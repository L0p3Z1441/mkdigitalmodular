
export enum Language {
  BR = 'BR',
  US = 'US',
  ES = 'ES',
}

export type NicheId = 
  | 'marketing' 
  | 'investment' 
  | 'development' 
  | 'relationships' 
  | 'programming' 
  | 'wellness' 
  | 'spirituality';

export interface User {
  name: string;
  email: string;
  country: string;
}

export interface Review {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  text: string;
}

export interface PlatformReview {
  id: string;
  text: string;
  author: string;
  role: string;
}

export interface FrequentReview extends Review {
  memberStatus: 'Black' | 'Platinum' | 'Gold' | 'Standard';
  purchaseCount: number;
}

export interface EmployeeReview {
  id: string;
  text: string;
  name: string;
  formerRole: string;
  currentRole: string;
}

export interface NewsItem {
  id: string;
  date: string;
  category: string;
  title: string;
  summary: string;
  content: string[];
  image: string;
  link: string;
}

export interface StatItem {
  label: string;
  value: string;
  suffix: string;
}

export interface FaqItem {
  question: string;
  answer: string;
  category: string;
  }

export interface DesignSpec {
  title: string;
  description: string;
  value: string;
}

export interface RoadmapStep {
  period: string;
  title: string;
  description: string;
  status: 'completed' | 'current' | 'future';
}

export interface GalleryImage {
  id: string;
  title: string;
  image: string;
  description: string;
}

export interface CouponItem {
  id: string;
  category: string;
  discount: number;
  description: string;
  code: string;
}

export interface NicheDetail {
  description: string;
  reviews: Review[];
  maxLevels?: number;
  checkoutLinks: {
    level1: string;
    level2: string;
    level3: string;
  };
}

export interface HubMapLevel {
  level: 1 | 2 | 3;
  title: string;
  description: string;
}

export interface HubFormat {
  id: string;
  title: string;
  icon: any; 
  questions: string[];
}

export interface TextSnippets {
  navNote: string;
  expectation: string;
  rhythm: string;
  intent: string;
  authority: string;
  maturity: string;
  honesty: string;
  manifesto: string;
  transition: string;
  anchor: string;
}

export interface TierBenefit {
  tier: string;
  benefits: string[];
}

export interface Translations {
  hero: {
    subtitle: string;
    cta: string;
    microcopy: string;
  };
  snippets: TextSnippets;
  about: {
    title: string;
    description: string;
  };
  stats: StatItem[];
  design: {
    title: string;
    subtitle: string;
    specs: DesignSpec[];
  };
  roadmap: {
    title: string;
    subtitle: string;
    items: RoadmapStep[];
  };
  gallery: {
    title: string;
    subtitle: string;
    items: GalleryImage[];
  };
  manifesto: {
    title: string;
    text: string[];
  };
  news: {
    title: string;
    subtitle: string;
    readMore: string;
    close: string;
    items: NewsItem[];
  };
  niches: {
    title: string;
    items: Record<NicheId, string>;
  };
  nicheDetails: Record<NicheId, NicheDetail>;
  products: {
    levels: {
      beginner: string;
      intermediate: string;
      advanced: string;
    };
    prices: {
      level1: string;
      level2: string;
      level3: string;
    };
    buy: string;
    currency: string;
    back: string;
  };
  evolution: {
    title: string;
    mastery: string;
  };
  faq: {
    title: string;
    items: FaqItem[];
  };
  auth: {
    login: string;
    register: string;
    logout: string;
    namePlaceholder: string;
    emailPlaceholder: string;
    passwordPlaceholder: string;
    submitLogin: string;
    submitRegister: string;
    switchToRegister: string;
    switchToLogin: string;
    welcome: string;
    country: string;
    error: string;
  };
  footer: {
    rights: string;
    contact: string;
  };
  platformReviews: {
    title: string;
    items: PlatformReview[];
  };
  frequentReviews: {
    title: string;
    subtitle: string;
    items: FrequentReview[];
  };
  careers: {
    title: string;
    subtitle: string;
    items: EmployeeReview[];
  };
  marketplace: {
    searchPlaceholder: string;
    departments: string;
    all: string;
    results: string;
    bestSeller: string;
    addToCart: string;
    noResults: string;
  };
}