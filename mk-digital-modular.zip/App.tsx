
import React, { useState, useEffect, useRef, Suspense } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { ArrowUp, ShoppingBag, Info, AlertTriangle, Loader2 } from 'lucide-react';
import { Language, Translations, NicheId, User, NewsItem } from './types';
import { CONTENT, NICHE_KEYS, NICHE_IMAGES } from './constants';
import LanguageSelector from './components/LanguageSelector';
import AuthModal from './components/AuthModal';
import NicheCard from './components/NicheCard';
import ProductCard from './components/ProductCard';
import LearningEvolution from './components/LearningEvolution';
import ReviewsSection from './components/ReviewsSection';
import ChatGuia from './components/ChatGuia';
import PlatformFeedback from './components/PlatformFeedback';
import FrequentReviews from './components/FrequentReviews';
import LatestNews from './components/LatestNews';
import ArticleReader from './components/ArticleReader';
import TrustStats from './components/TrustStats';
import FaqSection from './components/FaqSection';
import AcquisitionFeed from './components/AcquisitionFeed';
import HubHeader from './components/HubHeader';
// Eagerly load lightweight components, Lazy load heavy views
const Marketplace = React.lazy(() => import('./components/Marketplace'));
const HubView = React.lazy(() => import('./components/HubView'));
const DigitalGallery = React.lazy(() => import('./components/DigitalGallery'));
const DesignPhilosophy = React.lazy(() => import('./components/DesignPhilosophy'));
const Roadmap = React.lazy(() => import('./components/Roadmap'));
const EmployeeFeedback = React.lazy(() => import('./components/EmployeeFeedback'));
// BotGuide is heavy on logic, load lazily
const BotGuide = React.lazy(() => import('./components/BotGuide'));

// Loading Fallback Component
const LoadingSection = () => (
  <div className="w-full h-[500px] flex items-center justify-center bg-mk-black border-y border-white/5">
    <div className="flex flex-col items-center gap-4">
      <Loader2 className="w-8 h-8 text-mk-gold animate-spin" />
      <span className="text-xs text-gray-500 uppercase tracking-widest">Carregando Módulo...</span>
    </div>
  </div>
);

function App() {
  const [lang, setLang] = useState<Language>(Language.BR);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<'home' | 'marketplace' | 'hub'>('home');
  const [selectedNiche, setSelectedNiche] = useState<NicheId | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);

  // Ref to control the bot programmatically
  const botRef = useRef<any>(null);

  const t: Translations = CONTENT[lang];
  
  const maxLevels = selectedNiche ? (t.nicheDetails[selectedNiche]?.maxLevels || 3) : 3;

  useEffect(() => {
    const session = localStorage.getItem('mk_user_session');
    if (session) {
      try {
        setUser(JSON.parse(session));
      } catch (e) {
        localStorage.removeItem('mk_user_session');
      }
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsScrolled(currentScrollY > 50);
      setShowBackToTop(currentScrollY > 500);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.3], [1, 0.9]);
  const heroY = useTransform(scrollYProgress, [0, 0.3], [0, 100]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [selectedNiche, currentView]);

  const handleLogin = async (email: string, pass: string) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    const usersDb = JSON.parse(localStorage.getItem('mk_users_db') || '[]');
    const foundUser = usersDb.find((u: any) => u.email === email && u.password === pass);
    if (foundUser) {
      const { password, ...safeUser } = foundUser;
      setUser(safeUser);
      localStorage.setItem('mk_user_session', JSON.stringify(safeUser));
    } else {
      throw new Error('Invalid credentials');
    }
  };

  const handleRegister = async (name: string, email: string, pass: string, country: string) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    const usersDb = JSON.parse(localStorage.getItem('mk_users_db') || '[]');
    if (usersDb.find((u: any) => u.email === email)) {
      throw new Error('User already exists');
    }
    const newUser = { name, email, password: pass, country };
    usersDb.push(newUser);
    localStorage.setItem('mk_users_db', JSON.stringify(usersDb));
    const { password, ...safeUser } = newUser;
    setUser(safeUser);
    localStorage.setItem('mk_user_session', JSON.stringify(safeUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('mk_user_session');
  };

  const handleBotNavigation = (nicheId: string) => {
    if (NICHE_KEYS.includes(nicheId as NicheId)) {
      setSelectedNiche(nicheId as NicheId);
      setCurrentView('home');
    } else if (nicheId === 'home') {
      setSelectedNiche(null);
      setCurrentView('home');
    }
  };

  const handleGoHome = () => {
    setSelectedNiche(null);
    setCurrentView('home');
  };

  return (
    <div className="min-h-screen bg-mk-black text-white selection:bg-mk-gold selection:text-black font-sans overflow-x-hidden">
      
      <ChatGuia 
        lang={lang} 
        nicheDetails={t.nicheDetails}
        nicheNames={t.niches.items}
        nicheImages={NICHE_IMAGES}
        onNavigateToProduct={(nicheId) => {
          setSelectedNiche(nicheId);
          setCurrentView('home');
        }}
      />

      <Suspense fallback={null}>
        <BotGuide ref={botRef} onNavigate={handleBotNavigation} lang={lang} />
      </Suspense>

      <AcquisitionFeed />
      
      <ArticleReader 
        article={selectedArticle} 
        onClose={() => setSelectedArticle(null)}
        closeText={t.news.close}
      />

      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={scrollToTop}
            className="fixed bottom-6 right-6 z-[70] p-3 bg-mk-black border border-mk-gold/30 text-mk-gold hover:bg-mk-gold hover:text-black transition-all duration-500 shadow-[0_0_20px_rgba(212,175,55,0.2)] group rounded-full"
            aria-label="Voltar ao topo"
          >
            <ArrowUp size={24} className="group-hover:-translate-y-1 transition-transform duration-300" />
          </motion.button>
        )}
      </AnimatePresence>

      <HubHeader 
        user={user}
        lang={lang}
        isScrolled={isScrolled}
        currentView={currentView}
        translations={t}
        onLogin={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
        onNavigate={(view) => {
          setCurrentView(view);
          setSelectedNiche(null);
        }}
        onLangSelect={setLang}
      />

      <AnimatePresence mode='wait'>
        {currentView === 'hub' ? (
           <motion.div
            key="hub"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
           >
             <Suspense fallback={<LoadingSection />}>
                <HubView 
                  nicheNames={t.niches.items} 
                  lang={lang}
                  onAskBot={(question) => botRef.current?.ask(question)}
                />
             </Suspense>
           </motion.div>
        ) : currentView === 'marketplace' ? (
           <Suspense fallback={<LoadingSection />}>
             <Marketplace 
               translations={t}
               niches={t.niches.items}
               nicheDetails={t.nicheDetails}
               nicheImages={NICHE_IMAGES}
               onProductClick={(nicheId) => {
                  setCurrentView('home');
                  setSelectedNiche(nicheId);
               }}
             />
           </Suspense>
        ) : !selectedNiche ? (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <header className="relative h-screen flex items-center justify-center overflow-hidden bg-mk-black">
              <div className="absolute inset-0 z-0">
                 <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(212,175,55,0.08),transparent_70%)] animate-pulse-slow will-change-transform" />
                 <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-mk-red/20 rounded-full blur-[100px] animate-float will-change-transform" />
                 <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-mk-gold/10 rounded-full blur-[120px] animate-float will-change-transform" style={{ animationDelay: '2s' }} />
              </div>

              <motion.div 
                style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}
                className="container mx-auto px-6 text-center z-10 relative"
              >
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="mb-4"
                >
                   <span className="text-[10px] md:text-xs text-mk-gold uppercase tracking-[0.4em] font-light border-b border-mk-gold/30 pb-1">
                      {t.snippets.anchor}
                   </span>
                </motion.div>

                <motion.h1 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                  className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-serif font-bold mb-6 tracking-tighter drop-shadow-2xl"
                >
                  <span className="text-gold-gradient bg-clip-text text-transparent">MK DIGITAL</span>
                </motion.h1>

                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "160px" }}
                  transition={{ duration: 1, delay: 0.3 }}
                  className="h-[2px] bg-gradient-to-r from-transparent via-mk-red to-transparent mx-auto mb-8 shadow-[0_0_10px_#B11212]"
                />

                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 1 }}
                  className="text-base sm:text-lg md:text-xl text-gray-300 max-w-2xl mx-auto font-light leading-relaxed mb-12 mix-blend-screen"
                >
                  {t.hero.subtitle}
                </motion.p>

                <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    onClick={() => document.getElementById('niches')?.scrollIntoView({ behavior: 'smooth' })}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="group relative px-10 py-4 bg-transparent border border-mk-gold/50 text-mk-gold font-bold uppercase tracking-widest overflow-hidden rounded-sm w-full sm:w-auto"
                  >
                    <span className="relative z-10 group-hover:text-black transition-colors duration-300">{t.hero.cta}</span>
                    <div className="absolute inset-0 bg-mk-gold transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300 ease-out" />
                  </motion.button>

                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.9 }}
                    onClick={() => setCurrentView('marketplace')}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-10 py-4 bg-white/5 hover:bg-white/10 text-white font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 rounded-sm border border-white/10 hover:border-white/30 w-full sm:w-auto"
                  >
                    <ShoppingBag size={18} /> MK Store
                  </motion.button>
                </div>
              </motion.div>
            </header>

            <div className="bg-mk-black border-b border-white/5 py-4">
               <div className="container mx-auto px-6 text-center">
                  <p className="text-gray-500 text-xs font-light italic tracking-wide">
                     <Info size={12} className="inline mr-2 text-mk-gold/50" />
                     {t.snippets.navNote}
                  </p>
               </div>
            </div>

            <TrustStats stats={t.stats} />

            <section className="py-24 bg-mk-black relative z-10 border-t border-white/5">
              <div className="container mx-auto px-6 md:px-12 lg:px-24 text-center md:text-left">
                <div className="md:border-l-2 md:border-mk-red md:pl-12">
                  <h2 className="text-3xl md:text-4xl font-serif text-white mb-6">
                    {t.about.title}
                  </h2>
                  <p className="text-gray-400 text-lg md:text-xl leading-relaxed max-w-4xl mb-8">
                    {t.about.description}
                  </p>
                  <div className="mt-8 p-6 bg-white/5 border-l-2 border-mk-gold/30">
                     <p className="text-gray-300 italic font-serif text-lg">"{t.snippets.manifesto}"</p>
                  </div>
                </div>
              </div>
            </section>
            
            <Suspense fallback={<LoadingSection />}>
               <DigitalGallery title={t.gallery.title} subtitle={t.gallery.subtitle} items={t.gallery.items} />
            </Suspense>
            
            <div className="py-16 bg-neutral-900 border-y border-white/5">
               <div className="container mx-auto px-6 text-center">
                  <p className="text-xl md:text-2xl font-serif text-white/80 leading-relaxed max-w-3xl mx-auto">
                     {t.snippets.intent}
                  </p>
               </div>
            </div>

            <Suspense fallback={<LoadingSection />}>
              <DesignPhilosophy title={t.design.title} subtitle={t.design.subtitle} specs={t.design.specs} />
              <Roadmap title={t.roadmap.title} subtitle={t.roadmap.subtitle} items={t.roadmap.items} />
            </Suspense>

            <div className="bg-black py-8 border-t border-white/5">
               <p className="text-center text-gray-500 text-xs uppercase tracking-widest">{t.snippets.transition}</p>
            </div>

            <section className="py-24 bg-mk-gray border-y border-mk-gold/10 relative overflow-hidden">
               <div className="container mx-auto px-6 max-w-4xl text-center relative z-10">
                  <h2 className="text-3xl md:text-5xl font-serif text-mk-gold mb-10">{t.manifesto.title}</h2>
                  <div className="space-y-8 text-lg md:text-xl text-gray-300 font-light leading-relaxed">
                     {t.manifesto.text.map((paragraph, i) => (
                        <p key={i}>{paragraph}</p>
                     ))}
                  </div>
               </div>
            </section>

            <PlatformFeedback data={t.platformReviews} />

            <section id="niches" className="py-24 bg-[#080808] content-visibility-auto">
              <div className="container mx-auto px-6">
                <div className="mb-16 text-center">
                  <div className="mb-6 inline-block">
                     <p className="text-gray-500 text-sm italic border-b border-mk-gold/20 pb-1">{t.snippets.rhythm}</p>
                  </div>
                  <h2 className="text-4xl md:text-5xl font-serif text-white">
                    {t.niches.title}
                  </h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {NICHE_KEYS.map((key, index) => (
                    <NicheCard 
                      key={key} 
                      title={t.niches.items[key]} 
                      image={NICHE_IMAGES[key]} 
                      index={index} 
                      onClick={() => setSelectedNiche(key)}
                    />
                  ))}
                </div>
              </div>
            </section>
            
            <div className="py-12 bg-neutral-900/50 border-y border-white/5 text-center px-6">
               <p className="text-gray-400 font-serif italic text-lg">"{t.snippets.honesty}"</p>
            </div>

            <FrequentReviews data={t.frequentReviews} />
            <LatestNews data={t.news} onRead={(article) => setSelectedArticle(article)} />
            
            <FaqSection title={t.faq.title} items={t.faq.items} />
            
            <Suspense fallback={null}>
               <EmployeeFeedback data={t.careers} />
            </Suspense>

            <div className="bg-[#050505] border-t border-white/5 py-8">
               <div className="container mx-auto px-6 flex justify-center">
                  <div className="flex items-center gap-3 text-gray-500 text-xs uppercase tracking-wider border border-white/10 px-6 py-3 rounded-full">
                     <AlertTriangle size={14} className="text-mk-gold" />
                     {t.snippets.maturity}
                  </div>
               </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="details"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="pt-24"
          >
             <div className="relative h-[50vh] flex items-center justify-center bg-black overflow-hidden">
                <div 
                   className="absolute inset-0 bg-cover bg-center opacity-40 blur-[2px]" 
                   style={{ backgroundImage: `url(${NICHE_IMAGES[selectedNiche]})` }}
                />
                <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
                  <h2 className="text-5xl md:text-7xl font-serif text-white mb-8">
                    {t.niches.items[selectedNiche]}
                  </h2>
                  <p className="text-lg sm:text-xl text-gray-300 font-light leading-relaxed">
                    {t.nicheDetails[selectedNiche].description}
                  </p>
                </div>
             </div>

             <LearningEvolution 
               translations={t.evolution} 
               levels={t.products.levels}
               maxLevels={maxLevels}
             />

             <section className="py-24">
               <div className="container mx-auto px-6">
                  <div className={`grid gap-8 ${maxLevels === 2 ? 'grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto' : 'grid-cols-1 md:grid-cols-3'}`}>
                     <ProductCard level={1} price={t.products.prices.level1} nicheTitle={t.niches.items[selectedNiche]} translations={t.products} checkoutUrl={t.nicheDetails[selectedNiche].checkoutLinks.level1} />
                     <ProductCard level={2} price={t.products.prices.level2} nicheTitle={t.niches.items[selectedNiche]} translations={t.products} checkoutUrl={t.nicheDetails[selectedNiche].checkoutLinks.level2} />
                     {maxLevels === 3 && (
                       <ProductCard level={3} price={t.products.prices.level3} nicheTitle={t.niches.items[selectedNiche]} translations={t.products} checkoutUrl={t.nicheDetails[selectedNiche].checkoutLinks.level3} />
                     )}
                  </div>
               </div>
             </section>

             <ReviewsSection reviews={t.nicheDetails[selectedNiche].reviews} />

             <div className="py-16 text-center border-t border-white/5">
                <button onClick={handleGoHome} className="text-gray-500 hover:text-white uppercase tracking-widest text-sm border-b border-transparent hover:border-mk-gold pb-1 transition-all">
                  {t.products.back}
                </button>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="bg-black py-16 border-t border-white/10 content-visibility-auto">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-2xl font-serif text-mk-gold mb-8">MK DIGITAL</h3>
          <p className="text-gray-600 text-xs tracking-widest uppercase mb-4">Referência Premium em Conhecimento Estratégico</p>
          <p className="text-gray-600 text-[10px] tracking-widest mb-4">&copy; {new Date().getFullYear()} MK Digital Platform. {t.footer.rights}</p>
          <p className="text-gray-800 text-[9px] uppercase tracking-wider">{t.snippets.authority}</p>
        </div>
      </footer>

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        text={t.auth}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />
    </div>
  );
}

export default App;
