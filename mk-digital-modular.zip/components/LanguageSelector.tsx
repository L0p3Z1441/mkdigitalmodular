import React from 'react';
import { Language } from '../types';
import { motion } from 'framer-motion';

interface Props {
  currentLang: Language;
  onSelect: (lang: Language) => void;
}

const LanguageSelector: React.FC<Props> = ({ currentLang, onSelect }) => {
  const flags = [
    { code: Language.BR, label: "🇧🇷" },
    { code: Language.US, label: "🇺🇸" },
    { code: Language.ES, label: "🇪🇸" },
  ];

  return (
    <div className="flex space-x-6 items-center">
      {flags.map((flag) => (
        <motion.button
          key={flag.code}
          onClick={() => onSelect(flag.code)}
          whileHover={{ scale: 1.2, y: -2 }}
          whileTap={{ scale: 0.95 }}
          className={`text-2xl filter transition-opacity duration-300 ${
            currentLang === flag.code ? 'opacity-100 grayscale-0' : 'opacity-40 grayscale hover:opacity-100 hover:grayscale-0'
          }`}
          aria-label={`Select ${flag.code}`}
        >
          {flag.label}
        </motion.button>
      ))}
    </div>
  );
};

export default LanguageSelector;