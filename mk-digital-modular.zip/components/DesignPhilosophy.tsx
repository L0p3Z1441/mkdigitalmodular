
import React from 'react';
import { motion } from 'framer-motion';
import { DesignSpec } from '../types';
import { Palette, Type, Grid3X3 } from 'lucide-react';

interface Props {
  title: string;
  subtitle: string;
  specs: DesignSpec[];
}

const DesignPhilosophy: React.FC<Props> = ({ title, subtitle, specs }) => {
  const icons = [Type, Palette, Grid3X3];

  return (
    <section className="py-24 bg-[#050505] overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
           <div className="lg:w-1/2">
              <h2 className="text-[10px] text-mk-gold uppercase tracking-[0.4em] mb-4 font-bold">{subtitle}</h2>
              <h3 className="text-4xl md:text-6xl font-serif text-white mb-8 leading-tight">{title}</h3>
              <p className="text-gray-400 text-lg font-light leading-relaxed mb-12 max-w-xl">
                 Acreditamos que a forma como o conhecimento é apresentado altera a forma como ele é absorvido. Na MK Digital, o design não é decorativo; é estratégico.
              </p>
              
              <div className="space-y-8">
                 {specs.map((spec, i) => {
                    const Icon = icons[i % icons.length];
                    return (
                       <motion.div 
                         key={i}
                         initial={{ opacity: 0, x: -30 }}
                         whileInView={{ opacity: 1, x: 0 }}
                         viewport={{ once: true }}
                         transition={{ delay: i * 0.2 }}
                         className="flex gap-6 items-start group"
                       >
                          <div className="p-3 bg-white/5 border border-white/10 group-hover:border-mk-gold transition-colors">
                             <Icon className="text-mk-gold" size={24} />
                          </div>
                          <div>
                             <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-2 group-hover:text-mk-gold transition-colors">{spec.title}</h4>
                             <p className="text-gray-500 text-sm leading-relaxed mb-1">{spec.description}</p>
                             <span className="text-[10px] text-mk-gold/50 font-mono">{spec.value}</span>
                          </div>
                       </motion.div>
                    );
                 })}
              </div>
           </div>
           
           <div className="lg:w-1/2 relative">
              <div className="relative z-10 p-8 border border-white/10 bg-black shadow-2xl">
                 <div className="aspect-square bg-gradient-to-br from-mk-gray to-black flex items-center justify-center overflow-hidden group">
                    <motion.div 
                       animate={{ 
                         rotate: [0, 90, 180, 270, 360],
                         scale: [1, 1.1, 1] 
                       }}
                       transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                       className="w-64 h-64 border-2 border-mk-gold/20 flex items-center justify-center"
                    >
                       <div className="w-48 h-48 border border-mk-gold/10 rotate-45" />
                    </motion.div>
                    <div className="absolute inset-0 flex items-center justify-center">
                       <span className="text-gold-gradient font-serif text-8xl opacity-20 group-hover:opacity-100 transition-opacity duration-1000">MK</span>
                    </div>
                 </div>
                 <div className="mt-8 flex justify-between text-[10px] text-gray-700 font-mono uppercase tracking-[0.3em]">
                    <span>Standard ISO:Premium</span>
                    <span>Version 4.2.0</span>
                 </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -top-12 -right-12 w-64 h-64 bg-mk-red/5 rounded-full blur-[100px]" />
              <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-mk-gold/5 rounded-full blur-[100px]" />
           </div>
        </div>
      </div>
    </section>
  );
};

export default DesignPhilosophy;
