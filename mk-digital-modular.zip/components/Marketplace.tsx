

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, ShoppingBag, Star, X } from 'lucide-react';
import { Translations, NicheId, NicheDetail } from '../types';
import { NICHE_KEYS } from '../constants';

interface Props {
  translations: Translations;
  niches: Record<NicheId, string>;
  nicheDetails: Record<NicheId, NicheDetail>;
  nicheImages: Record<NicheId, string>;
  onProductClick: (nicheId: NicheId) => void;
}

interface FlattenedProduct {
  id: string;
  nicheId: NicheId;
  nicheTitle: string;
  level: 1 | 2 | 3;
  title: string;
  price: string;
  image: string;
  link: string;
  rating: number;
  reviewCount: number;
}

const Marketplace: React.FC<Props> = ({ translations, niches, nicheDetails, nicheImages, onProductClick }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<NicheId | 'all'>('all');
  const [products, setProducts] = useState<FlattenedProduct[]>([]);
  const t = translations.marketplace;

  useEffect(() => {
    const allProducts: FlattenedProduct[] = [];
    NICHE_KEYS.forEach(key => {
      const details = nicheDetails[key];
      const maxLevels = details.maxLevels || 3;
      for (let i = 1; i <= maxLevels; i++) {
        const level = i as 1 | 2 | 3;
        let checkoutLink = "#";
        let levelTitle = "";
        let price = "";

        if (level === 1) {
          checkoutLink = details.checkoutLinks.level1;
          levelTitle = translations.products.levels.beginner;
          price = translations.products.prices.level1;
        } else if (level === 2) {
          checkoutLink = details.checkoutLinks.level2;
          levelTitle = translations.products.levels.intermediate;
          price = translations.products.prices.level2;
        } else {
          checkoutLink = details.checkoutLinks.level3;
          levelTitle = translations.products.levels.advanced;
          price = translations.products.prices.level3;
        }

        allProducts.push({
          id: `${key}-${level}`,
          nicheId: key,
          nicheTitle: niches[key],
          level: level,
          title: `${niches[key]} - ${levelTitle}`,
          price: price,
          image: nicheImages[key],
          link: checkoutLink,
          rating: level === 3 ? 5 : 4.5,
          reviewCount: Math.floor(Math.random() * 500) + 50
        });
      }
    });
    setProducts(allProducts);
  }, [translations, niches, nicheDetails, nicheImages]);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.nicheTitle.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || p.nicheId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-24 pb-12 bg-[#080808]"
    >
      {/* Search Header */}
      <div className="bg-mk-black/90 backdrop-blur-md border-b border-white/10 sticky top-[72px] z-30 py-4 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
             <div className="relative w-full max-w-3xl mx-auto flex shadow-lg shadow-mk-gold/5 transition-shadow focus-within:shadow-mk-gold/20 rounded-md">
                <div className="bg-neutral-800/80 rounded-l-md flex items-center px-4 border border-r-0 border-white/10">
                   <Filter size={18} className="text-mk-gold" />
                </div>
                <input 
                  type="text"
                  placeholder={t.searchPlaceholder}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-neutral-900/80 text-white px-4 py-3 border-y border-white/10 outline-none placeholder:text-gray-500 focus:bg-black transition-colors"
                />
                 {searchTerm && (
                   <button onClick={() => setSearchTerm('')} className="bg-neutral-900/80 border-y border-white/10 flex items-center px-2 text-gray-400 hover:text-white">
                      <X size={16} />
                   </button>
                 )}
                <button className="bg-mk-gold hover:bg-white hover:text-black text-black px-6 rounded-r-md transition-all duration-300 font-bold border border-mk-gold">
                   <Search size={22} />
                </button>
             </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-8 flex flex-col lg:flex-row gap-8">
        
        {/* Sidebar Departments (Scrollable on mobile) */}
        <div className="w-full lg:w-64 flex-shrink-0">
           <h3 className="font-bold text-white text-lg mb-4 flex items-center gap-2">
             <ShoppingBag size={20} className="text-mk-gold" /> {t.departments}
           </h3>
           <div className="flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 scrollbar-hide snap-x">
              <button 
                onClick={() => setSelectedCategory('all')}
                className={`flex-shrink-0 snap-start text-left px-4 py-3 rounded-md transition-all whitespace-nowrap border ${selectedCategory === 'all' ? 'bg-mk-gold text-black border-mk-gold font-bold shadow-[0_0_15px_rgba(212,175,55,0.3)]' : 'bg-neutral-900/50 text-gray-400 border-transparent hover:border-mk-gold/30 hover:text-white'}`}
              >
                {t.all}
              </button>
              {NICHE_KEYS.map(key => (
                 <button 
                   key={key}
                   onClick={() => setSelectedCategory(key)}
                   className={`flex-shrink-0 snap-start text-left px-4 py-3 rounded-md transition-all whitespace-nowrap border ${selectedCategory === key ? 'bg-mk-gold text-black border-mk-gold font-bold shadow-[0_0_15px_rgba(212,175,55,0.3)]' : 'bg-neutral-900/50 text-gray-400 border-transparent hover:border-mk-gold/30 hover:text-white'}`}
                 >
                   {niches[key]}
                 </button>
              ))}
           </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
           <div className="flex justify-between items-center mb-6">
              <p className="text-gray-400 text-sm">
                 <span className="text-white font-bold">{filteredProducts.length}</span> {t.results}
              </p>
           </div>

           <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6">
             <AnimatePresence mode="popLayout">
                {filteredProducts.map((product, index) => (
                  <motion.div 
                    layout
                    key={product.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3, delay: index * 0.03, ease: "easeOut" }}
                    className="bg-[#111] border border-white/5 rounded-sm overflow-hidden hover:border-mk-gold/50 transition-all duration-300 flex flex-col group h-full hover:shadow-[0_0_20px_rgba(0,0,0,0.8)] relative gpu-accelerated"
                  >
                    {/* Image Area */}
                    <div className="relative h-56 bg-black overflow-hidden cursor-pointer" onClick={() => onProductClick(product.nicheId)}>
                       <img 
                         src={product.image}
                         alt={product.title}
                         loading="lazy"
                         decoding="async"
                         width="600"
                         height="400"
                         className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 will-change-transform"
                       />
                       <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
                       
                       {product.level === 3 && (
                         <div className="absolute top-0 right-0 bg-mk-red text-white text-[10px] font-bold px-3 py-1 uppercase shadow-md shadow-mk-red/20 z-10">
                            {t.bestSeller}
                         </div>
                       )}

                       {/* Hover Overlay */}
                       <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <span className="px-6 py-2 border border-white text-white uppercase tracking-widest text-xs font-bold hover:bg-white hover:text-black transition-colors">
                             {t.addToCart}
                          </span>
                       </div>
                    </div>

                    {/* Content */}
                    <div className="p-5 flex flex-col flex-grow relative">
                       <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-mk-gold/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                       
                       <div 
                         className="cursor-pointer"
                         onClick={() => onProductClick(product.nicheId)}
                       >
                         <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">{product.nicheTitle}</p>
                         <h3 className="text-gray-100 font-bold text-lg leading-tight mb-2 group-hover:text-mk-gold transition-colors">
                           {product.title}
                         </h3>
                         <div className="flex items-center gap-2 mb-3">
                            <div className="flex text-mk-gold">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} size={12} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} className={i < Math.floor(product.rating) ? "drop-shadow-[0_0_5px_rgba(212,175,55,0.5)]" : "text-gray-800"} />
                              ))}
                            </div>
                            <span className="text-xs text-gray-500">({product.reviewCount})</span>
                         </div>
                       </div>

                       <div className="mt-auto pt-4 border-t border-white/5 flex items-center justify-between">
                          <div>
                             <span className="text-xs text-gray-500 font-serif mr-1">{translations.products.currency}</span>
                             <span className="text-2xl font-bold text-white">{product.price}</span>
                          </div>

                          <a 
                            href={product.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-mk-gold hover:bg-white text-black font-bold px-4 py-2 rounded-sm transition-colors text-xs uppercase tracking-wide shadow-lg shadow-mk-gold/10"
                          >
                            {translations.products.buy}
                          </a>
                       </div>
                    </div>
                  </motion.div>
                ))}
             </AnimatePresence>
           </motion.div>

           {filteredProducts.length === 0 && (
             <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20 bg-neutral-900/30 border border-white/5 rounded-lg">
                <Search size={48} className="mx-auto text-gray-600 mb-4" />
                <h3 className="text-xl text-white font-bold mb-2">{t.noResults}</h3>
                <button 
                  onClick={() => setSearchTerm('')}
                  className="text-mk-gold hover:underline text-sm"
                >
                  Limpar pesquisa
                </button>
             </motion.div>
           )}
        </div>
      </div>
    </motion.div>
  );
};

export default Marketplace;