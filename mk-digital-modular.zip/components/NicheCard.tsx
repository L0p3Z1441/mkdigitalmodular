
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

interface Props {
  title: string;
  image: string;
  index: number;
  onClick: () => void;
}

const NicheCard: React.FC<Props> = ({ title, image, index, onClick }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }} // Premium Cubic Bezier
      onClick={onClick}
      className="group relative h-[300px] sm:h-[350px] w-full overflow-hidden cursor-pointer border border-white/5 hover:border-mk-gold/50 transition-colors duration-500 shadow-lg hover:shadow-[0_0_30px_rgba(212,175,55,0.15)] gpu-accelerated"
    >
      {/* Background Image with Zoom Effect - Optimized with gpu-accelerated class */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-[1.2s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105 grayscale group-hover:grayscale-0 will-change-transform"
        style={{ backgroundImage: `url(${image})` }}
      />
      
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent opacity-90 group-hover:opacity-70 transition-opacity duration-700 ease-in-out" />

      {/* Shine Effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" style={{ transform: 'skewX(-20deg)' }} />
      </div>

      {/* Content */}
      <div className="absolute inset-0 p-6 sm:p-8 flex flex-col justify-end items-start z-10">
        <div className="w-8 h-[2px] bg-mk-gold mb-4 origin-left group-hover:w-24 transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] shadow-[0_0_10px_#D4AF37]" />
        
        <h3 className="text-2xl sm:text-3xl font-serif text-white group-hover:text-gold-gradient transition-all duration-500 drop-shadow-md">
          {title}
        </h3>
        
        <div className="mt-4 overflow-hidden h-0 group-hover:h-10 transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]">
           <span className="text-xs sm:text-sm uppercase tracking-widest text-white/90 flex items-center gap-2 font-bold">
             Explorar Acervo <ArrowUpRight size={16} className="text-mk-gold" />
           </span>
        </div>
      </div>
      
      {/* Decorative Borders */}
      <div className="absolute top-0 right-0 w-[1px] h-0 bg-gradient-to-b from-mk-gold to-transparent group-hover:h-full transition-all duration-1000 ease-in-out delay-100" />
      <div className="absolute bottom-0 left-0 w-0 h-[1px] bg-gradient-to-r from-mk-gold to-transparent group-hover:w-full transition-all duration-1000 ease-in-out" />
    </motion.div>
  );
};

export default NicheCard;
