import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Clock, Calendar, Share2 } from 'lucide-react';
import { NewsItem } from '../types';

interface Props {
  article: NewsItem | null;
  onClose: () => void;
  closeText: string;
}

const ArticleReader: React.FC<Props> = ({ article, onClose, closeText }) => {
  if (!article) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/95 backdrop-blur-md"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 40 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="relative w-full max-w-4xl bg-[#0a0a0a] border border-mk-gold/20 shadow-2xl shadow-mk-gold/10 overflow-hidden flex flex-col max-h-[90vh] rounded-sm"
        >
          {/* Header Image */}
          <div className="relative h-64 sm:h-80 flex-shrink-0">
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${article.image})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-black/40 to-transparent" />
            
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 bg-black/50 hover:bg-mk-red text-white p-2 rounded-full transition-colors backdrop-blur-sm border border-white/10"
            >
              <X size={20} />
            </button>

            <div className="absolute bottom-0 left-0 p-6 sm:p-10 w-full">
              <span className="inline-block px-3 py-1 bg-mk-gold text-black text-xs font-bold uppercase tracking-widest mb-4">
                {article.category}
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-white leading-tight drop-shadow-lg">
                {article.title}
              </h2>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-10 custom-scrollbar bg-[#0a0a0a]">
            <div className="flex items-center justify-between text-gray-500 text-sm mb-8 border-b border-white/10 pb-4">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-2"><Calendar size={14} /> {article.date}</span>
                <span className="flex items-center gap-2"><Clock size={14} /> 5 min read</span>
              </div>
              <button className="flex items-center gap-2 hover:text-mk-gold transition-colors">
                 <Share2 size={16} /> <span className="hidden sm:inline">Share</span>
              </button>
            </div>

            <div className="space-y-6">
               <p className="text-xl text-gray-300 font-light leading-relaxed first-letter:text-5xl first-letter:font-serif first-letter:text-mk-gold first-letter:float-left first-letter:mr-3 first-letter:mt-[-10px]">
                 {article.summary}
               </p>
               
               {article.content && article.content.map((paragraph, idx) => (
                 <p key={idx} className="text-lg text-gray-400 leading-loose font-light">
                   {paragraph}
                 </p>
               ))}
            </div>

            <div className="mt-12 pt-8 border-t border-white/10 text-center">
              <button 
                onClick={onClose}
                className="text-mk-gold hover:text-white uppercase tracking-widest text-sm font-bold border-b border-mk-gold/30 hover:border-white pb-1 transition-all"
              >
                {closeText}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ArticleReader;