import React from 'react';
import { motion } from 'framer-motion';
import { PlatformReview } from '../types';
import { Award, Monitor, Layers } from 'lucide-react';

interface Props {
  data: {
    title: string;
    items: PlatformReview[];
  };
}

const PlatformFeedback: React.FC<Props> = ({ data }) => {
  const icons = [Award, Monitor, Layers];

  return (
    <section className="py-24 bg-black border-y border-white/5 relative">
      <div className="container mx-auto px-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-serif text-white mb-4">
            {data.title}
          </h2>
          <div className="w-12 h-1 bg-mk-red mx-auto" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {data.items.map((review, index) => {
            const Icon = icons[index % icons.length];
            return (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="bg-neutral-900/40 p-8 border border-white/5 hover:border-mk-gold/40 transition-all duration-500 group relative overflow-hidden"
              >
                {/* Decorative Background Icon */}
                <div className="absolute -right-4 -bottom-4 text-white/5 group-hover:text-mk-gold/5 transition-colors duration-500">
                  <Icon size={120} />
                </div>

                <div className="relative z-10">
                  <div className="mb-6 text-mk-gold opacity-80 group-hover:opacity-100 transition-opacity">
                    <Icon size={32} />
                  </div>

                  <p className="text-gray-300 text-lg leading-relaxed mb-6 font-light">
                    "{review.text}"
                  </p>

                  <div className="border-t border-white/10 pt-4">
                    <p className="text-white font-serif text-lg">{review.author}</p>
                    <p className="text-xs text-mk-red uppercase tracking-widest mt-1">{review.role}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default PlatformFeedback;