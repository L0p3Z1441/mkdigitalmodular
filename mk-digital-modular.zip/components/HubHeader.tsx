
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Language, Translations } from '../types';
import { User as UserIcon, LogOut, Menu, X, Globe, ShieldCheck, Wifi, ShoppingBag, Home, LayoutGrid } from 'lucide-react';
import LanguageSelector from './LanguageSelector';

interface Props {
  user: User | null;
  lang: Language;
  isScrolled: boolean;
  currentView: 'home' | 'marketplace' | 'hub';
  translations: Translations;
  onLogin: () => void;
  onLogout: () => void;
  onMenuToggle: () => void;
  onNavigate: (view: 'home' | 'marketplace' | 'hub') => void;
  onLangSelect: (lang: Language) => void;
}

const HubHeader: React.FC<Props> = ({ 
  user, lang, isScrolled, currentView, translations, 
  onLogin, onLogout, onMenuToggle, onNavigate, onLangSelect 
}) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className={`fixed w-full z-50 transition-all duration-500 ${
      isScrolled ? 'bg-black/95 backdrop-blur-xl shadow-2xl' : 'bg-gradient-to-b from-black/80 to-transparent'
    }`}>
      {/* Top System Bar */}
      <div className="hidden md:flex justify-between items-center px-6 py-1 border-b border-white/5 bg-[#020202] text-[10px] uppercase tracking-[0.2em] font-mono text-gray-500">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-2 text-mk-gold">
            <Wifi size={10} /> SYSTEM ONLINE
          </span>
          <span className="hidden lg:inline">SECURE CONNECTION SHA-256</span>
        </div>
        <div className="flex items-center gap-4">
          <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <span className="text-mk-gold">MK-HUB v4.2</span>
        </div>
      </div>

      {/* Main Navigation */}
      <div className={`container mx-auto px-6 transition-all duration-500 ${isScrolled ? 'py-3' : 'py-6'}`}>
        <div className="flex justify-between items-center">
          
          {/* Logo Area */}
          <div className="flex items-center gap-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => onNavigate('home')}
            >
              <div className="w-8 h-8 bg-mk-gold/10 border border-mk-gold flex items-center justify-center rounded-sm group-hover:bg-mk-gold group-hover:text-black transition-all duration-300">
                <span className="font-serif font-bold text-lg">M</span>
              </div>
              <div>
                <h1 className="font-serif text-white font-bold text-lg leading-none tracking-wider">MK DIGITAL</h1>
                <p className="text-[8px] text-mk-gold uppercase tracking-[0.3em]">Premium Hub</p>
              </div>
            </motion.div>

            {/* Desktop Nav Links */}
            <nav className="hidden md:flex items-center space-x-1 pl-8 border-l border-white/10 h-8">
              <button 
                onClick={() => onNavigate('home')}
                className={`px-4 py-1.5 rounded-sm text-xs font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${
                  currentView === 'home' 
                    ? 'bg-white/10 text-white border border-white/10' 
                    : 'text-gray-500 hover:text-white hover:bg-white/5'
                }`}
              >
                <Home size={14} /> Home
              </button>
              <button 
                onClick={() => onNavigate('marketplace')}
                className={`px-4 py-1.5 rounded-sm text-xs font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${
                  currentView === 'marketplace' 
                    ? 'bg-mk-gold/10 text-mk-gold border border-mk-gold/30 shadow-[0_0_15px_rgba(212,175,55,0.1)]' 
                    : 'text-gray-500 hover:text-mk-gold hover:bg-mk-gold/5'
                }`}
              >
                <ShoppingBag size={14} /> Store
              </button>
              <button 
                onClick={() => onNavigate('hub')}
                className={`px-4 py-1.5 rounded-sm text-xs font-bold uppercase tracking-widest transition-all flex items-center gap-2 ${
                  currentView === 'hub' 
                    ? 'bg-mk-red/10 text-mk-red border border-mk-red/30 shadow-[0_0_15px_rgba(138,15,15,0.1)]' 
                    : 'text-gray-500 hover:text-mk-red hover:bg-mk-red/5'
                }`}
              >
                <LayoutGrid size={14} /> Hub
              </button>
            </nav>
          </div>

          {/* Right Actions */}
          <div className="hidden md:flex items-center gap-6">
            <LanguageSelector currentLang={lang} onSelect={onLangSelect} />
            
            <div className="w-px h-8 bg-white/10" />

            {user ? (
              <div className="flex items-center gap-4">
                <div className="text-right hidden lg:block">
                  <p className="text-[9px] text-gray-500 uppercase tracking-widest mb-0.5">{translations.auth.welcome}</p>
                  <p className="text-xs font-bold text-white flex items-center justify-end gap-1">
                     {user.name} <ShieldCheck size={12} className="text-mk-gold" />
                  </p>
                </div>
                <button 
                  onClick={onLogout}
                  className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-gray-400 hover:text-mk-red hover:border-mk-red transition-all"
                  title={translations.auth.logout}
                >
                  <LogOut size={14} />
                </button>
              </div>
            ) : (
              <button 
                onClick={onLogin}
                className="group relative px-5 py-2 overflow-hidden rounded-sm bg-transparent border border-mk-gold/30 hover:border-mk-gold transition-colors"
              >
                <div className="absolute inset-0 w-0 bg-mk-gold transition-all duration-[250ms] ease-out group-hover:w-full opacity-10" />
                <span className="relative text-xs font-bold uppercase tracking-widest text-mk-gold flex items-center gap-2">
                  <UserIcon size={14} /> {translations.auth.login}
                </span>
              </button>
            )}
          </div>

          {/* Mobile Toggle */}
          <button 
            className="md:hidden text-white p-2"
            onClick={onMenuToggle}
          >
            <Menu size={24} />
          </button>
        </div>
      </div>
      
      {/* Decorative Line */}
      <div className="h-px w-full bg-gradient-to-r from-transparent via-mk-gold/30 to-transparent opacity-50" />
    </header>
  );
};

export default HubHeader;
