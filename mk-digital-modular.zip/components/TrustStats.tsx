
import React from 'react';
import { motion } from 'framer-motion';
import { StatItem } from '../types';

interface Props {
  stats: StatItem[];
}

const TrustStats: React.FC<Props> = ({ stats }) => {
  return (
    <section className="py-20 bg-black border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-3xl md:text-5xl font-serif text-mk-gold mb-2 font-bold">
                 {stat.value}{stat.suffix}
              </div>
              <p className="text-gray-500 text-[10px] md:text-xs uppercase tracking-[0.2em] font-bold">
                 {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustStats;
