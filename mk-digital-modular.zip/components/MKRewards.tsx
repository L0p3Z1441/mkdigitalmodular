import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Ticket, Copy, Check } from 'lucide-react';
import { CouponItem } from '../types';

interface Props {
  data: {
    title: string;
    subtitle: string;
    copy: string;
    copied: string;
    off: string;
    items: CouponItem[];
  };
}

const MKRewards: React.FC<Props> = ({ data }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section className="py-24 bg-mk-black border-t border-white/5 relative">
      <div className="container mx-auto px-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="text-center mb-16"
        >
          <div className="flex justify-center mb-4">
             <div className="p-3 bg-mk-gold/10 rounded-full border border-mk-gold/20 animate-pulse-slow">
                <Ticket className="w-8 h-8 text-mk-gold" />
             </div>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif text-white mb-4">
            {data.title}
          </h2>
          <p className="text-gray-400 text-lg font-light">
            {data.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {data.items.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="group relative bg-[#0F0F0F] border border-mk-gold/20 hover:border-mk-gold/60 transition-all duration-300 rounded-sm overflow-hidden flex flex-col"
            >
              {/* Ticket Shine */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              
              {/* Top Section */}
              <div className="p-6 text-center border-b border-dashed border-white/10 relative bg-neutral-900/30">
                 {/* Cutout circles for ticket effect */}
                 <div className="absolute -left-3 bottom-[-10px] w-6 h-6 bg-mk-black rounded-full border-r border-mk-gold/20" />
                 <div className="absolute -right-3 bottom-[-10px] w-6 h-6 bg-mk-black rounded-full border-l border-mk-gold/20" />

                 <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-2 block">{item.category}</span>
                 <div className="text-4xl font-serif text-gold-gradient font-bold mb-1">
                    {item.discount}%
                 </div>
                 <span className="text-xs font-bold text-mk-gold uppercase tracking-widest">{data.off}</span>
              </div>

              {/* Bottom Section */}
              <div className="p-6 flex flex-col items-center justify-between flex-grow">
                 <p className="text-gray-400 text-sm text-center mb-6 font-light leading-relaxed">
                    {item.description}
                 </p>

                 <button
                   onClick={() => handleCopy(item.code, item.id)}
                   className="w-full relative overflow-hidden group/btn"
                 >
                    <div className={`
                       border border-mk-gold/30 bg-black/50 py-3 px-4 rounded-sm flex items-center justify-center gap-3 transition-all duration-300
                       ${copiedId === item.id ? 'bg-mk-gold border-mk-gold text-black' : 'hover:border-mk-gold hover:bg-mk-gold/10 text-white'}
                    `}>
                       <AnimatePresence mode='wait'>
                          {copiedId === item.id ? (
                             <motion.span
                               key="copied"
                               initial={{ opacity: 0, y: 10 }}
                               animate={{ opacity: 1, y: 0 }}
                               exit={{ opacity: 0, y: -10 }}
                               className="font-bold text-xs uppercase tracking-widest flex items-center gap-2"
                             >
                                <Check size={14} /> {data.copied}
                             </motion.span>
                          ) : (
                             <motion.span
                               key="code"
                               initial={{ opacity: 0, y: 10 }}
                               animate={{ opacity: 1, y: 0 }}
                               exit={{ opacity: 0, y: -10 }}
                               className="font-mono text-sm tracking-widest flex items-center gap-2 group-hover/btn:text-mk-gold transition-colors"
                             >
                                {item.code} <Copy size={14} className="opacity-50" />
                             </motion.span>
                          )}
                       </AnimatePresence>
                    </div>
                 </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MKRewards;