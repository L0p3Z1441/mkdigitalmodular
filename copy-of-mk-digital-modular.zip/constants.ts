
import { Language, NicheId, NewsItem, PlatformReview, FrequentReview, EmployeeReview, StatItem, FaqItem, DesignSpec, RoadmapStep, GalleryImage, TextSnippets } from './types';

export const NICHE_KEYS: NicheId[] = ['marketing', 'investment', 'development', 'relationships', 'programming', 'wellness', 'spirituality'];

// OPTIMIZATION: High-performance image parameters
const IMG_PARAMS = "?auto=format&fit=crop&q=80&w=800"; 
const HERO_IMG_PARAMS = "?auto=format&fit=crop&q=80&w=1200";
const AVATAR_PARAMS = "?auto=format&fit=crop&q=80&w=150&h=150";

// RELIABLE IMAGE MAP (Updated with stable Unsplash IDs)
export const NICHE_IMAGES: Record<NicheId, string> = {
  marketing: `https://images.unsplash.com/photo-1460925895917-afdab827c52f${HERO_IMG_PARAMS}`, // Analytics/Strategy
  investment: `https://images.unsplash.com/photo-1611974765270-ca12586343bb${HERO_IMG_PARAMS}`, // Stock Market/Candles
  development: `https://images.unsplash.com/photo-1552664730-d307ca884978${HERO_IMG_PARAMS}`, // Team Strategy
  relationships: `https://images.unsplash.com/photo-1521791136064-7986c2920216${HERO_IMG_PARAMS}`, // Handshake/Connection
  programming: `https://images.unsplash.com/photo-1555066931-4365d14bab8c${HERO_IMG_PARAMS}`, // Coding/Screen
  wellness: `https://images.unsplash.com/photo-1544367563-12123d8966bf${HERO_IMG_PARAMS}`, // Yoga/Nature
  spirituality: `https://images.unsplash.com/photo-1507525428034-b723cf961d3e${HERO_IMG_PARAMS}`, // Sky/Peace
};

const SNIPPETS: Record<Language, TextSnippets> = {
  [Language.BR]: {
    navNote: "Este conteúdo não foi feito para consumo rápido. Ele foi pensado para leitura consciente, conexão de ideias e aplicação gradual.",
    expectation: "Se você busca soluções imediatas, talvez este não seja o lugar certo. Aqui as coisas funcionam no tempo real da vida.",
    rhythm: "Não existe ordem obrigatória. Você pode começar por onde fizer mais sentido agora.",
    intent: "Este projeto não ensina o que pensar, mas ajuda a organizar como pensar.",
    authority: "Conteúdo estruturado por níveis de compreensão, não por modas ou tendências.",
    maturity: "Este espaço exige responsabilidade do leitor. Nada aqui substitui decisão, ação ou consciência pessoal.",
    honesty: "Nem todo conteúdo aqui vai agradar. E isso é intencional.",
    manifesto: "Construir é mais difícil do que consumir. Por isso, a maioria desiste cedo. Este projeto existe para quem permanece.",
    transition: "Antes de avançar, vale observar em que ponto da jornada você está.",
    anchor: "Clareza precede crescimento."
  },
  [Language.US]: {
    navNote: "This content was not made for quick consumption. It was designed for conscious reading, connection of ideas, and gradual application.",
    expectation: "If you seek immediate solutions, this might not be the place. Here things work in real life time.",
    rhythm: "There is no mandatory order. You can start where it makes the most sense now.",
    intent: "This project does not teach what to think, but helps organize how to think.",
    authority: "Content structured by levels of understanding, not by fads or trends.",
    maturity: "This space demands reader responsibility. Nothing here replaces decision, action, or personal awareness.",
    honesty: "Not every content here will please you. And that is intentional.",
    manifesto: "Building is harder than consuming. That's why most give up early. This project exists for those who remain.",
    transition: "Before moving forward, it's worth observing where you are in the journey.",
    anchor: "Clarity precedes growth."
  },
  [Language.ES]: {
    navNote: "Este contenido no fue hecho para consumo rápido. Fue pensado para lectura consciente, conexión de ideas y aplicación gradual.",
    expectation: "Si buscas soluciones inmediatas, quizás este no sea el lugar. Aquí las cosas funcionan en el tiempo real de la vida.",
    rhythm: "No hay orden obligatorio. Puedes comenzar por donde tenga más sentido ahora.",
    intent: "Este proyecto no enseña qué pensar, sino que ayuda a organizar cómo pensar.",
    authority: "Contenido estructurado por niveles de comprensión, no por modas o tendencias.",
    maturity: "Este espacio exige responsabilidad del lector. Nada aquí sustituye decisión, acción o conciencia personal.",
    honesty: "No todo el contenido aquí agradará. Y eso es intencional.",
    manifesto: "Construir es más difícil que consumir. Por eso la mayoría desiste pronto. Este proyecto existe para quien permanece.",
    transition: "Antes de avanzar, vale observar en qué punto de la jornada estás.",
    anchor: "La claridad precede al crecimiento."
  }
};

const NEWS: Record<Language, NewsItem[]> = {
  [Language.BR]: [
    {
      id: "n1", date: "22 Mai 2024", category: "Mercado", title: "A Ascensão do Infoproduto Premium",
      summary: "Por que o mercado está migrando para tickets mais altos e conteúdos densos.",
      content: ["O mercado digital saturou de promessas vazias.", "A MK Digital lidera a fronteira de conteúdos que focam em aplicação prática e resultados mensuráveis.", "O novo luxo no digital é a clareza e o tempo poupado."],
      image: `https://images.unsplash.com/photo-1556761175-5973dc0f32e7${IMG_PARAMS}`, link: "#"
    },
    {
      id: "n2", date: "15 Mai 2024", category: "Tecnologia", title: "IA e a Nova Programação",
      summary: "Como a inteligência artificial está moldando o futuro dos desenvolvedores.",
      content: ["Não se trata de substituir o programador, mas de dar superpoderes a ele.", "O Nível 3 de Programação já aborda fluxos de trabalho híbridos com LLMs."],
      image: `https://images.unsplash.com/photo-1488590528505-98d2b5aba04b${IMG_PARAMS}`, link: "#"
    }
  ],
  [Language.US]: [
    {
      id: "n1", date: "May 22, 2024", category: "Market", title: "The Rise of Premium Infoproducts",
      summary: "Why the market is shifting towards higher tickets and dense content.",
      content: ["The digital market is saturated with empty promises.", "MK Digital leads the frontier of content focused on practical application and measurable results.", "The new luxury in digital is clarity and saved time."],
      image: `https://images.unsplash.com/photo-1556761175-5973dc0f32e7${IMG_PARAMS}`, link: "#"
    },
    {
      id: "n2", date: "May 15, 2024", category: "Technology", title: "AI and the New Programming",
      summary: "How artificial intelligence is shaping the future for developers.",
      content: ["It's not about replacing the programmer, but about giving them superpowers.", "Level 3 Programming already addresses hybrid workflows with LLMs."],
      image: `https://images.unsplash.com/photo-1488590528505-98d2b5aba04b${IMG_PARAMS}`, link: "#"
    }
  ],
  [Language.ES]: [
    {
      id: "n1", date: "22 May 2024", category: "Mercado", title: "El Ascenso del Infoproducto Premium",
      summary: "Por qué el mercado está migrando hacia tickets más altos y contenidos densos.",
      content: ["El mercado digital se saturó de promesas vacías.", "MK Digital lidera la frontera de contenidos enfocados en aplicación práctica y resultados medibles.", "El nuevo lujo en lo digital es la claridad y el tiempo ahorrado."],
      image: `https://images.unsplash.com/photo-1556761175-5973dc0f32e7${IMG_PARAMS}`, link: "#"
    },
    {
      id: "n2", date: "15 May 2024", category: "Tecnología", title: "IA y la Nueva Programación",
      summary: "Cómo la inteligencia artificial está moldeando el futuro de los desarrolladores.",
      content: ["No se trata de reemplazar al desarrollador, sino de darle superpoderes.", "El Nivel 3 de Programação ya aborda flujos de trabajo híbridos con LLMs."],
      image: `https://images.unsplash.com/photo-1488590528505-98d2b5aba04b${IMG_PARAMS}`, link: "#"
    }
  ]
};

const ROADMAP: Record<Language, RoadmapStep[]> = {
  [Language.BR]: [
    { period: "Q1 2024", title: "Expansão Ibérica", description: "Lançamento oficial da MK Espanha com conteúdos localizados.", status: "completed" },
    { period: "Q3 2024", title: "App MK Mobile", description: "Nova experiência nativa para leitura offline e interativa.", status: "current" },
    { period: "Q1 2025", title: "MK Mastermind", description: "Encontros presenciais de elite para membros Nível 3.", status: "future" }
  ],
  [Language.US]: [
    { period: "Q1 2024", title: "Iberian Expansion", description: "Official launch of MK Spain with localized content.", status: "completed" },
    { period: "Q3 2024", title: "MK Mobile App", description: "New native experience for offline and interactive reading.", status: "current" },
    { period: "Q1 2025", title: "MK Mastermind", description: "Elite in-person meetings for Level 3 members.", status: "future" }
  ],
  [Language.ES]: [
    { period: "Q1 2024", title: "Expansión Ibérica", description: "Lanzamiento oficial de MK España con contenido localizado.", status: "completed" },
    { period: "Q3 2024", title: "App MK Mobile", description: "Nueva experiencia nativa para lectura offline e interactiva.", status: "current" },
    { period: "Q1 2025", title: "MK Mastermind", description: "Encuentros presenciales de élite para miembros de Nivel 3.", status: "future" }
  ]
};

const GALLERY: Record<Language, GalleryImage[]> = {
  [Language.BR]: [
    { id: "g1", title: "Design de Elite", image: `https://images.unsplash.com/photo-1507238691740-187a5b1d37b8${IMG_PARAMS}`, description: "Diagramação pensada para foco profundo." },
    { id: "g2", title: "Gráficos de Escala", image: `https://images.unsplash.com/photo-1551288049-bbbda536339a${IMG_PARAMS}`, description: "Visualização de dados para clareza estratégica." },
    { id: "g3", title: "Checklists de Execução", image: `https://images.unsplash.com/photo-1454165804606-c3d57bc86b40${IMG_PARAMS}`, description: "Passo a passo prático para resultados rápidos." }
  ],
  [Language.US]: [
    { id: "g1", title: "Elite Design", image: `https://images.unsplash.com/photo-1507238691740-187a5b1d37b8${IMG_PARAMS}`, description: "Layout designed for deep focus." },
    { id: "g2", title: "Scale Graphics", image: `https://images.unsplash.com/photo-1551288049-bbbda536339a${IMG_PARAMS}`, description: "Data visualization for strategic clarity." },
    { id: "g3", title: "Execution Checklists", image: `https://images.unsplash.com/photo-1454165804606-c3d57bc86b40${IMG_PARAMS}`, description: "Practical step-by-step for quick results." }
  ],
  [Language.ES]: [
    { id: "g1", title: "Diseño de Élite", image: `https://images.unsplash.com/photo-1507238691740-187a5b1d37b8${IMG_PARAMS}`, description: "Maquetación diseñada para un enfoque profundo." },
    { id: "g2", title: "Gráficos de Escala", image: `https://images.unsplash.com/photo-1551288049-bbbda536339a${IMG_PARAMS}`, description: "Visualización de datos para claridad estratégica." },
    { id: "g3", title: "Listas de Ejecución", image: `https://images.unsplash.com/photo-1454165804606-c3d57bc86b40${IMG_PARAMS}`, description: "Paso a paso práctico para resultados rápidos." }
  ]
};

const STATS: Record<Language, StatItem[]> = {
  [Language.BR]: [
    { label: "Alunos Ativos", value: "54", suffix: "k+" },
    { label: "Países Alcançados", value: "12", suffix: "" },
    { label: "Conteúdo Prático", value: "800", suffix: "h+" },
    { label: "Nível de Satisfação", value: "98", suffix: "%" }
  ],
  [Language.US]: [
    { label: "Active Students", value: "54", suffix: "k+" },
    { label: "Countries Reached", value: "12", suffix: "" },
    { label: "Practical Content", value: "800", suffix: "h+" },
    { label: "Satisfaction Level", value: "98", suffix: "%" }
  ],
  [Language.ES]: [
    { label: "Alumnos Activos", value: "54", suffix: "k+" },
    { label: "Países Alcanzados", value: "12", suffix: "" },
    { label: "Contenido Práctico", value: "800", suffix: "h+" },
    { label: "Nivel de Satisfacción", value: "98", suffix: "%" }
  ]
};

const DESIGN_SPECS: Record<Language, DesignSpec[]> = {
  [Language.BR]: [
    { title: "Tipografia", description: "Uso de Serifas para autoridade e Sans-serif para legibilidade moderna.", value: "Inter & Playfair" },
    { title: "Cromatismo", description: "Ouro para exclusividade e Vermelho para urgência estratégica.", value: "#D4AF37, #8A0F0F" },
    { title: "Geometria", description: "Grid de 12 colunas com espaçamentos amplos.", value: "Minimalist Grid" }
  ],
  [Language.US]: [
    { title: "Typography", description: "Use of Serifs for authority and Sans-serif for modern readability.", value: "Inter & Playfair" },
    { title: "Chromatism", description: "Gold for exclusivity and Red for strategic urgency.", value: "#D4AF37, #8A0F0F" },
    { title: "Geometry", description: "12-column grid with wide spacing.", value: "Minimalist Grid" }
  ],
  [Language.ES]: [
    { title: "Tipografía", description: "Uso de Serifas para autoridad y Sans-serif para legibilidad moderna.", value: "Inter & Playfair" },
    { title: "Cromatismo", description: "Oro para exclusividad y Rojo para urgencia estratégica.", value: "#D4AF37, #8A0F0F" },
    { title: "Geometría", description: "Cuadrícula de 12 columnas con espacios amplios.", value: "Minimalist Grid" }
  ]
};

const EMPLOYEES: Record<Language, EmployeeReview[]> = {
  [Language.BR]: [
    { id: "e1", name: "Carlos Eduardo", text: "Trabalhar na MK foi um divisor de águas. A cultura de excelência não é apenas um slide, é o que entregamos em cada página que o aluno lê.", formerRole: "Senior UI Designer", currentRole: "Diretor de Arte @ V-Studios" },
    { id: "e2", name: "Beatriz Ferro", text: "O rigor que aplicamos nos eBooks é o que nos diferencia. Na MK, 'bom o suficiente' nunca foi aceito. Buscamos a perfeição técnica.", formerRole: "Head of Copy", currentRole: "CMO @ Fintech Global" },
    { id: "e3", name: "Jean Marcondes", text: "Aprendi que o design estratégico é a base de qualquer venda de alto ticket. A MK me deu essa visão 360 do mercado digital.", formerRole: "Lead Developer", currentRole: "CTO @ EdTech Unicorn" },
    { id: "e4", name: "Letícia Antunes", text: "A obsessão por dados e pesquisas reais por trás de cada parágrafo é o que torna os produtos MK inigualáveis no mercado.", formerRole: "Research Analyst", currentRole: "Estrategista Chefe @ MkLab" },
    { id: "e5", name: "Gabriel Siqueira", text: "Nossa missão é transformar informação bruta em conhecimento acionável. É gratificante ver o impacto real na vida dos alunos.", formerRole: "Content Manager", currentRole: "Head de Produto @ MK" },
    { id: "e6", name: "Sophia Mendes", text: "Aqui, unimos psicologia comportamental e design premium. O resultado é uma experiência de aprendizado sem atritos.", formerRole: "UX Researcher", currentRole: "Consultora de Experiência @ DigitalFlow" }
  ],
  [Language.US]: [
    { id: "e1", name: "Charles Edward", text: "Working at MK was a game-changer. The culture of excellence isn't just a slide; it's what we deliver on every page.", formerRole: "Senior UI Designer", currentRole: "Art Director @ V-Studios" },
    { id: "e2", name: "Beatrice Ferro", text: "The rigor we apply to the eBooks is what sets us apart. At MK, 'good enough' was never accepted.", formerRole: "Head of Copy", currentRole: "CMO @ Fintech Global" },
    { id: "e3", name: "John Marcondes", text: "I learned that strategic design is the basis of any high-ticket sale. MK gave me that 360 vision.", formerRole: "Lead Developer", currentRole: "CTO @ EdTech Unicorn" },
    { id: "e4", name: "Laetitia Antunes", text: "The obsession with data and real research behind every paragraph makes MK products unrivaled.", formerRole: "Research Analyst", currentRole: "Chief Strategist @ MkLab" },
    { id: "e5", name: "Gabriel Siqueira", text: "Our mission is to transform raw information into actionable knowledge.", formerRole: "Content Manager", currentRole: "Head of Product @ MK" },
    { id: "e6", name: "Sophia Mendes", text: "Here, we combine behavioral psychology and premium design for a frictionless experience.", formerRole: "UX Researcher", currentRole: "Experience Consultant @ DigitalFlow" }
  ],
  [Language.ES]: [
    { id: "e1", name: "Carlos Eduardo", text: "Trabajar en MK fue un antes y un después. La cultura de excelencia es lo que entregamos en cada página.", formerRole: "Senior UI Designer", currentRole: "Director de Arte @ V-Studios" },
    { id: "e2", name: "Beatriz Ferro", text: "El rigor que aplicamos en los eBooks es lo que nos diferencia. En MK, 'suficientemente bueno' nunca se aceptó.", formerRole: "Head of Copy", currentRole: "CMO @ Fintech Global" },
    { id: "e3", name: "Juan Marcondes", text: "Aprendí que el diseño estratégico es la base de cualquier venda de alto ticket. MK me dio esa visión 360.", formerRole: "Lead Developer", currentRole: "CTO @ EdTech Unicorn" },
    { id: "e4", name: "Leticia Antunes", text: "La obsesión por los datos y las investigaciones reales detrás de cada párrafo es lo que hace a los productos MK únicos.", formerRole: "Research Analyst", currentRole: "Estratega Jefe @ MkLab" },
    { id: "e5", name: "Gabriel Siqueira", text: "Nuestra misión es transformar información bruta en conocimiento accionable.", formerRole: "Content Manager", currentRole: "Jefe de Producto @ MK" },
    { id: "e6", name: "Sofía Mendes", text: "Aquí, unimos psicología conductual y diseño premium para una experiencia sin fricciones.", formerRole: "UX Researcher", currentRole: "Consultora de Experiencia @ DigitalFlow" }
  ]
};

const FAQ: Record<Language, FaqItem[]> = {
  [Language.BR]: [
    { category: "Geral", question: "Isso é curso, mentoria ou o quê?", answer: "Nenhum dos três no formato tradicional. É um ecossistema de conteúdo estruturado que guia a pessoa por níveis de maturidade. Você aprende enquanto avança, não antes de agir." },
    { category: "Geral", question: "Isso funciona pra iniciantes?", answer: "Funciona justamente porque respeita iniciantes. O erro comum é jogar estratégia avançada pra quem ainda está no nível de consciência. Aqui cada coisa aparece no tempo certo." },
    { category: "Geral", question: "Preciso saber muito antes de começar?", answer: "Não. Precisa só de disposição pra aprender sem pular etapas. O sistema foi feito pra quem começa perdido e ganha clareza com o tempo." },
    { category: "Geral", question: "Isso serve pra quem já tentou e falhou?", answer: "Principalmente. A maioria falha não por falta de esforço, mas por falta de estrutura. O conteúdo parte exatamente desse ponto." },
    
    { category: "Marketing", question: "Marketing digital ainda funciona ou já saturou?", answer: "Funciona, mas não do jeito romantizado. O que saturou foi a ilusão de dinheiro fácil. Estrutura, clareza e constância continuam funcionando." },
    { category: "Marketing", question: "Preciso aparecer em redes sociais?", answer: "Não necessariamente. O ecossistema trabalha com conteúdo, hubs e intenção. Aparição é ferramenta, não obrigação." },
    { category: "Marketing", question: "Dá pra fazer isso com pouco dinheiro?", answer: "Sim. A lógica começa com estrutura e conhecimento. Tráfego pago só entra quando faz sentido estratégico." },
    { category: "Marketing", question: "Isso é afiliado, dropshipping ou agência?", answer: "Pode se conectar com tudo isso, mas não depende de nenhum modelo específico. Primeiro vem o entendimento do jogo, depois a escolha do veículo." },

    { category: "Investimentos", question: "Investir é arriscado?", answer: "É arriscado quando feito sem consciência. Aqui o foco inicial não é ganhar muito, é parar de perder." },
    { category: "Investimentos", question: "Preciso ter muito dinheiro pra investir?", answer: "Não. Precisa ter mentalidade. Valores baixos já ensinam disciplina, visão de longo prazo e controle emocional." },
    { category: "Investimentos", question: "Vocês prometem retorno financeiro?", answer: "Não. Promessa de retorno é sinal de problema. O que existe aqui é construção de base, gestão de risco e clareza." },
    { category: "Investimentos", question: "Isso é só pra quem quer ficar rico?", answer: "Não. É pra quem quer parar de ser refém financeiro e tomar decisões melhores ao longo da vida." },

    { category: "Desenvolvimento", question: "Isso é motivação?", answer: "Não. Motivação passa. O foco aqui é identidade, hábito e consistência." },
    { category: "Desenvolvimento", question: "Vai mexer com a mente da pessoa?", answer: "Vai organizar, não manipular. Autoconhecimento é ferramenta, não lavagem cerebral." },
    { category: "Desenvolvimento", question: "Serve pra quem está desanimado ou perdido?", answer: "Sim. O sistema não parte do 'seja incrível', mas do 'entenda onde você está'." },

    { category: "Relacionamentos", question: "Isso ensina a conquistar pessoas?", answer: "Não no sentido raso. Ensina maturidade emocional, comunicação e limites. Conquista sem base vira dependência." },
    { category: "Relacionamentos", question: "Serve pra quem está solteiro e pra quem está em relacionamento?", answer: "Sim. Relacionamento começa consigo mesmo. O estado civil não muda isso." },
    { category: "Relacionamentos", question: "Tem viés de gênero ou ideologia?", answer: "Não. O foco é responsabilidade emocional e construção saudável, não narrativa pronta." },

    { category: "Programação", question: "Preciso ser bom em matemática pra programar?", answer: "Não. Precisa aprender a pensar de forma estruturada. A matemática vem depois, se precisar." },
    { category: "Programação", question: "Isso é só pra quem quer virar dev profissional?", answer: "Não. Programação aqui é ferramenta de poder mental, automação e liberdade — mesmo fora da carreira tradicional." },
    { category: "Programação", question: "Tem IA envolvida?", answer: "Sim, mas como ferramenta estratégica, não como atalho mágico." },

    { category: "Bem-estar", question: "Isso é sobre dieta, treino ou saúde mental?", answer: "É sobre base. Dormir, comer, se mover e respirar bem vêm antes de qualquer método sofisticado." },
    { category: "Bem-estar", question: "Promete felicidade?", answer: "Não. Promete menos caos, mais clareza e mais energia pra lidar com a vida real." },

    { category: "Espiritualidade", question: "Isso é ligado a alguma religião específica?", answer: "Não. Respeita todas. O foco é espiritualidade madura, não dogma." },
    { category: "Espiritualidade", question: "Vai tentar converter alguém?", answer: "Não. A proposta é reflexão, sentido e ética — não imposição." },
    { category: "Espiritualidade", question: "Mistura espiritualidade com dinheiro e sucesso?", answer: "Mistura com responsabilidade. Espiritualidade aqui não é fuga da realidade, é profundidade para lidar com ela." },

    { category: "Tempo & Ritmo", question: "Em quanto tempo vejo resultados?", answer: "Depende do que você chama de resultado. Clareza vem rápido. Construção leva tempo. E isso é assumido desde o início." },
    { category: "Tempo & Ritmo", question: "Preciso consumir tudo de uma vez?", answer: "Não. O sistema foi feito pra ser explorado no ritmo da pessoa. Pressa aqui atrapalha." },
    { category: "Tempo & Ritmo", question: "Isso é pra vida toda?", answer: "É pra fases. Cada nível cumpre seu papel. O objetivo não é dependência, é autonomia." },
  ],
  [Language.US]: [
    { category: "General", question: "Is this a course, mentorship, or what?", answer: "None of the three in the traditional format. It's an ecosystem of structured content guiding you through maturity levels. You learn as you advance, not before acting." },
    { category: "General", question: "Does this work for beginners?", answer: "It works precisely because it respects beginners. A common mistake is throwing advanced strategy at someone still building awareness. Here, everything appears at the right time." },
    { category: "General", question: "Do I need to know a lot before starting?", answer: "No. You only need the willingness to learn without skipping steps. The system is designed for those who start lost and gain clarity over time." },
    { category: "General", question: "Is this for those who have tried and failed?", answer: "Especially. Most fail not due to lack of effort, but lack of structure. The content starts exactly from this point." },

    { category: "Marketing", question: "Does digital marketing still work or is it saturated?", answer: "It works, but not in the romanticized way. What saturated was the illusion of easy money. Structure, clarity, and consistency still work." },
    { category: "Marketing", question: "Do I need to appear on social media?", answer: "Not necessarily. The ecosystem works with content, hubs, and intent. Appearing is a tool, not an obligation." },
    { category: "Marketing", question: "Can I do this with little money?", answer: "Yes. Logic starts with structure and knowledge. Paid traffic only enters when it makes strategic sense." },
    { category: "Marketing", question: "Is this affiliate, dropshipping, or agency?", answer: "It can connect with all of these, but relies on no specific model. First comes understanding the game, then choosing the vehicle." },

    { category: "Investment", question: "Is investing risky?", answer: "It's risky when done without awareness. Here, the initial focus isn't earning a lot, but stopping losses." },
    { category: "Investment", question: "Do I need a lot of money to invest?", answer: "No. You need mindset. Small amounts teach discipline, long-term vision, and emotional control." },
    { category: "Investment", question: "Do you promise financial returns?", answer: "No. Promises of returns are a red flag. What exists here is foundation building, risk management, and clarity." },
    { category: "Investment", question: "Is this only for those wanting to get rich?", answer: "No. It's for those wanting to stop being financial hostages and make better decisions throughout life." },

    { category: "Development", question: "Is this motivation?", answer: "No. Motivation passes. The focus here is identity, habit, and consistency." },
    { category: "Development", question: "Will it mess with my mind?", answer: "It will organize, not manipulate. Self-knowledge is a tool, not brainwashing." },
    { category: "Development", question: "Is it for those discouraged or lost?", answer: "Yes. The system doesn't start from 'be amazing', but from 'understand where you are'." },

    { category: "Relationships", question: "Does this teach how to win people over?", answer: "Not in a shallow sense. It teaches emotional maturity, communication, and boundaries. Winning over without a base becomes dependency." },
    { category: "Relationships", question: "Is it for singles or those in relationships?", answer: "Yes. Relationship starts with oneself. Marital status doesn't change that." },
    { category: "Relationships", question: "Is there gender bias or ideology?", answer: "No. The focus is emotional responsibility and healthy construction, not ready-made narratives." },

    { category: "Programming", question: "Do I need to be good at math to program?", answer: "No. You need to learn to think in a structured way. Math comes later, if needed." },
    { category: "Programming", question: "Is this only for those wanting to be pro devs?", answer: "No. Programming here is a tool for mental power, automation, and freedom — even outside traditional careers." },
    { category: "Programming", question: "Is AI involved?", answer: "Yes, but as a strategic tool, not a magic shortcut." },

    { category: "Wellness", question: "Is this about diet, workout, or mental health?", answer: "It's about base. Sleeping, eating, moving, and breathing well come before any sophisticated method." },
    { category: "Wellness", question: "Does it promise happiness?", answer: "No. It promises less chaos, more clarity, and more energy to deal with real life." },

    { category: "Spirituality", question: "Is this linked to a specific religion?", answer: "No. It respects all. The focus is mature spirituality, not dogma." },
    { category: "Spirituality", question: "Will you try to convert anyone?", answer: "No. The proposal is reflection, meaning, and ethics — not imposition." },
    { category: "Spirituality", question: "Does it mix spirituality with money and success?", answer: "It mixes with responsibility. Spirituality here isn't an escape from reality, it's depth to deal with it." },

    { category: "Time & Pace", question: "How soon will I see results?", answer: "Depends on what you call results. Clarity comes fast. Construction takes time. And this is assumed from the start." },
    { category: "Time & Pace", question: "Do I need to consume everything at once?", answer: "No. The system was made to be explored at your pace. Haste here hinders." },
    { category: "Time & Pace", question: "Is this for life?", answer: "It's for phases. Each level fulfills its role. The goal isn't dependency, it's autonomy." },
  ],
  [Language.ES]: [
    { category: "General", question: "¿Es esto un curso, mentoría o qué?", answer: "Ninguno de los tres en formato tradicional. Es un ecosistema de contenido estructurado que guía por niveles de madurez. Aprendes mientras avanzas, no antes de actuar." },
    { category: "General", question: "¿Funciona para principiantes?", answer: "Funciona justamente porque respeta a los principiantes. El error común es lanzar estrategia avanzada a quien aún está en nivel de consciencia. Aquí cada cosa aparece en su tiempo." },
    { category: "General", question: "¿Necesito saber mucho antes de empezar?", answer: "No. Solo necesitas disposición para aprender sin saltar etapas. El sistema está hecho para quien empieza perdido y gana claridad con el tiempo." },
    { category: "General", question: "¿Sirve para quien ya intentó y falló?", answer: "Principalmente. La mayoría falla no por falta de esfuerzo, sino por falta de estructura. El contenido parte exactamente de ese punto." },

    { category: "Marketing", question: "¿El marketing digital aún funciona o ya saturó?", answer: "Funciona, pero no de la forma romántica. Lo que saturó fue la ilusión de dinero fácil. Estructura, claridad y constancia siguen funcionando." },
    { category: "Marketing", question: "¿Necesito aparecer en redes sociales?", answer: "No necesariamente. El ecosistema trabaja con contenido, hubs e intención. Aparecer es herramienta, no obligación." },
    { category: "Marketing", question: "¿Se puede hacer con poco dinero?", answer: "Sí. La lógica empieza con estructura y conocimiento. El tráfico pago solo entra cuando tiene sentido estratégico." },
    { category: "Marketing", question: "¿Es afiliado, dropshipping o agencia?", answer: "Puede conectarse con todo eso, pero no depende de ningún modelo específico. Primero viene el entendimiento del juego, luego la elección del vehículo." },

    { category: "Inversiones", question: "¿Invertir es arriesgado?", answer: "Es arriesgado cuando se hace sin consciencia. Aquí el foco inicial no es ganar mucho, es dejar de perder." },
    { category: "Inversiones", question: "¿Necesito mucho dinero para invertir?", answer: "No. Necesitas mentalidad. Valores bajos ya enseñan disciplina, visión a largo plazo y control emocional." },
    { category: "Inversiones", question: "¿Prometen retorno financiero?", answer: "No. Promesa de retorno es señal de problema. Lo que existe aquí es construcción de base, gestión de riesgo y claridad." },
    { category: "Inversiones", question: "¿Es solo para quien quiere ser rico?", answer: "No. Es para quien quiere dejar de ser rehén financiero y tomar mejores decisiones a lo largo de la vida." },

    { category: "Desarrollo", question: "¿Es motivación?", answer: "No. La motivación pasa. El foco aquí es identidad, hábito e identidad." },
    { category: "Desarrollo", question: "¿Van a manipular mi mente?", answer: "Va a organizar, no manipular. Autoconocimiento es herramienta, no lavado de cerebro." },
    { category: "Desarrollo", question: "¿Sirve para quien está desanimado o perdido?", answer: "Sí. El sistema no parte del 'sé increíble', sino del 'entiende dónde estás'." },

    { category: "Relaciones", question: "¿Enseña a conquistar personas?", answer: "No en sentido superficial. Enseña madurez emocional, comunicación y límites. Conquista sin base se vuelve dependencia." },
    { category: "Relaciones", question: "¿Sirve para solteros y para quienes están en relación?", answer: "Sí. La relación empieza con uno mismo. El estado civil no cambia eso." },
    { category: "Relaciones", question: "¿Tiene sesgo de género o ideología?", answer: "No. El foco es responsabilidad emocional y construcción sana, no narrativa prefabricada." },

    { category: "Programación", question: "¿Necesito ser bueno en matemáticas para programar?", answer: "No. Necesitas aprender a pensar de forma estructurada. Las matemáticas vienen después, si se necesitan." },
    { category: "Programación", question: "¿Es solo para quien quiere ser dev profesional?", answer: "No. La programación aquí es herramienta de poder mental, automatización y libertad — incluso fuera de la carrera tradicional." },
    { category: "Programación", question: "¿Hay IA involucrada?", answer: "Sí, pero como herramienta estratégica, no como atajo mágico." },

    { category: "Bienestar", question: "¿Es sobre dieta, entreno o salud mental?", answer: "Es sobre base. Dormir, comer, moverse y respirar bien vienen antes de cualquier método sofisticado." },
    { category: "Bienestar", question: "¿Promete felicidad?", answer: "No. Promete menos caos, más claridad y más energía para lidiar con la vida real." },

    { category: "Espiritualidad", question: "¿Está ligado a alguna religión específica?", answer: "No. Respeta todas. El foco es espiritualidad madura, no dogma." },
    { category: "Espiritualidad", question: "¿Intentarán convertir a alguien?", answer: "No. La propuesta es reflexión, sentido y ética — no imposición." },
    { category: "Espiritualidad", question: "¿Mezcla espiritualidad con dinero y éxito?", answer: "Mezcla con responsabilidad. Espiritualidad aquí no es fuga de la realidad, es profundidad para lidiar con ella." },

    { category: "Tiempo & Ritmo", question: "¿En cuánto tiempo veo resultados?", answer: "Depende de lo que llames resultado. La claridad viene rápido. La construcción lleva tiempo. Y eso se asume desde el inicio." },
    { category: "Tiempo & Ritmo", question: "¿Necesito consumir todo de una vez?", answer: "No. El sistema fue hecho para ser explorado a tu ritmo. La prisa aquí estorba." },
    { category: "Tiempo & Ritmo", question: "¿Es para toda la vida?", answer: "Es por fases. Cada nivel cumple su papel. El objetivo no es dependencia, es autonomía." },
  ]
};

const PLATFORM_FEEDBACK: Record<Language, PlatformReview[]> = {
  [Language.BR]: [
    { id: "p1", text: "A MK Digital redefiniu o padrão de infoprodutos. A profundidade técnica combinada com a experiência de usuário é incomparável no mercado atual.", author: "Ricardo Silva", role: "CEO @ TechFlow" },
    { id: "p2", text: "Não é apenas conteúdo, é uma arquitetura de aprendizado. A progressão por níveis elimina a ansiedade de informação que paralisa a maioria dos estudantes.", author: "Amanda Costa", role: "Diretora de Ensino" },
    { id: "p3", text: "O design do ecossistema reflete a qualidade do conhecimento. Clareza visual que se traduz em clareza mental para execução estratégica.", author: "Pedro Alencar", role: "Designer Sênior" }
  ],
  [Language.US]: [
    { id: "p1", text: "MK Digital has redefined the standard for infoproducts. The technical depth combined with the user experience is unrivaled in the current market.", author: "Richard Silva", role: "CEO @ TechFlow" },
    { id: "p2", text: "It's not just content, it's a learning architecture. Level progression eliminates the information overload that paralyzes most students.", author: "Amanda Costa", role: "Education Director" },
    { id: "p3", text: "The ecosystem design reflects the quality of knowledge. Visual clarity translating into mental clarity for strategic execution.", author: "Peter Alencar", role: "Senior Designer" }
  ],
  [Language.ES]: [
    { id: "p1", text: "MK Digital ha redefinido el estándar de infoproductos. La profundidad técnica combinada con la experiencia de usuario no tiene rival en el mercado actual.", author: "Ricardo Silva", role: "CEO @ TechFlow" },
    { id: "p2", text: "No es solo contenido, es una arquitectura de aprendizaje. La progresión por niveles elimina la ansiedad de información que paraliza a la mayoría.", author: "Amanda Costa", role: "Directora de Educación" },
    { id: "p3", text: "El diseño del ecosistema refleja la calidad del conocimiento. Claridad visual que se traduce en claridad mental para la ejecución estratégica.", author: "Pedro Alencar", role: "Diseñador Senior" }
  ]
};

const FREQUENT: Record<Language, FrequentReview[]> = {
  [Language.BR]: [
    { id: "f1", name: "Lucas M.", avatar: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d${AVATAR_PARAMS}`, rating: 5, text: "O Nível 3 de Investimentos mudou minha vida financeira em 6 meses.", memberStatus: 'Black', purchaseCount: 12 },
    { id: "f2", name: "Júlia R.", avatar: `https://images.unsplash.com/photo-1494790108377-be9c29b29330${AVATAR_PARAMS}`, rating: 5, text: "Conteúdo denso, sem enrolação. Programação avançada aplicada à realidade.", memberStatus: 'Gold', purchaseCount: 5 },
    { id: "f3", name: "Marcos T.", avatar: `https://images.unsplash.com/photo-1500648767791-00dcc994a43e${AVATAR_PARAMS}`, rating: 5, text: "A melhor plataforma de ensino que já usei. Design e didática perfeitos.", memberStatus: 'Platinum', purchaseCount: 8 }
  ],
  [Language.US]: [
    { id: "f1", name: "Lucas M.", avatar: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d${AVATAR_PARAMS}`, rating: 5, text: "Level 3 Investment changed my financial life in 6 months.", memberStatus: 'Black', purchaseCount: 12 },
    { id: "f2", name: "Julia R.", avatar: `https://images.unsplash.com/photo-1494790108377-be9c29b29330${AVATAR_PARAMS}`, rating: 5, text: "Dense content, no fluff. Advanced programming applied to reality.", memberStatus: 'Gold', purchaseCount: 5 },
    { id: "f3", name: "Mark T.", avatar: `https://images.unsplash.com/photo-1500648767791-00dcc994a43e${AVATAR_PARAMS}`, rating: 5, text: "The best teaching platform I've ever used. Perfect design and didactics.", memberStatus: 'Platinum', purchaseCount: 8 }
  ],
  [Language.ES]: [
    { id: "f1", name: "Lucas M.", avatar: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d${AVATAR_PARAMS}`, rating: 5, text: "El Nivel 3 de Inversiones cambió mi vida financiera en 6 meses.", memberStatus: 'Black', purchaseCount: 12 },
    { id: "f2", name: "Julia R.", avatar: `https://images.unsplash.com/photo-1494790108377-be9c29b29330${AVATAR_PARAMS}`, rating: 5, text: "Contenido denso, sin rodeos. Programación avanzada aplicada a la realidad.", memberStatus: 'Gold', purchaseCount: 5 },
    { id: "f3", name: "Marcos T.", avatar: `https://images.unsplash.com/photo-1500648767791-00dcc994a43e${AVATAR_PARAMS}`, rating: 5, text: "La mejor plataforma de enseñanza que he usado. Diseño y didáctica perfectos.", memberStatus: 'Platinum', purchaseCount: 8 }
  ]
};

export const CONTENT: Record<Language, any> = {
  [Language.BR]: {
    hero: { subtitle: "A elite do conhecimento digital. eBooks estruturados para sua ascensão estratégica.", cta: "Explorar Acervo", microcopy: "Design de Próxima Geração. Conteúdo Elite." },
    snippets: SNIPPETS[Language.BR],
    about: { title: "Arquitetura do Saber", description: "Não vendemos apenas informação; entregamos caminhos modulados para o sucesso real. Nossa metodologia é baseada em 3 níveis de profundidade técnica." },
    stats: STATS[Language.BR],
    design: { title: "Design Language", subtitle: "A estética do conhecimento.", specs: DESIGN_SPECS[Language.BR] },
    roadmap: { title: "MK Vision 2025", subtitle: "Nossa jornada rumo à hegemonia digital.", items: ROADMAP[Language.BR] },
    gallery: { title: "Por Dentro da Elite", subtitle: "Uma prévia da experiência visual MK.", items: GALLERY[Language.BR] },
    manifesto: { title: "Nossa Filosofia", text: ["Cada pixel foi desenhado para inspirar foco profundo.", "Beleza é a porta de entrada para a disciplina.", "Conhecimento sem execução é apenas ruído."] },
    news: { title: "MK Insights", subtitle: "As fronteiras do mercado digital e tecnologia.", readMore: "Ver Artigo", close: "Voltar", items: NEWS[Language.BR] },
    niches: { title: "Domínios de Conhecimento", items: { marketing: "Marketing", investment: "Investimentos", development: "Desenvolvimento", relationships: "Relacionamentos", programming: "Programação", wellness: "Bem-estar", spirituality: "Religião" } },
    nicheDetails: {
      marketing: { 
        description: "Domine a arte da persuasão, tráfego pago e escala global de vendas.", 
        checkoutLinks: { level1: "https://pay.kiwify.com.br/RnRSJIq", level2: "https://pay.kiwify.com.br/t5OEhod", level3: "https://pay.kiwify.com.br/AD5paHG" }, 
        reviews: [
          { id: "r1", name: "Fernando M.", rating: 5, text: "O nível 3 é absurdo. Apliquei os funis e o ROI subiu 40%.", avatar: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d${AVATAR_PARAMS}` },
          { id: "r2", name: "Carla S.", rating: 5, text: "Diagramação impecável. Finalmente um conteúdo que não cansa a vista.", avatar: `https://images.unsplash.com/photo-1494790108377-be9c29b29330${AVATAR_PARAMS}` }
        ] 
      },
      investment: { description: "Estratégias de preservação, gestão de risco e multiplicação de capital.", checkoutLinks: { level1: "https://pay.kiwify.com.br/jRvpJlF", level2: "https://pay.kiwify.com.br/At9Lbif", level3: "https://pay.kiwify.com.br/luVuvQR" }, reviews: [] },
      development: { description: "Alta performance, liderança e a ciência da produtividade extrema.", checkoutLinks: { level1: "https://pay.kiwify.com.br/KjpJqYi", level2: "https://pay.kiwify.com.br/5Ho4VEQ", level3: "https://pay.kiwify.com.br/dpKoaeI" }, reviews: [] },
      relationships: { description: "Dinâmicas sociais, comunicação e inteligência emocional avançada.", checkoutLinks: { level1: "https://pay.kiwify.com.br/salH47P", level2: "https://pay.kiwify.com.br/5rXGBDc", level3: "https://pay.kiwify.com.br/HUn0NMn" }, reviews: [] },
      programming: { description: "Lógica de elite, arquiteturas modernas e desenvolvimento fullstack.", checkoutLinks: { level1: "https://pay.kiwify.com.br/ZBCveai", level2: "https://pay.kiwify.com.br/0ubQj2y", level3: "https://pay.kiwify.com.br/HE1axTm" }, reviews: [] },
      wellness: { description: "Biohacking, saúde otimizada para performance e longevidade.", checkoutLinks: { level1: "https://pay.kiwify.com.br/lgdx0rv", level2: "https://pay.kiwify.com.br/lNTd9aj", level3: "https://pay.kiwify.com.br/TitYvFn" }, reviews: [] },
      spirituality: { description: "Paz interior, clareza de propósito e fundamentos da fé cristã.", checkoutLinks: { level1: "https://pay.kiwify.com.br/CZVysE4", level2: "https://pay.kiwify.com.br/Q9vSjrC", level3: "https://pay.kiwify.com.br/43kdm8L" }, reviews: [] },
    },
    products: { currency: "R$", buy: "Adquirir Agora", back: "Voltar", levels: { beginner: "Iniciante", intermediate: "Intermediário", advanced: "Avançado" }, prices: { level1: "299", level2: "299", level3: "299" } },
    evolution: { title: "Curva de Maestria", mastery: "domínio" },
    faq: { title: "Centro de Suporte", items: FAQ[Language.BR] },
    auth: { login: "Acessar", register: "Criar Conta", logout: "Sair", welcome: "Olá,", namePlaceholder: "Nome", emailPlaceholder: "E-mail", passwordPlaceholder: "Senha", submitLogin: "Entrar", submitRegister: "Registrar", switchToRegister: "Novo? Criar conta", switchToLogin: "Membro? Entrar", country: "País", error: "Acesso negado." },
    footer: { rights: "MK Digital Platform. Referência em Infoprodutos Premium.", contact: "contato@mkdigital.com" },
    platformReviews: { title: "Feedback Crítico", items: PLATFORM_FEEDBACK[Language.BR] },
    frequentReviews: { title: "Vozes da Elite", subtitle: "O que dizem os membros que alcançaram o Nível 3.", items: FREQUENT[Language.BR] },
    careers: { title: "Cultura & Legado", subtitle: "Vozes de quem ajudou a construir nossa excelência.", items: EMPLOYEES[Language.BR] },
    marketplace: { searchPlaceholder: "O que você quer dominar hoje?", departments: "Departamentos", all: "Todos", results: "eBooks", bestSeller: "Mais Vendido", addToCart: "Comprar", noResults: "Nada encontrado." }
  },
  [Language.US]: {
    hero: { subtitle: "The elite of digital knowledge. eBooks structured for your strategic rise.", cta: "Explore Collection", microcopy: "Next-Gen Design. Elite Content." },
    snippets: SNIPPETS[Language.US],
    about: { title: "Architecture of Knowledge", description: "We don't just sell information; we deliver modulated paths to real success. Our methodology is based on 3 levels of technical depth." },
    stats: STATS[Language.US],
    design: { title: "Design Language", subtitle: "The aesthetics of knowledge.", specs: DESIGN_SPECS[Language.US] },
    roadmap: { title: "MK Vision 2025", subtitle: "Our journey towards digital hegemony.", items: ROADMAP[Language.US] },
    gallery: { title: "Inside the Elite", subtitle: "A preview of the MK visual experience.", items: GALLERY[Language.US] },
    manifesto: { title: "Our Philosophy", text: ["Each pixel was designed to inspire deep focus.", "Beauty is the gateway to discipline.", "Knowledge without execution is just noise."] },
    news: { title: "MK Insights", subtitle: "The frontiers of the digital market and technology.", readMore: "View Article", close: "Back", items: NEWS[Language.US] },
    niches: { title: "Knowledge Domains", items: { marketing: "Marketing", investment: "Investments", development: "Development", relationships: "Relationships", programming: "Programming", wellness: "Wellness", spirituality: "Spirituality" } },
    nicheDetails: {
      marketing: { 
        description: "Master the art of persuasion, paid traffic, and global sales scaling.", 
        checkoutLinks: { level1: "https://pay.kiwify.com/BMzk0JR", level2: "https://pay.kiwify.com/dFrOIOX", level3: "https://pay.kiwify.com/1217hEA" }, 
        reviews: [] 
      },
      investment: { description: "Preservation strategies, risk management, and capital multiplication.", checkoutLinks: { level1: "https://pay.kiwify.com/28yAsrj", level2: "https://pay.kiwify.com/csZmdI9", level3: "https://pay.kiwify.com/PkBCmlS" }, reviews: [] },
      development: { description: "High performance, leadership, and the science of extreme productivity.", checkoutLinks: { level1: "https://pay.kiwify.com/TELjd5I", level2: "https://pay.kiwify.com/lbeoM9F", level3: "https://pay.kiwify.com/Ynieo4o" }, reviews: [] },
      relationships: { description: "Social dynamics, communication, and advanced emotional intelligence.", checkoutLinks: { level1: "https://pay.kiwify.com/S9xIovA", level2: "https://pay.kiwify.com/dqOCL7V", level3: "https://pay.kiwify.com/i6o31YD" }, reviews: [] },
      programming: { description: "Elite logic, modern architectures, and fullstack development.", checkoutLinks: { level1: "https://pay.kiwify.com/tc0dB8N", level2: "https://pay.kiwify.com/rlJkyMx", level3: "https://pay.kiwify.com/IJxAzH8" }, reviews: [] },
      wellness: { description: "Biohacking, optimized health for performance and longevity.", checkoutLinks: { level1: "https://pay.kiwify.com/DnKj9Sh", level2: "https://pay.kiwify.com/lY61xIb", level3: "https://pay.kiwify.com/Hvh9j9r" }, reviews: [] },
      spirituality: { description: "Inner peace, clarity of purpose, and faith foundations.", checkoutLinks: { level1: "https://pay.kiwify.com/v5Chr8s", level2: "https://pay.kiwify.com/r3Hpn9D", level3: "https://pay.kiwify.com/BMzk0JR" }, reviews: [] },
    },
    products: { currency: "$", buy: "Acquire Now", back: "Back", levels: { beginner: "Beginner", intermediate: "Intermediate", advanced: "Advanced" }, prices: { level1: "55", level2: "55", level3: "55" } },
    evolution: { title: "Mastery Curve", mastery: "mastery" },
    faq: { title: "Support Center", items: FAQ[Language.US] },
    auth: { login: "Access", register: "Create Account", logout: "Logout", welcome: "Hello,", namePlaceholder: "Name", emailPlaceholder: "Email", passwordPlaceholder: "Password", submitLogin: "Login", submitRegister: "Register", switchToRegister: "New? Create account", switchToLogin: "Member? Login", country: "Country", error: "Access denied." },
    footer: { rights: "MK Digital Platform. Premium Infoproduct Reference.", contact: "contact@mkdigital.com" },
    platformReviews: { title: "Critical Feedback", items: PLATFORM_FEEDBACK[Language.US] },
    frequentReviews: { title: "Elite Voices", subtitle: "What members who reached Level 3 say.", items: FREQUENT[Language.US] },
    careers: { title: "Culture & Legacy", subtitle: "Voices of those who helped build our excellence.", items: EMPLOYEES[Language.US] },
    marketplace: { searchPlaceholder: "What do you want to master today?", departments: "Departments", all: "All", results: "eBooks", bestSeller: "Best Seller", addToCart: "Buy", noResults: "Nothing found." }
  },
  [Language.ES]: {
    hero: { subtitle: "La élite del conocimiento digital. eBooks estruturados para su ascenso estratégico.", cta: "Explorar Catálogo", microcopy: "Diseño de Próxima Generación. Contenido Élite." },
    snippets: SNIPPETS[Language.ES],
    about: { title: "Arquitectura del Saber", description: "No solo vendemos información; entregamos caminos modulados para el éxito real. Nuestra metodología se basa en 3 níveis de profundidad técnica." },
    stats: STATS[Language.ES],
    design: { title: "Design Language", subtitle: "La estética del conocimiento.", specs: DESIGN_SPECS[Language.ES] },
    roadmap: { title: "MK Vision 2025", subtitle: "Nuestra jornada hacia la hegemonía digital.", items: ROADMAP[Language.ES] },
    gallery: { title: "Por Dentro de la Élite", subtitle: "Una vista previa de la experiencia visual MK.", items: GALLERY[Language.ES] },
    manifesto: { title: "Nuestra Filosofia", text: ["Cada píxel fue diseñado para inspirar un enfoque profundo.", "La belleza es la puerta de entrada a la disciplina.", "El conocimiento sin ejecución es solo ruido."] },
    news: { title: "MK Insights", subtitle: "Las fronteras del mercado digital y la tecnología.", readMore: "Ver Artículo", close: "Volver", items: NEWS[Language.ES] },
    niches: { title: "Dominios de Conocimiento", items: { marketing: "Marketing", investment: "Inversiones", development: "Desarrollo", relationships: "Relaciones", programming: "Programación", wellness: "Bienestar", spirituality: "Religión" } },
    nicheDetails: {
      marketing: { 
        description: "Domine el arte de la persuasión, el tráfico pagado y la escala global de ventas.", 
        checkoutLinks: { level1: "https://pay.kiwify.com/b4jA9pA", level2: "https://pay.kiwify.com/b0jrgrq", level3: "https://pay.kiwify.com/90OaVTv" }, 
        reviews: [] 
      },
      investment: { description: "Estrategias de preservación, gestión de riesgos y multiplicación de capital.", checkoutLinks: { level1: "https://pay.kiwify.com/8A99jLJ", level2: "https://pay.kiwify.com/UYe6MST", level3: "https://pay.kiwify.com/ZmGK4Iv" }, reviews: [] },
      development: { description: "Alto rendimiento, liderazgo y la ciencia de la productividad extrema.", checkoutLinks: { level1: "https://pay.kiwify.com/VQmS1fT", level2: "https://pay.kiwify.com/CCehhPr", level3: "https://pay.kiwify.com/kGVt1h3" }, reviews: [] },
      relationships: { description: "Dinámicas sociales, comunicación e inteligencia emocional avanzada.", checkoutLinks: { level1: "https://pay.kiwify.com/3IMr3hY", level2: "https://pay.kiwify.com/orhj0yg", level3: "https://pay.kiwify.com/pXxSMAg" }, reviews: [] },
      programming: { description: "Lógica de élite, arquitecturas modernas y desarrollo fullstack.", checkoutLinks: { level1: "https://pay.kiwify.com/E4rbtN4", level2: "https://pay.kiwify.com/gAgSleZ", level3: "https://pay.kiwify.com/2mSRYCk" }, reviews: [] },
      wellness: { description: "Biohacking, salud optimizada para el rendimiento y la longevidad.", checkoutLinks: { level1: "https://pay.kiwify.com/9g81VAu", level2: "https://pay.kiwify.com/UTYSf09", level3: "https://pay.kiwify.com/vRT6hOD" }, reviews: [] },
      spirituality: { description: "Paz interior, claridad de propósito y fundamentos da fe.", checkoutLinks: { level1: "https://pay.kiwify.com/yxd1NnB", level2: "https://pay.kiwify.com/UzLhOAz", level3: "https://pay.kiwify.com/b4jA9pA" }, reviews: [] },
    },
    products: { currency: "€", buy: "Adquirir Ahora", back: "Volver", levels: { beginner: "Principiante", intermediate: "Intermedio", advanced: "Avanzado" }, prices: { level1: "47", level2: "47", level3: "47" } },
    evolution: { title: "Curva de Maestria", mastery: "maestría" },
    faq: { title: "Centro de Soporte", items: FAQ[Language.ES] },
    auth: { login: "Acceder", register: "Crear Conta", logout: "Sair", welcome: "Hola,", namePlaceholder: "Nombre", emailPlaceholder: "Correo", passwordPlaceholder: "Contraseña", submitLogin: "Entrar", submitRegister: "Registrar", switchToRegister: "¿Nuevo? Crear cuenta", switchToLogin: "¿Miembro? Entrar", country: "País", error: "Acceso denegado." },
    footer: { rights: "MK Digital Platform. Referência em Infoprodutos Premium.", contact: "contacto@mkdigital.com" },
    platformReviews: { title: "Feedback Crítico", items: PLATFORM_FEEDBACK[Language.ES] },
    frequentReviews: { title: "Voces de la Élite", subtitle: "Lo que dicen los miembros que alcançaron el Nivel 3.", items: FREQUENT[Language.ES] },
    careers: { title: "Cultura & Legado", subtitle: "Voces de quienes ayudaron a construir nuestra excelencia.", items: EMPLOYEES[Language.ES] },
    marketplace: { searchPlaceholder: "¿Qué quieres dominar hoy?", departments: "Departamentos", all: "Todos", results: "eBooks", bestSeller: "Más Vendido", addToCart: "Comprar", noResults: "Nada encontrado." }
  }
};
