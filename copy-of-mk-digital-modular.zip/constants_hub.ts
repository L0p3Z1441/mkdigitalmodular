
import { NicheId, HubMapLevel, Language } from './types';

type MultiLangHubContent = Record<Language, Record<NicheId, HubMapLevel[]>>;
type MultiLangTemplates = Record<Language, Record<string, string[]>>;

export const HUB_MAP_CONTENT: MultiLangHubContent = {
  [Language.BR]: {
    marketing: [
      { level: 1, title: "O Despertar", description: "O marketing digital se apresenta como porta de entrada. Entende-se tráfego, conteúdo e por que a atenção é moeda. É o fim da invisibilidade." },
      { level: 2, title: "O Cálculo", description: "Deixa de ser tentativa e vira estatística. SEO, dados, automação e posicionamento. O jogo não é aparecer, é converter com intenção cirúrgica." },
      { level: 3, title: "A Máquina", description: "Escala agressiva, funis complexos e IA. O sistema roda sozinho. A pergunta muda de 'como vender' para 'quanto podemos escalar hoje'." }
    ],
    investment: [
      { level: 1, title: "Consciência", description: "O dinheiro deixa de ser mistério. Entendimento de juros compostos e fim da mentalidade de escassez. Organização é liberdade." },
      { level: 2, title: "Campo de Batalha", description: "Ações, FIIs, Cripto e diversificação real. Análise fria substitui a emoção. O patrimônio começa a trabalhar." },
      { level: 3, title: "Mentalidade", description: "Gestão de risco assimétrica, mercados globais e automação de aportes. O capital se torna uma ferramenta silenciosa de poder." }
    ],
    development: [
      { level: 1, title: "Acordar", description: "Autoconhecimento brutal. Perceber que a maior trava é interna. Hábitos básicos são instalados para parar a autossabotagem." },
      { level: 2, title: "Construção", description: "Rotina de elite, foco laser e produtividade. Você se torna alguém que começa e termina. A consistência vence a intensidade." },
      { level: 3, title: "Identidade", description: "Não é mais sobre o que você faz, mas quem você é. Alta performance natural, propósito claro e domínio emocional absoluto." }
    ],
    relationships: [
      { level: 1, title: "Entendimento", description: "Comunicação básica e limites. Aprender que amar não significa se anular. O fim dos jogos emocionais infantis." },
      { level: 2, title: "Profundidade", description: "Conexão real, vulnerabilidade estratégica e resolução de conflitos. Construção de confiança sólida e maturidade afetiva." },
      { level: 3, title: "Parceria de Vida", description: "Crescimento mútuo acelerado. Autonomia emocional completa. O relacionamento é um pilar de força, não de drenagem." }
    ],
    programming: [
      { level: 1, title: "Lógica", description: "Aprender a pensar como a máquina. Algoritmos, estrutura de dados e os fundamentos que não mudam. O código é uma ferramenta." },
      { level: 2, title: "Sistemas", description: "Arquitetura, clean code e escalabilidade. Criar soluções robustas, não apenas scripts. Domínio de frameworks e bancos de dados." },
      { level: 3, title: "Poder", description: "IA, automação complexa e sistemas distribuídos. O código vira alavanca de negócios. Transformar linhas de texto em impérios digitais." }
    ],
    wellness: [
      { level: 1, title: "Sobrevivência", description: "O básico bem feito: sono, hidratação e movimento. Sair do sedentarismo mental e físico. O corpo para de atrapalhar." },
      { level: 2, title: "Equilíbrio", description: "Nutrição estratégica e treino focado. A energia se mantém alta o dia todo. O corpo vira um motor de produtividade." },
      { level: 3, title: "Estilo de Vida", description: "Biohacking, longevidade e performance cognitiva. Otimização total da biologia para servir ao propósito de vida." }
    ],
    spirituality: [
      { level: 1, title: "A Pergunta", description: "O questionamento do materialismo. Busca por sentido, valores e conexão com algo maior. O início da jornada interior." },
      { level: 2, title: "O Caráter", description: "A fé moldando a ética. Disciplina espiritual diária. A espiritualidade deixa de ser teoria e vira comportamento prático." },
      { level: 3, title: "A Profundidade", description: "Paz inabalável e transcendência. Conexão direta e propósito divino claro. A vida se torna uma missão espiritual em tempo integral." }
    ]
  },
  [Language.US]: {
    marketing: [
      { level: 1, title: "The Awakening", description: "Digital marketing as a gateway. Understanding traffic, content, and attention as currency. The end of invisibility." },
      { level: 2, title: "The Calculation", description: "No longer guesswork, it becomes statistics. SEO, data, automation, and positioning. The game is not appearing, but converting with surgical intent." },
      { level: 3, title: "The Machine", description: "Aggressive scaling, complex funnels, and AI. The system runs itself. The question shifts from 'how to sell' to 'how much can we scale today'." }
    ],
    investment: [
      { level: 1, title: "Awareness", description: "Money ceases to be a mystery. Understanding compound interest and ending the scarcity mindset. Organization is freedom." },
      { level: 2, title: "Battlefield", description: "Stocks, REITs, Crypto, and real diversification. Cold analysis replaces emotion. Wealth starts working." },
      { level: 3, title: "Mindset", description: "Asymmetric risk management, global markets, and automated contributions. Capital becomes a silent tool of power." }
    ],
    development: [
      { level: 1, title: "Waking Up", description: "Brutal self-awareness. Realizing the biggest lock is internal. Basic habits are installed to stop self-sabotage." },
      { level: 2, title: "Construction", description: "Elite routine, laser focus, and productivity. You become someone who starts and finishes. Consistency beats intensity." },
      { level: 3, title: "Identity", description: "It's no longer about what you do, but who you are. Natural high performance, clear purpose, and absolute emotional mastery." }
    ],
    relationships: [
      { level: 1, title: "Understanding", description: "Basic communication and boundaries. Learning that loving doesn't mean erasing yourself. The end of childish emotional games." },
      { level: 2, title: "Depth", description: "Real connection, strategic vulnerability, and conflict resolution. Building solid trust and affective maturity." },
      { level: 3, title: "Life Partnership", description: "Accelerated mutual growth. Complete emotional autonomy. The relationship is a pillar of strength, not drainage." }
    ],
    programming: [
      { level: 1, title: "Logic", description: "Learning to think like the machine. Algorithms, data structures, and unchanging fundamentals. Code is a tool." },
      { level: 2, title: "Systems", description: "Architecture, clean code, and scalability. Creating robust solutions, not just scripts. Mastery of frameworks and databases." },
      { level: 3, title: "Power", description: "AI, complex automation, and distributed systems. Code becomes a business lever. Turning lines of text into digital empires." }
    ],
    wellness: [
      { level: 1, title: "Survival", description: "Basics done right: sleep, hydration, and movement. Exiting mental and physical sedentarism. The body stops being a hindrance." },
      { level: 2, title: "Balance", description: "Strategic nutrition and focused training. Energy stays high all day. The body becomes a productivity engine." },
      { level: 3, title: "Lifestyle", description: "Biohacking, longevity, and cognitive performance. Total biological optimization to serve life's purpose." }
    ],
    spirituality: [
      { level: 1, title: "The Question", description: "Questioning materialism. Search for meaning, values, and connection with something greater. The start of the inner journey." },
      { level: 2, title: "Character", description: "Faith shaping ethics. Daily spiritual discipline. Spirituality stops being theory and becomes practical behavior." },
      { level: 3, title: "Depth", description: "Unshakable peace and transcendence. Direct connection and clear divine purpose. Life becomes a full-time spiritual mission." }
    ]
  },
  [Language.ES]: {
    marketing: [
      { level: 1, title: "El Despertar", description: "El marketing digital como puerta de entrada. Entender tráfico, contenido y la atención como moneda. El fin de la invisibilidad." },
      { level: 2, title: "El Cálculo", description: "Deja de ser intento y se vuelve estadística. SEO, datos, automatización y posicionamiento. El juego no es aparecer, es convertir con intención quirúrgica." },
      { level: 3, title: "La Máquina", description: "Escala agresiva, embudos complejos e IA. El sistema corre solo. La pregunta cambia de 'cómo vender' a 'cuánto podemos escalar hoy'." }
    ],
    investment: [
      { level: 1, title: "Consciencia", description: "El dinero deja de ser un misterio. Entender el interés compuesto y fin de la mentalidad de escasez. Organización es libertad." },
      { level: 2, title: "Campo de Batalla", description: "Acciones, FIIs, Cripto y diversificación real. Análisis frío reemplaza la emoción. El patrimonio empieza a trabajar." },
      { level: 3, title: "Mentalidad", description: "Gestión de riesgo asimétrica, mercados globales y automatización. El capital se convierte en una herramienta silenciosa de poder." }
    ],
    development: [
      { level: 1, title: "Despertar", description: "Autoconocimiento brutal. Darse cuenta de que el mayor bloqueo es interno. Hábitos básicos para detener el autosabotaje." },
      { level: 2, title: "Construcción", description: "Rutina de élite, enfoque láser y productividad. Te conviertes en alguien que empieza y termina. La consistencia vence a la intensidad." },
      { level: 3, title: "Identidad", description: "Ya no es sobre lo que haces, sino quién eres. Alto rendimiento natural, propósito claro y dominio emocional absoluto." }
    ],
    relationships: [
      { level: 1, title: "Entendimiento", description: "Comunicación básica y límites. Aprender que amar no significa anularse. El fin de los juegos emocionales infantiles." },
      { level: 2, title: "Profundidad", description: "Conexión real, vulnerabilidad estratégica y resolución de conflictos. Construcción de confianza sólida y madurez afectiva." },
      { level: 3, title: "Alianza de Vida", description: "Crecimiento mutuo acelerado. Autonomía emocional completa. La relación es un pilar de fuerza, no de drenaje." }
    ],
    programming: [
      { level: 1, title: "Lógica", description: "Aprender a pensar como la máquina. Algoritmos, estructuras de datos y fundamentos que no cambian. El código es una herramienta." },
      { level: 2, title: "Sistemas", description: "Arquitectura, clean code y escalabilidad. Crear soluciones robustas, no solo scripts. Dominio de frameworks y bases de datos." },
      { level: 3, title: "Poder", description: "IA, automatización compleja y sistemas distribuidos. El código se vuelve palanca de negocios. Convertir líneas de texto en imperios digitales." }
    ],
    wellness: [
      { level: 1, title: "Supervivencia", description: "Lo básico bien hecho: sueño, hidratación y movimiento. Salir del sedentarismo mental y físico. El cuerpo deja de estorbar." },
      { level: 2, title: "Equilibrio", description: "Nutrición estratégica y entrenamiento enfocado. La energía se mantiene alta todo el día. El cuerpo se vuelve un motor de productividad." },
      { level: 3, title: "Estilo de Vida", description: "Biohacking, longevidad y rendimiento cognitivo. Optimización total de la biología para servir al propósito de vida." }
    ],
    spirituality: [
      { level: 1, title: "La Pregunta", description: "Cuestionamiento del materialismo. Búsqueda de sentido, valores y conexión con algo mayor. El inicio del viaje interior." },
      { level: 2, title: "Carácter", description: "La fe moldeando la ética. Disciplina espiritual diaria. La espiritualidad deja de ser teoría y se vuelve comportamiento práctico." },
      { level: 3, title: "Profundidad", description: "Paz inquebrantable y trascendencia. Conexión directa y propósito divino claro. La vida se convierte en una misión espiritual a tiempo completo." }
    ]
  }
};

export const HUB_TEMPLATES: MultiLangTemplates = {
  [Language.BR]: {
    format1: [
      "Por que as pessoas falham em {niche}?",
      "O que ninguém te conta sobre {niche}?",
      "Qual é o maior erro silencioso em {niche}?",
      "O que realmente separa quem vence em {niche}?",
      "Quando {niche} não é a melhor escolha?"
    ],
    format2: [
      "{niche} está superestimado?",
      "O mito da facilidade em {niche}",
      "O perigo de romantizar {niche}",
      "Por que a maioria mente sobre resultados em {niche}",
      "A verdade desconfortável sobre {niche}"
    ],
    format3: [
      "{niche} quando você tem pouco tempo",
      "{niche} quando você está perdido",
      "{niche} para quem já tentou e falhou",
      "{niche} quando falta confiança",
      "{niche} em meio ao caos mental"
    ],
    format4: [
      "Mentalidade correta para evoluir em {niche}",
      "O papel da paciência em {niche}",
      "Como não se sabotar em {niche}",
      "O ciclo emocional de quem entra em {niche}",
      "O que amadurecimento muda em {niche}"
    ],
    format5: [
      "O que {niche} tem a ver com disciplina",
      "Como {niche} afeta decisões financeiras",
      "{niche} e autocontrole",
      "O papel de propósito em {niche}",
      "O que {niche} ensina sobre a vida"
    ],
    format6: [
      "Guia honesto sobre {niche}",
      "O caminho real em {niche}",
      "O mapa completo de {niche}",
      "{niche} explicado sem ilusão",
      "A versão madura de {niche}"
    ]
  },
  [Language.US]: {
    format1: [
      "Why do people fail in {niche}?",
      "What nobody tells you about {niche}?",
      "What is the biggest silent mistake in {niche}?",
      "What really separates winners in {niche}?",
      "When is {niche} not the best choice?"
    ],
    format2: [
      "Is {niche} overrated?",
      "The myth of ease in {niche}",
      "The danger of romanticizing {niche}",
      "Why most lie about results in {niche}",
      "The uncomfortable truth about {niche}"
    ],
    format3: [
      "{niche} when you have little time",
      "{niche} when you are lost",
      "{niche} for those who tried and failed",
      "{niche} when confidence is lacking",
      "{niche} amidst mental chaos"
    ],
    format4: [
      "Correct mindset to evolve in {niche}",
      "The role of patience in {niche}",
      "How not to sabotage yourself in {niche}",
      "The emotional cycle of entering {niche}",
      "What maturity changes in {niche}"
    ],
    format5: [
      "What {niche} has to do with discipline",
      "How {niche} affects financial decisions",
      "{niche} and self-control",
      "The role of purpose in {niche}",
      "What {niche} teaches about life"
    ],
    format6: [
      "Honest guide about {niche}",
      "The real path in {niche}",
      "The complete map of {niche}",
      "{niche} explained without illusion",
      "The mature version of {niche}"
    ]
  },
  [Language.ES]: {
    format1: [
      "¿Por qué la gente falla en {niche}?",
      "¿Lo que nadie te cuenta sobre {niche}?",
      "¿Cuál es el mayor error silencioso en {niche}?",
      "¿Qué separa realmente a quienes ganan en {niche}?",
      "¿Cuándo {niche} no es la mejor opción?"
    ],
    format2: [
      "¿Está sobrevalorado {niche}?",
      "El mito de la facilidad en {niche}",
      "El peligro de idealizar {niche}",
      "Por qué la mayoría miente sobre resultados en {niche}",
      "La verdad incómoda sobre {niche}"
    ],
    format3: [
      "{niche} cuando tienes poco tiempo",
      "{niche} cuando estás perdido",
      "{niche} para quien ya intentó y falló",
      "{niche} cuando falta confianza",
      "{niche} en medio del caos mental"
    ],
    format4: [
      "Mentalidad correcta para evolucionar en {niche}",
      "El papel de la paciencia en {niche}",
      "Cómo no sabotearse en {niche}",
      "El ciclo emocional de entrar en {niche}",
      "Lo que la madurez cambia en {niche}"
    ],
    format5: [
      "Qué tiene que ver {niche} con la disciplina",
      "Cómo afecta {niche} las decisiones financieras",
      "{niche} y autocontrol",
      "El papel del propósito en {niche}",
      "Lo que {niche} enseña sobre la vida"
    ],
    format6: [
      "Guía honesta sobre {niche}",
      "El camino real en {niche}",
      "El mapa completo de {niche}",
      "{niche} explicado sin ilusión",
      "La versión madura de {niche}"
    ]
  }
};
