
import React from 'react';
import { motion } from 'framer-motion';
import { GalleryImage } from '../types';

interface Props {
  title: string;
  subtitle: string;
  items: GalleryImage[];
}

const DigitalGallery: React.FC<Props> = ({ title, subtitle, items }) => {
  return (
    <section className="py-24 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-4">{title}</h2>
          <p className="text-gray-400 font-light">{subtitle}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -10 }}
              className="group relative h-[500px] overflow-hidden rounded-sm border border-white/5"
            >
              <div 
                 className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-110"
                 style={{ backgroundImage: `url(${item.image})` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90" />
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end z-10">
                <h3 className="text-2xl font-serif text-white mb-2 transform transition-transform group-hover:translate-x-2">{item.title}</h3>
                <p className="text-gray-400 text-sm font-light opacity-0 group-hover:opacity-100 transition-opacity duration-500">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DigitalGallery;
