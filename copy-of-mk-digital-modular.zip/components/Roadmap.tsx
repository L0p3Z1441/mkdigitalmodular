
import React from 'react';
import { motion } from 'framer-motion';
import { RoadmapStep } from '../types';
import { CheckCircle2, Circle, FastForward } from 'lucide-react';

interface Props {
  title: string;
  subtitle: string;
  items: RoadmapStep[];
}

const Roadmap: React.FC<Props> = ({ title, subtitle, items }) => {
  return (
    <section className="py-24 bg-mk-black border-y border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-4">{title}</h2>
          <p className="text-gray-400 font-light">{subtitle}</p>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Vertical Line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/10 hidden md:block" />

          <div className="space-y-12">
            {items.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className={`flex flex-col md:flex-row items-center gap-8 ${i % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
              >
                <div className="flex-1 text-center md:text-left">
                  <span className="text-[10px] text-mk-gold uppercase tracking-[0.3em] font-bold">{item.period}</span>
                  <h3 className="text-2xl font-serif text-white my-2">{item.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{item.description}</p>
                </div>

                <div className="relative z-10 flex items-center justify-center">
                   <div className={`p-2 rounded-full border bg-mk-black ${item.status === 'completed' ? 'border-mk-gold text-mk-gold' : item.status === 'current' ? 'border-mk-red text-mk-red animate-pulse' : 'border-gray-700 text-gray-700'}`}>
                      {item.status === 'completed' ? <CheckCircle2 size={24} /> : item.status === 'current' ? <FastForward size={24} /> : <Circle size={24} />}
                   </div>
                </div>

                <div className="flex-1 hidden md:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Roadmap;
