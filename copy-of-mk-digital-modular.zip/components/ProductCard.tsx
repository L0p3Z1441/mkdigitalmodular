
import React, { useState, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ShoppingCart, BookOpen, Check, Plus, Minus, List } from 'lucide-react';
import { Translations } from '../types';

interface Props {
  level: 1 | 2 | 3;
  price: string;
  nicheTitle: string;
  translations: Translations['products'];
  checkoutUrl: string;
}

const ProductCard: React.FC<Props> = memo(({ level, price, nicheTitle, translations, checkoutUrl }) => {
  const [showModules, setShowModules] = useState(false);

  const getLevelDetails = () => {
    switch(level) {
      case 1:
        return {
          title: translations.levels.beginner,
          borderColor: "border-gray-700 group-hover:border-gray-500",
          glow: "group-hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]",
          stars: 3,
          features: ["Fundamentos Essenciais", "Guia Introdutório", "Acesso Básico"],
          modules: [
            "Módulo 01: O Despertar da Consciência",
            "Módulo 02: Ferramentas Fundamentais",
            "Módulo 03: Eliminando Ruídos",
            "Módulo 04: Primeiro Plano de Ação"
          ]
        };
      case 2:
        return {
          title: translations.levels.intermediate,
          borderColor: "border-mk-gold/30 group-hover:border-mk-gold",
          glow: "group-hover:shadow-[0_0_25px_rgba(212,175,55,0.2)]",
          stars: 4,
          features: ["Técnicas Aplicadas", "Estudos de Caso", "Mentoria Gravada"],
          modules: [
            "Módulo 01: Estratégia Aplicada",
            "Módulo 02: Otimização de Processos",
            "Módulo 03: Análise de Dados Reais",
            "Módulo 04: Escalando Resultados"
          ]
        };
      case 3:
        return {
          title: translations.levels.advanced,
          borderColor: "border-mk-gold group-hover:border-[#FFD700]",
          glow: "group-hover:shadow-[0_0_40px_rgba(212,175,55,0.4)]",
          stars: 5,
          features: ["Mastery Completo", "Certificação", "Acesso Vitalício & VIP"],
          modules: [
            "Módulo 01: Hegemonia de Mercado",
            "Módulo 02: Psicologia das Massas",
            "Módulo 03: Automação Sistêmica",
            "Módulo 04: O Legado (Endgame)"
          ]
        };
    }
  };

  const details = getLevelDetails();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`relative bg-mk-gray/80 backdrop-blur-sm p-6 sm:p-8 flex flex-col h-full border ${details.borderColor} ${details.glow} transition-all duration-500 group rounded-sm gpu-accelerated`}
    >
      {/* Background Gradient Mesh */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

      <div className="absolute top-0 right-0 p-4">
        <div className="flex space-x-1">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              size={12} 
              className={`${i < details.stars ? 'text-mk-gold fill-mk-gold drop-shadow-[0_0_5px_rgba(212,175,55,0.8)]' : 'text-gray-800'}`} 
            />
          ))}
        </div>
      </div>

      <div className="mb-6 mt-2 relative z-10">
        <span className="text-[10px] uppercase tracking-[0.2em] text-gray-400 group-hover:text-white transition-colors">{nicheTitle}</span>
        <h3 className="text-2xl font-bold text-white mt-2 group-hover:text-mk-gold transition-colors duration-300">
          {details.title}
        </h3>
      </div>

      <div className="flex items-center space-x-4 mb-8 relative z-10">
        <div className="p-3 bg-black/50 rounded-full border border-white/10 group-hover:border-mk-gold/50 transition-colors">
           <BookOpen size={24} className="text-gray-400 group-hover:text-white transition-colors" />
        </div>
        <div className="h-10 w-[1px] bg-gray-700" />
        <div className="text-3xl sm:text-4xl font-serif text-white group-hover:scale-105 transition-transform origin-left will-change-transform">
          <span className="text-sm align-top opacity-60 mr-1">{translations.currency}</span>
          {price}
        </div>
      </div>

      {/* Features List */}
      <ul className="space-y-4 mb-8 flex-grow relative z-10">
        {details.features.map((feat, i) => (
          <li key={i} className="flex items-center text-sm text-gray-400 group-hover:text-gray-200 transition-colors">
            <div className="w-5 h-5 rounded-full bg-mk-gold/10 flex items-center justify-center mr-3 border border-mk-gold/20 group-hover:border-mk-gold/60">
               <Check size={10} className="text-mk-gold" />
            </div>
            {feat}
          </li>
        ))}
      </ul>

      {/* Expandable Modules */}
      <div className="mb-6 relative z-10">
        <button 
          onClick={() => setShowModules(!showModules)}
          className="w-full flex items-center justify-between text-[10px] uppercase tracking-widest text-gray-500 hover:text-mk-gold transition-colors py-2 border-t border-white/5"
        >
          <span className="flex items-center gap-2"><List size={12} /> Grade Curricular</span>
          {showModules ? <Minus size={12} /> : <Plus size={12} />}
        </button>
        <AnimatePresence>
          {showModules && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <ul className="py-3 space-y-2">
                {details.modules.map((mod, i) => (
                  <motion.li 
                    key={i}
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className="text-xs text-gray-300 font-light pl-4 border-l border-mk-gold/30"
                  >
                    {mod}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <a 
        href={checkoutUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="relative overflow-hidden w-full bg-white text-black font-bold py-4 flex items-center justify-center space-x-2 transition-all duration-300 cursor-pointer group-hover:bg-mk-gold z-10 shadow-lg will-change-transform rounded-sm"
      >
        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
        <ShoppingCart size={18} className="relative z-10" />
        <span className="relative z-10 tracking-widest text-xs uppercase">{translations.buy}</span>
      </a>

      {level === 3 && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-mk-red text-white text-[10px] font-bold px-4 py-1.5 uppercase tracking-widest shadow-[0_0_15px_#B11212] z-20 animate-pulse-slow">
          Best Seller
        </div>
      )}
    </motion.div>
  );
});

export default ProductCard;
