import React from 'react';
import { motion } from 'framer-motion';
import { Translations } from '../types';

interface Props {
  translations: Translations['evolution'];
  levels: Translations['products']['levels'];
  maxLevels?: number;
}

const LearningEvolution: React.FC<Props> = ({ translations, levels, maxLevels }) => {
  const bars = maxLevels === 2 
    ? [
        { label: levels.beginner, percentage: 50, color: 'bg-mk-gold/60' },
        { label: levels.advanced, percentage: 100, color: 'bg-mk-gold' },
      ]
    : [
        { label: levels.beginner, percentage: 30, color: 'bg-gray-500' },
        { label: levels.intermediate, percentage: 65, color: 'bg-mk-gold/60' },
        { label: levels.advanced, percentage: 100, color: 'bg-mk-gold' },
      ];

  return (
    <div className="py-12 bg-black/50 border-y border-white/5">
      <div className="container mx-auto px-6">
        <h3 className="text-2xl font-serif text-white mb-8 text-center">
          {translations.title}
        </h3>
        
        <div className="space-y-6 max-w-3xl mx-auto">
          {bars.map((bar, index) => (
            <div key={index} className="relative">
              <div className="flex justify-between text-sm text-gray-400 mb-2 uppercase tracking-wider">
                <span>{bar.label}</span>
                <span>{bar.percentage}% {translations.mastery}</span>
              </div>
              <div className="h-4 bg-gray-900 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${bar.percentage}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5, delay: index * 0.2, ease: "easeOut" }}
                  className={`h-full ${bar.color} relative`}
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse" />
                </motion.div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LearningEvolution;