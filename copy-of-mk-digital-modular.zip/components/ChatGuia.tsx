
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, X, Sparkles, ShoppingBag, ArrowRight, Bot, Loader2, CreditCard } from 'lucide-react';
import { GoogleGenAI, FunctionDeclaration, Type } from "@google/genai";
import { Language, NicheId, NicheDetail } from '../types';
import { NICHE_KEYS } from '../constants';

interface ProductRecommendation {
  nicheId: NicheId;
  level: 1 | 2 | 3;
  reasoning: string;
}

interface Message {
  id: string;
  role: 'user' | 'model';
  text?: string;
  recommendation?: ProductRecommendation;
}

interface Props {
  lang: Language;
  nicheDetails: Record<NicheId, NicheDetail>;
  nicheNames: Record<NicheId, string>;
  nicheImages: Record<NicheId, string>;
  onNavigateToProduct: (nicheId: NicheId) => void;
}

const ChatGuia: React.FC<Props> = ({ 
  lang, 
  nicheDetails, 
  nicheNames, 
  nicheImages, 
  onNavigateToProduct 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial greeting
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const greeting = lang === Language.BR 
        ? "Olá. Sou o Guia MK. Analiso seu perfil e indico o caminho exato para sua evolução. O que você busca dominar hoje?"
        : (lang === Language.US 
            ? "Hello. I am the MK Guide. I analyze your profile and point the exact path for your evolution. What do you seek to master today?"
            : "Hola. Soy el Guía MK. Analizo su perfil e indico el camino exacto para su evolución. ¿Qué busca dominar hoy?");
      
      setMessages([{ id: 'init', role: 'model', text: greeting }]);
    }
  }, [isOpen, lang]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      if (!process.env.API_KEY) {
        throw new Error("API Key not found");
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Define the tool for product recommendation
      const suggestPurchaseTool: FunctionDeclaration = {
        name: 'suggestPurchase',
        description: 'Suggests a specific purchase (Niche and Level) based on user needs.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            nicheId: {
              type: Type.STRING,
              enum: NICHE_KEYS,
              description: 'The niche category identifier.'
            },
            level: {
              type: Type.NUMBER,
              enum: ["1", "2", "3"],
              description: 'The complexity level (1=Beginner/Fundamentals, 2=Intermediate/Applied, 3=Advanced/Mastery).'
            },
            reasoning: {
              type: Type.STRING,
              description: 'Short explanation of why this product fits the user.'
            }
          },
          required: ['nicheId', 'level', 'reasoning']
        }
      };

      const systemPrompt = `
        You are the 'MK Guia', an expert sales consultant for a premium digital education platform.
        Your goal is to understand the user's current situation and recommend the PERFECT product.
        
        Platform Structure:
        - Niches: ${NICHE_KEYS.join(', ')}.
        - Levels: 
          1 (Beginner): Foundations, awareness, starting out.
          2 (Intermediate): Strategy, application, growing.
          3 (Advanced): Scaling, mastery, high-performance, complex systems.

        Rules:
        1. If the user is vague, ask clarifying questions.
        2. If the user gives enough context (e.g., "I have a business but can't scale"), recommend a product immediately using the 'suggestPurchase' tool.
        3. Be concise, professional, and elegant.
        4. Language: ${lang === Language.BR ? 'Portuguese' : (lang === Language.US ? 'English' : 'Spanish')}.
      `;

      // Build history for context
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text || (m.recommendation ? `Recommended: ${m.recommendation.nicheId} Level ${m.recommendation.level}` : '') }]
      }));

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          ...history,
          { role: 'user', parts: [{ text: input }] }
        ],
        config: {
          systemInstruction: systemPrompt,
          tools: [{ functionDeclarations: [suggestPurchaseTool] }]
        }
      });

      const functionCalls = response.functionCalls;
      let botResponseText = response.text || "";

      if (functionCalls && functionCalls.length > 0) {
        const call = functionCalls[0];
        if (call.name === 'suggestPurchase') {
          const args = call.args as unknown as ProductRecommendation;
          
          const recMsg: Message = {
            id: Date.now().toString(),
            role: 'model',
            recommendation: {
              nicheId: args.nicheId,
              level: Number(args.level) as 1 | 2 | 3,
              reasoning: args.reasoning
            }
          };
          setMessages(prev => [...prev, recMsg]);
          setIsLoading(false);
          return;
        }
      }

      if (botResponseText) {
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: botResponseText }]);
      } else {
        // Fallback
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "Compreendido. Poderia detalhar um pouco mais?" }]);
      }

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "Erro de conexão. Tente novamente." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getProductInfo = (nicheId: NicheId, level: number) => {
    // Simulated prices based on App.tsx constants usually passed in
    const prices = { 1: "299", 2: "299", 3: "299" }; 
    const currency = lang === Language.BR ? "R$" : (lang === Language.US ? "$" : "€");
    const displayPrice = lang === Language.US ? "55" : (lang === Language.ES ? "47" : "299");
    
    return {
      title: `${nicheNames[nicheId]} - Nível ${level}`,
      price: `${currency} ${displayPrice}`,
      image: nicheImages[nicheId],
      description: nicheDetails[nicheId].description
    };
  };

  return (
    <>
      {/* Trigger Button */}
      {!isOpen && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          onClick={() => setIsOpen(true)}
          className="fixed bottom-24 right-6 z-40 bg-white text-black p-4 rounded-full shadow-[0_0_30px_rgba(255,255,255,0.3)] hover:scale-110 transition-transform group flex items-center gap-2"
        >
          <Sparkles size={20} className="text-mk-gold fill-mk-gold animate-pulse" />
          <span className="font-bold text-xs uppercase tracking-widest pr-1">Guia MK</span>
        </motion.button>
      )}

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] h-[600px] max-h-[80vh] bg-[#050505] border border-mk-gold/30 flex flex-col shadow-2xl shadow-black rounded-sm overflow-hidden"
          >
            {/* Header */}
            <div className="bg-mk-gold/10 backdrop-blur-md p-4 border-b border-mk-gold/20 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="bg-mk-gold p-1.5 rounded-sm">
                  <Bot size={18} className="text-black" />
                </div>
                <div>
                  <h3 className="text-mk-gold font-serif font-bold leading-none">MK GUIA</h3>
                  <span className="text-[9px] text-gray-400 uppercase tracking-widest">Consultor Inteligente</span>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-gray-500 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-gradient-to-b from-[#050505] to-[#0a0a0a] custom-scrollbar">
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.recommendation ? (
                    // PRODUCT CARD RENDER
                    <div className="w-full max-w-[90%]">
                      <div className="bg-[#111] border border-mk-gold/40 rounded-sm overflow-hidden shadow-[0_0_20px_rgba(212,175,55,0.1)]">
                        {/* Header Reasoning */}
                        <div className="p-3 bg-mk-gold/10 border-b border-mk-gold/10">
                          <p className="text-xs text-mk-gold italic">"{msg.recommendation.reasoning}"</p>
                        </div>
                        
                        {/* Product Visuals */}
                        <div className="relative h-32">
                          <img 
                            src={getProductInfo(msg.recommendation.nicheId, msg.recommendation.level).image} 
                            alt="Product" 
                            className="w-full h-full object-cover opacity-60"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#111] to-transparent" />
                          <div className="absolute bottom-3 left-4">
                            <span className="text-[10px] bg-mk-gold text-black px-2 py-0.5 font-bold uppercase tracking-widest rounded-sm">
                              Recomendado
                            </span>
                          </div>
                        </div>

                        {/* Product Info */}
                        <div className="p-4 pt-2">
                          <h4 className="text-white font-serif text-lg mb-1">
                            {getProductInfo(msg.recommendation.nicheId, msg.recommendation.level).title}
                          </h4>
                          <div className="flex justify-between items-end mt-4">
                            <span className="text-2xl text-white font-bold">
                              {getProductInfo(msg.recommendation.nicheId, msg.recommendation.level).price}
                            </span>
                            <button
                              onClick={() => {
                                onNavigateToProduct(msg.recommendation!.nicheId);
                                setIsOpen(false);
                              }}
                              className="bg-mk-gold text-black text-xs font-bold uppercase tracking-widest px-4 py-2 flex items-center gap-2 hover:bg-white transition-colors"
                            >
                              Ver Produto <ArrowRight size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    // TEXT RENDER
                    <div className={`max-w-[85%] p-3 text-sm leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-white/10 text-white rounded-tl-lg rounded-bl-lg rounded-br-lg' 
                        : 'text-gray-300 font-light'
                    }`}>
                      {msg.text}
                    </div>
                  )}
                </motion.div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-2 text-mk-gold text-xs uppercase tracking-widest">
                    <Loader2 size={14} className="animate-spin" />
                    Analisando...
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-[#0a0a0a] border-t border-white/10">
              <div className="relative flex items-center gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Descreva seu momento atual..."
                  className="w-full bg-white/5 border border-white/10 text-white px-4 py-3 text-sm focus:border-mk-gold/50 focus:ring-0 outline-none transition-all placeholder:text-gray-600"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="bg-mk-gold/90 hover:bg-mk-gold text-black p-3 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatGuia;
