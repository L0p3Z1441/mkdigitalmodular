
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { NicheId, Language } from '../types';
import { NICHE_KEYS } from '../constants';
import { HUB_MAP_CONTENT, HUB_TEMPLATES } from '../constants_hub';
import { 
  Zap, AlertTriangle, Clock, Brain, Network, BookOpen, 
  ChevronRight, Layout, Monitor, DollarSign, Heart, 
  Code, Activity, Sparkles, FolderOpen, ArrowUpRight, MessageCircle 
} from 'lucide-react';

interface Props {
  nicheNames: Record<NicheId, string>;
  lang: Language;
  onAskBot: (question: string) => void;
}

const HubView: React.FC<Props> = ({ nicheNames, lang, onAskBot }) => {
  const [activeNiche, setActiveNiche] = useState<NicheId>('marketing');
  const [expandedFormat, setExpandedFormat] = useState<string | null>('format1');
  const [showArticles, setShowArticles] = useState(false);

  // Premium Easing Curve
  const transition = { type: "tween" as const, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number], duration: 0.5 };

  const icons: Record<NicheId, any> = {
    marketing: Monitor,
    investment: DollarSign,
    development: Zap,
    relationships: Heart,
    programming: Code,
    wellness: Activity,
    spirituality: Sparkles
  };

  const getUIStrings = () => {
    if (lang === Language.US) return {
      explore: "Explore Related Articles",
      mapTitle: "Evolution Map",
      deepDive: "Strategic Deep Dive",
      level: "Level",
      read: "PDF"
    };
    if (lang === Language.ES) return {
      explore: "Explorar Artículos Relacionados",
      mapTitle: "Mapa de Evolución",
      deepDive: "Inmersión Estratégica",
      level: "Nivel",
      read: "PDF"
    };
    return {
      explore: "Explorar Artigos Relacionados",
      mapTitle: "O Mapa da Evolução",
      deepDive: "Deep Dive Estratégico",
      level: "Nível",
      read: "PDF"
    };
  };

  const strings = getUIStrings();

  const formats = [
    { id: 'format1', title: lang === Language.BR ? 'Perguntas Fundamentais' : (lang === Language.US ? 'Fundamental Questions' : 'Preguntas Fundamentales'), icon: FolderOpen, data: HUB_TEMPLATES[lang].format1 },
    { id: 'format2', title: lang === Language.BR ? 'Conflito Direto' : (lang === Language.US ? 'Direct Conflict' : 'Conflicto Directo'), icon: AlertTriangle, data: HUB_TEMPLATES[lang].format2 },
    { id: 'format3', title: lang === Language.BR ? 'Situações Específicas' : (lang === Language.US ? 'Specific Situations' : 'Situaciones Específicas'), icon: Clock, data: HUB_TEMPLATES[lang].format3 },
    { id: 'format4', title: lang === Language.BR ? 'Metacognição' : (lang === Language.US ? 'Metacognition' : 'Metacognición'), icon: Brain, data: HUB_TEMPLATES[lang].format4 },
    { id: 'format5', title: lang === Language.BR ? 'Conexões Cruzadas' : (lang === Language.US ? 'Cross Connections' : 'Conexiones Cruzadas'), icon: Network, data: HUB_TEMPLATES[lang].format5 },
    { id: 'format6', title: lang === Language.BR ? 'Consolidação' : (lang === Language.US ? 'Consolidation' : 'Consolidación'), icon: BookOpen, data: HUB_TEMPLATES[lang].format6 },
  ];

  const getSimulatedArticles = (niche: NicheId) => {
    const titles = {
      [Language.BR]: [
        `Guia Definitivo de ${nicheNames[niche]} para 2025`,
        `Os 3 Erros Comuns em ${nicheNames[niche]}`,
        `Estudo de Caso: Sucesso em ${nicheNames[niche]}`,
        `Ferramentas Essenciais para ${nicheNames[niche]}`
      ],
      [Language.US]: [
        `Ultimate Guide to ${nicheNames[niche]} for 2025`,
        `Top 3 Mistakes in ${nicheNames[niche]}`,
        `Case Study: Success in ${nicheNames[niche]}`,
        `Essential Tools for ${nicheNames[niche]}`
      ],
      [Language.ES]: [
        `Guía Definitiva de ${nicheNames[niche]} para 2025`,
        `Los 3 Errores Comunes en ${nicheNames[niche]}`,
        `Estudio de Caso: Éxito en ${nicheNames[niche]}`,
        `Herramientas Esenciales para ${nicheNames[niche]}`
      ]
    };
    return titles[lang] || titles[Language.BR];
  };

  const formatText = (text: string, nicheKey: NicheId) => {
    const name = nicheNames[nicheKey];
    return text.replace(/{niche}/g, name);
  };

  return (
    <div className="min-h-screen pt-28 pb-12 bg-[#050505]">
      
      {/* Header */}
      <div className="container mx-auto px-6 mb-12">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={transition}
           className="text-center"
        >
           <h1 className="text-4xl md:text-6xl font-serif text-white mb-4 tracking-tight">
             {lang === Language.BR ? "Hub de Inteligência" : (lang === Language.US ? "Intelligence Hub" : "Hub de Inteligencia")}
           </h1>
           <p className="text-gray-400 text-lg max-w-2xl mx-auto font-light">
             {lang === Language.BR 
               ? "Um atlas estratégico mapeando os 7 domínios da vida, do despertar à maestria absoluta." 
               : (lang === Language.US 
                   ? "A strategic atlas mapping the 7 domains of life, from awakening to absolute mastery." 
                   : "Un atlas estratégico que mapea los 7 dominios de la vida, desde el despertar hasta la maestría absoluta.")}
           </p>
        </motion.div>
      </div>

      {/* Niche Selector */}
      <div className="border-y border-white/5 bg-black/50 backdrop-blur-sm sticky top-[72px] z-30 overflow-x-auto hide-scrollbar">
        <div className="container mx-auto px-6">
          <div className="flex gap-8 min-w-max md:justify-center py-4">
            {NICHE_KEYS.map((key) => {
              const Icon = icons[key];
              const isActive = activeNiche === key;
              return (
                <button
                  key={key}
                  onClick={() => setActiveNiche(key)}
                  className={`flex items-center gap-2 text-sm uppercase tracking-widest transition-all duration-300 ${
                    isActive ? 'text-mk-gold scale-105 font-bold' : 'text-gray-500 hover:text-white'
                  }`}
                >
                  <Icon size={16} className={isActive ? 'text-mk-gold' : 'text-gray-600'} />
                  {nicheNames[key]}
                  {isActive && <motion.div layoutId="activeTab" transition={transition} className="absolute bottom-0 h-[2px] bg-mk-gold w-full left-0 mt-4" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        
        {/* SECTION 1: THE MAP */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <Layout className="text-mk-gold" />
            <h2 className="text-2xl font-serif text-white">{strings.mapTitle}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <AnimatePresence mode='wait'>
              {HUB_MAP_CONTENT[lang][activeNiche].map((levelData, index) => (
                <motion.div
                  key={`${activeNiche}-${levelData.level}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.1, ...transition }}
                  className={`bg-[#0A0A0A] border border-white/5 p-8 relative group hover:border-mk-gold/30 transition-all duration-500 ${
                    index === 2 ? 'bg-gradient-to-br from-[#0A0A0A] to-mk-gold/5' : ''
                  }`}
                >
                  <span className="absolute top-0 right-0 p-4 text-[80px] font-serif text-white/5 font-bold leading-none pointer-events-none">
                    0{levelData.level}
                  </span>
                  <div className="relative z-10">
                    <span className={`inline-block px-3 py-1 text-[10px] uppercase tracking-widest font-bold mb-4 rounded-sm ${
                      index === 0 ? 'bg-white/10 text-white' : index === 1 ? 'bg-mk-gold/10 text-mk-gold' : 'bg-mk-red/10 text-mk-red'
                    }`}>
                       {strings.level} {levelData.level}
                    </span>
                    <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-mk-gold transition-colors">
                      {levelData.title}
                    </h3>
                    <p className="text-gray-400 font-light leading-relaxed">
                      {levelData.description}
                    </p>
                  </div>
                  <div className="absolute bottom-0 left-0 h-1 bg-mk-gold/20 w-full">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(index + 1) * 33.3}%` }}
                      transition={{ duration: 1, delay: 0.5, ease: "circOut" }}
                      className="h-full bg-mk-gold"
                    />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* SECTION 2: DEEP DIVE FORMATS */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <Brain className="text-mk-gold" />
            <h2 className="text-2xl font-serif text-white">{strings.deepDive}</h2>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {formats.map((format) => (
              <motion.div
                key={format.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`border border-white/5 bg-[#0A0A0A] overflow-hidden transition-all duration-500 ${
                  expandedFormat === format.id ? 'border-mk-gold/30 shadow-lg shadow-black/50' : 'hover:border-white/20'
                }`}
              >
                <button
                  onClick={() => {
                     setExpandedFormat(expandedFormat === format.id ? null : format.id);
                     setShowArticles(false);
                  }}
                  className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-md transition-colors duration-300 ${expandedFormat === format.id ? 'bg-mk-gold text-black' : 'bg-white/5 text-gray-400'}`}>
                      <format.icon size={20} />
                    </div>
                    <span className={`text-lg font-serif tracking-wide transition-colors duration-300 ${expandedFormat === format.id ? 'text-white' : 'text-gray-400'}`}>
                      {format.title}
                    </span>
                  </div>
                  <ChevronRight 
                    className={`transform transition-transform duration-500 ease-[cubic-bezier(0.25,0.1,0.25,1)] ${expandedFormat === format.id ? 'rotate-90 text-mk-gold' : 'text-gray-600'}`} 
                  />
                </button>

                <AnimatePresence>
                  {expandedFormat === format.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
                      className="border-t border-white/5 overflow-hidden"
                    >
                      <div className="p-6 pt-0 mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                        {format.data.map((template, i) => {
                          const question = formatText(template, activeNiche);
                          return (
                            <motion.div 
                              key={i} 
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: i * 0.05 }}
                              onClick={() => onAskBot(question)}
                              className="p-4 bg-black/40 border border-white/5 hover:border-mk-gold/40 hover:bg-mk-gold/5 transition-all cursor-pointer group rounded-sm flex items-start gap-3 relative overflow-hidden will-change-transform"
                            >
                               <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <MessageCircle size={14} className="text-mk-gold" />
                               </div>
                               <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-gray-700 group-hover:bg-mk-gold transition-colors" />
                               <p className="text-gray-300 font-light text-sm leading-relaxed group-hover:text-white transition-colors pr-4">
                                 {question}
                               </p>
                            </motion.div>
                          );
                        })}
                      </div>
                      
                      <div className="bg-black/60 border-t border-white/5">
                        <button 
                           onClick={() => setShowArticles(!showArticles)}
                           className="w-full p-4 text-mk-gold text-xs uppercase tracking-widest hover:text-white hover:bg-white/5 transition-colors flex items-center justify-center gap-2"
                        >
                           {showArticles ? <ChevronRight className="-rotate-90" size={14} /> : <BookOpen size={14} />}
                           {strings.explore}
                        </button>

                        <AnimatePresence>
                           {showArticles && (
                              <motion.div
                                 initial={{ height: 0, opacity: 0 }}
                                 animate={{ height: "auto", opacity: 1 }}
                                 exit={{ height: 0, opacity: 0 }}
                                 transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
                                 className="overflow-hidden border-t border-white/5 bg-[#0F0F0F]"
                              >
                                 <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    {getSimulatedArticles(activeNiche).map((title, idx) => (
                                       <motion.div 
                                          key={idx} 
                                          initial={{ opacity: 0 }}
                                          animate={{ opacity: 1 }}
                                          transition={{ delay: idx * 0.1 }}
                                          className="flex items-center justify-between p-3 border border-white/5 hover:border-white/20 hover:bg-white/5 transition-all cursor-pointer group"
                                       >
                                          <div className="flex items-center gap-3">
                                             <div className="w-8 h-10 bg-gray-800 flex items-center justify-center">
                                                <span className="text-[8px] text-gray-400 font-mono">{strings.read}</span>
                                             </div>
                                             <span className="text-gray-300 text-sm font-medium group-hover:text-white">{title}</span>
                                          </div>
                                          <ArrowUpRight size={14} className="text-gray-600 group-hover:text-mk-gold" />
                                       </motion.div>
                                    ))}
                                 </div>
                              </motion.div>
                           )}
                        </AnimatePresence>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default HubView;
