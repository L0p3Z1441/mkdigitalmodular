import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Lock, Mail, User, ChevronRight, Globe, AlertCircle } from 'lucide-react';
import { Translations } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  text: Translations['auth'];
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: (name: string, email: string, password: string, country: string) => Promise<void>;
}

type AuthMode = 'login' | 'register';

const AuthModal: React.FC<Props> = ({ isOpen, onClose, text, onLogin, onRegister }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    country: ''
  });

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setError(null);
      setFormData({ name: '', email: '', password: '', country: '' });
      setMode('login');
    }
  }, [isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === 'login') {
        await onLogin(formData.email, formData.password);
      } else {
        await onRegister(formData.name, formData.email, formData.password, formData.country);
      }
      onClose();
    } catch (err) {
      setError(text.error);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/90 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md bg-mk-gray border border-mk-gold/20 p-8 rounded-none shadow-2xl shadow-mk-gold/10"
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-500 hover:text-mk-gold transition-colors"
          >
            <X size={24} />
          </button>

          <div className="mb-8 text-center">
            <h2 className="text-3xl font-serif text-mk-gold mb-2">MK DIGITAL</h2>
            <p className="text-gray-400 text-sm tracking-wide uppercase">
              {mode === 'login' ? text.login : text.register}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-red-900/20 border border-mk-red/50 text-red-200 px-4 py-3 rounded flex items-center gap-2 text-sm"
              >
                <AlertCircle size={16} />
                {error}
              </motion.div>
            )}

            {mode === 'register' && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                className="space-y-4 overflow-hidden"
              >
                <div className="relative group">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-mk-gold transition-colors" size={20} />
                  <input
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    type="text"
                    required={mode === 'register'}
                    placeholder={text.namePlaceholder}
                    className="w-full bg-black/50 border border-white/10 focus:border-mk-gold text-white px-10 py-3 outline-none transition-all duration-300 placeholder:text-gray-700"
                  />
                </div>
                <div className="relative group">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-mk-gold transition-colors" size={20} />
                  <select 
                    name="country"
                    value={formData.country}
                    onChange={handleChange}
                    required={mode === 'register'}
                    className="w-full bg-black/50 border border-white/10 focus:border-mk-gold text-white px-10 py-3 outline-none transition-all duration-300 placeholder:text-gray-700 appearance-none"
                  >
                    <option value="" disabled>{text.country}</option>
                    <option value="Brasil">Brasil</option>
                    <option value="USA">USA</option>
                    <option value="España">España</option>
                  </select>
                </div>
              </motion.div>
            )}

            <div className="relative group">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-mk-gold transition-colors" size={20} />
              <input
                name="email"
                value={formData.email}
                onChange={handleChange}
                type="email"
                required
                placeholder={text.emailPlaceholder}
                className="w-full bg-black/50 border border-white/10 focus:border-mk-gold text-white px-10 py-3 outline-none transition-all duration-300 placeholder:text-gray-700"
              />
            </div>

            <div className="relative group">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-mk-gold transition-colors" size={20} />
              <input
                name="password"
                value={formData.password}
                onChange={handleChange}
                type="password"
                required
                placeholder={text.passwordPlaceholder}
                className="w-full bg-black/50 border border-white/10 focus:border-mk-gold text-white px-10 py-3 outline-none transition-all duration-300 placeholder:text-gray-700"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-mk-gold text-black font-bold py-3 px-6 hover:bg-white transition-colors duration-300 flex items-center justify-center space-x-2 mt-4"
            >
              <span>{loading ? '...' : (mode === 'login' ? text.submitLogin : text.submitRegister)}</span>
              {!loading && <ChevronRight size={18} />}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              className="text-gray-500 hover:text-mk-gold text-sm transition-colors"
            >
              {mode === 'login' ? text.switchToRegister : text.switchToLogin}
            </button>
          </div>
          
          <div className="mt-8 border-t border-white/5 pt-4 text-center">
            <span className="text-[10px] text-gray-700 uppercase tracking-widest">Secured by MK Digital Identity</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default AuthModal;