

import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { FrequentReview } from '../types';
import { ShoppingBag, Star, ShieldCheck, CheckCircle } from 'lucide-react';

interface Props {
  data: {
    title: string;
    subtitle: string;
    items: FrequentReview[];
  };
}

const FrequentReviews: React.FC<Props> = ({ data }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const x = useTransform(scrollYProgress, [0, 1], [150, -150]);

  const getBadgeStyle = (status: string) => {
    switch (status) {
      case 'Black': return 'bg-neutral-900 border-mk-gold/50 text-mk-gold shadow-[0_0_10px_rgba(212,175,55,0.2)]';
      case 'Platinum': return 'bg-gray-300 border-white text-black';
      case 'Gold': return 'bg-mk-gold border-yellow-200 text-black';
      default: return 'bg-gray-800 text-white';
    }
  };

  return (
    <section ref={containerRef} className="py-24 bg-gradient-to-b from-black to-[#0a0a0a] border-y border-white/5 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-mk-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-6 mb-16 relative z-10 text-center md:text-left">
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
        >
          <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
             <div className="p-2 bg-mk-gold/10 rounded-full border border-mk-gold/20">
               <ShieldCheck className="text-mk-gold w-6 h-6" />
             </div>
             <span className="text-mk-gold text-sm uppercase tracking-widest font-bold">Membros Verificados</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-serif text-white mb-4">
            {data.title}
          </h2>
          <p className="text-gray-400 text-lg md:text-xl font-light max-w-2xl">
            {data.subtitle}
          </p>
        </motion.div>
      </div>

      <div className="relative w-full overflow-x-auto pb-8 hide-scrollbar cursor-grab active:cursor-grabbing">
         <motion.div 
           style={{ x }} 
           className="flex gap-6 px-6 w-max"
         >
            {data.items.map((item, index) => (
               <motion.div
                 key={item.id}
                 whileHover={{ scale: 1.02, y: -5 }}
                 className="w-[85vw] sm:w-[350px] md:w-[480px] bg-[#0F0F0F] border border-white/10 p-8 rounded-sm relative group transition-all duration-500 hover:border-mk-gold/50 shadow-2xl shadow-black/50"
               >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                  
                  <div className="flex justify-between items-start mb-6 relative z-10">
                     <div className="flex items-center gap-4">
                        <div className="relative flex-shrink-0">
                           <img 
                             src={item.avatar} 
                             alt={item.name} 
                             className="w-16 h-16 rounded-full border-2 border-mk-gold/20 object-cover"
                           />
                           <div className="absolute -bottom-1 -right-1 bg-mk-black rounded-full p-1 border border-mk-gold/30">
                              <CheckCircle size={12} className="text-mk-gold fill-mk-gold" />
                           </div>
                        </div>
                        <div>
                           <h4 className="text-white font-bold text-lg flex items-center gap-2">
                             {item.name}
                           </h4>
                           <span className={`text-[9px] px-2 py-0.5 rounded-full border uppercase tracking-widest font-bold mt-1 inline-block ${getBadgeStyle(item.memberStatus)}`}>
                              Membro {item.memberStatus}
                           </span>
                        </div>
                     </div>
                     <div className="text-right">
                        <div className="flex items-center gap-1 text-gray-500 text-[10px] uppercase tracking-widest mb-1 justify-end">
                           <ShoppingBag size={10} />
                           <span>Aquisições</span>
                        </div>
                        <span className="text-2xl font-serif text-white">{item.purchaseCount}</span>
                     </div>
                  </div>

                  <div className="mb-6 relative z-10">
                     <div className="flex gap-1 mb-4">
                        {[...Array(5)].map((_, i) => (
                           <Star key={i} size={14} className="text-mk-gold fill-mk-gold drop-shadow-md" />
                        ))}
                     </div>
                     <p className="text-gray-300 text-base leading-relaxed italic font-light">
                        "{item.text}"
                     </p>
                  </div>
                  
                  <div className="flex items-center gap-2 mt-4 text-[10px] text-gray-600 uppercase tracking-widest">
                     <span className="w-2 h-2 rounded-full bg-green-500/50" />
                     Compra Verificada
                  </div>
               </motion.div>
            ))}
         </motion.div>
      </div>
    </section>
  );
};

export default FrequentReviews;