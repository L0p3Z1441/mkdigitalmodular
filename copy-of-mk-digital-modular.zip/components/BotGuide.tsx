
import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, X, Send, Volume2, VolumeX, Sparkles, Bot, Navigation } from 'lucide-react';
import { GoogleGenAI, FunctionDeclaration, Type } from "@google/genai";
import { Language } from '../types';

// Interface for Web Speech API
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface Props {
  onNavigate: (nicheId: string) => void;
  lang: Language;
}

export interface BotGuideHandle {
  ask: (question: string) => void;
}

// Visualizer Component for smooth voice animation
const VoiceVisualizer = ({ isActive, color = "bg-mk-gold" }: { isActive: boolean, color?: string }) => {
  return (
    <div className="flex items-center justify-center gap-1 h-6">
      {[1, 2, 3, 4, 5].map((bar) => (
        <motion.div
          key={bar}
          initial={{ height: 4 }}
          animate={isActive ? { 
            height: [4, 12 + Math.random() * 12, 4],
            opacity: [0.5, 1, 0.5]
          } : { height: 4, opacity: 0.3 }}
          transition={{
            duration: 0.4,
            repeat: Infinity,
            repeatType: "reverse",
            delay: bar * 0.1,
            ease: "easeInOut"
          }}
          className={`w-1 rounded-full ${color}`}
        />
      ))}
    </div>
  );
};

// Smooth Typing Indicator
const TypingIndicator = () => {
  const dotTransition = {
    duration: 0.6,
    repeat: Infinity,
    repeatType: "loop" as const,
    ease: "easeInOut" as const
  };

  return (
    <div className="flex items-center gap-1 p-2">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          initial={{ y: 0, opacity: 0.4 }}
          animate={{ y: [-2, 2, -2], opacity: [0.4, 1, 0.4] }}
          transition={{ ...dotTransition, delay: i * 0.15 }}
          className="w-1.5 h-1.5 bg-mk-gold rounded-full"
        />
      ))}
    </div>
  );
};

// Language Translations Config
const UI_TEXT = {
  [Language.BR]: {
    promptTitle: "Concierge MK",
    promptSubtitle: "Posso guiar sua navegação?",
    yes: "Sim",
    no: "Não",
    header: "MK Navigator",
    placeholder: "Diga para onde quer ir...",
    listening: "Ouvindo...",
    speaking: "Falando...",
    demoMode: "Modo de demonstração: Navegação automática indisponível sem chave API.",
    welcome: "Bem-vindo. Sou seu Concierge MK. Diga-me o que busca (ex: 'Investir', 'Programar') ou faça uma pergunta sobre os nichos.",
    navConfirm: (dest: string) => `Compreendido. Acessando a área de ${dest}.`,
    error: "Houve uma falha na comunicação. Por favor, tente novamente."
  },
  [Language.US]: {
    promptTitle: "MK Concierge",
    promptSubtitle: "May I guide your journey?",
    yes: "Yes",
    no: "No",
    header: "MK Navigator",
    placeholder: "Tell me where to go...",
    listening: "Listening...",
    speaking: "Speaking...",
    demoMode: "Demo mode: Auto-navigation unavailable without API key.",
    welcome: "Welcome. I am your MK Concierge. Tell me what you seek (e.g., 'Investing', 'Coding') or ask a question about the niches.",
    navConfirm: (dest: string) => `Understood. Accessing the ${dest} area.`,
    error: "There was a communication failure. Please try again."
  },
  [Language.ES]: {
    promptTitle: "Conserje MK",
    promptSubtitle: "¿Puedo guiar su navegación?",
    yes: "Sí",
    no: "No",
    header: "MK Navigator",
    placeholder: "Dígame adónde quiere ir...",
    listening: "Escuchando...",
    speaking: "Hablando...",
    demoMode: "Modo demostración: Navegación automática no disponible sin clave API.",
    welcome: "Bienvenido. Soy su Conserje MK. Dígame qué busca (ej: 'Invertir', 'Programar') o haga una pregunta sobre los nichos.",
    navConfirm: (dest: string) => `Entendido. Accediendo al área de ${dest}.`,
    error: "Hubo un fallo en la comunicación. Por favor, inténtelo de nuevo."
  }
};

const BotGuide = forwardRef<BotGuideHandle, Props>(({ onNavigate, lang }, ref) => {
  const [stage, setStage] = useState<'prompt' | 'chat' | 'hidden'>('hidden');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  // Get current language config
  const t = UI_TEXT[lang];

  useImperativeHandle(ref, () => ({
    ask: (question: string) => {
      setStage('chat');
      // Small delay to allow UI to render before scrolling/sending
      setTimeout(() => {
         handleSend(question);
      }, 100);
    }
  }));

  // Helper for language codes
  const getLangCode = (l: Language) => {
    switch(l) {
      case Language.US: return 'en-US';
      case Language.ES: return 'es-ES';
      default: return 'pt-BR';
    }
  };

  // Initialize Speech Synthesis
  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Show prompt after a delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setStage((prev) => prev === 'hidden' ? 'prompt' : prev);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle Speech Recognition
  const toggleListening = () => {
    const { webkitSpeechRecognition, SpeechRecognition } = window as unknown as IWindow;
    const SpeechRecognitionAPI = SpeechRecognition || webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      alert("Browser does not support speech recognition.");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      const recognition = new SpeechRecognitionAPI();
      recognition.lang = getLangCode(lang); // DYNAMIC LANG
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        handleSend(transcript);
      };

      recognitionRef.current = recognition;
      recognition.start();
    }
  };

  const speak = (text: string) => {
    if (!synthRef.current || !soundEnabled) return;

    // Cancel previous speech
    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = getLangCode(lang); // DYNAMIC LANG
    utterance.rate = 1.1;
    utterance.pitch = 1;
    
    // Try to find a good voice for the current language
    const voices = synthRef.current.getVoices();
    const langCode = getLangCode(lang);
    const voice = voices.find(v => v.lang.includes(langCode) && v.name.includes('Google')) || 
                  voices.find(v => v.lang.includes(langCode)) || 
                  voices[0];
    
    if (voice) utterance.voice = voice;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  };

  const getSystemPrompt = (currentLang: Language) => {
    const langCode = getLangCode(currentLang);
    const context = `
      CONTEXTO MK DIGITAL (PLATAFORMA PREMIUM DE EBOOKS):
      - Marketing Digital (ID: marketing)
      - Investimentos (ID: investment)
      - Desenvolvimento Pessoal (ID: development)
      - Relacionamento (ID: relationships)
      - Programação (ID: programming)
      - Bem-estar (ID: wellness)
      - Espiritualidade (ID: spirituality)
      - Home/Início (ID: home)

      VOCÊ É O "CONCIERGE MK":
      1. Se o usuário pedir para ir a algum lugar, USE 'navigateToNiche'.
      2. Se o usuário fizer uma pergunta (ex: "Por que as pessoas falham em marketing?"), RESPONDA com sabedoria, brevidade (max 3 frases) e elegância.
      3. Não use formatação Markdown.
    `;

    if (currentLang === Language.US) {
      return `
        CONTEXT MK DIGITAL (PREMIUM EBOOK PLATFORM):
        - Niches IDs: marketing, investment, development, relationships, programming, wellness, spirituality, home.

        YOU ARE THE "MK CONCIERGE":
        1. If user wants to navigate/go somewhere, USE 'navigateToNiche'.
        2. If user asks a deep dive question (e.g. "Why do people fail?"), ANSWER it with wisdom, brevity (max 3 sentences), and elegance.
        3. No Markdown.
        Language: English (US).
      `;
    } else if (currentLang === Language.ES) {
      return `
        CONTEXTO MK DIGITAL (PLATAFORMA PREMIUM DE EBOOKS):
        - IDs de Nichos: marketing, investment, development, relationships, programming, wellness, spirituality, home.

        ERES EL "CONSERJE MK":
        1. Si el usuario quiere navegar/ir a algún lugar, USA 'navigateToNiche'.
        2. Si el usuario hace una pregunta profunda (ej: "¿Por qué falla la gente?"), RESPONDE con sabiduría, brevedad (máx 3 frases) y elegancia.
        3. Sin Markdown.
        Idioma: Español.
      `;
    } else {
      // PT-BR Default
      return `${context}\nIdioma: Português (Brasil).`;
    }
  };

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim()) return;

    const newMessages: Message[] = [...messages, { role: 'user', text: textToSend }];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      let responseText = "";

      if (process.env.API_KEY) {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const model = "gemini-3-flash-preview";
        
        const navigateTool: FunctionDeclaration = {
          name: 'navigateToNiche',
          description: 'Navigates the site to a specific niche page or home.',
          parameters: {
            type: Type.OBJECT,
            properties: {
              nicheId: {
                type: Type.STRING,
                description: 'The ID of the niche. Allowed: "marketing", "investment", "development", "relationships", "programming", "wellness", "spirituality", "home".',
                enum: ["marketing", "investment", "development", "relationships", "programming", "wellness", "spirituality", "home"]
              },
            },
            required: ['nicheId'],
          },
        };

        const systemPrompt = getSystemPrompt(lang);
        const historyContext = messages.slice(-4).map(m => `${m.role === 'user' ? 'User' : 'Concierge'}: ${m.text}`).join('\n');

        const result = await ai.models.generateContent({
            model: model,
            contents: [
              { role: 'user', parts: [{ text: `${systemPrompt}\n\nHistory:\n${historyContext}\n\nCurrent User Input: ${textToSend}` }] }
            ],
            config: {
              tools: [{ functionDeclarations: [navigateTool] }]
            }
        });
        
        const functionCalls = result.functionCalls;
        let navigationHappened = false;
        let toolNicheName = "";
        
        // CRITICAL FIX: Check for function calls first to avoid "non-text parts" warning
        if (functionCalls && functionCalls.length > 0) {
           const call = functionCalls[0];
           if (call.name === 'navigateToNiche') {
              const nicheId = call.args['nicheId'] as string;
              onNavigate(nicheId);
              navigationHappened = true;
              toolNicheName = nicheId;
           }
        }

        // Only try to access text if it's available, otherwise generate a fallback based on action
        if (result.candidates && result.candidates[0].content.parts.some(p => p.text)) {
           responseText = result.text || "";
        }
        
        if (!responseText && navigationHappened) {
          // If the model invoked a function but didn't return text, we provide a UI confirmation
          responseText = t.navConfirm(toolNicheName === 'home' ? (lang === Language.US ? 'home' : (lang === Language.ES ? 'inicio' : 'início')) : toolNicheName);
        } else if (!responseText) {
           // Fallback if no text and no function (rare)
          responseText = lang === Language.US ? "I'm thinking..." : (lang === Language.ES ? "Estoy pensando..." : "Estou pensando...");
        }

      } else {
        responseText = t.demoMode;
      }

      setMessages((prev) => [...prev, { role: 'model', text: responseText }]);
      speak(responseText);

    } catch (error) {
      console.error(error);
      const errorMsg = t.error;
      setMessages((prev) => [...prev, { role: 'model', text: errorMsg }]);
      speak(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const startChat = () => {
    setStage('chat');
    if (messages.length === 0) {
      const welcome = t.welcome;
      setMessages([{ role: 'model', text: welcome }]);
      speak(welcome);
    }
  };

  return (
    <>
      <AnimatePresence>
        {stage === 'prompt' && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: 50 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-6 right-6 z-50 flex items-center gap-4 bg-mk-black/90 backdrop-blur-md border border-mk-gold/30 p-4 rounded-none shadow-2xl shadow-mk-gold/10 max-w-sm gpu-accelerated"
          >
            <div className="bg-mk-gold/10 p-2 rounded-full relative">
              <Sparkles className="text-mk-gold w-6 h-6 z-10 relative" />
              <div className="absolute inset-0 bg-mk-gold/20 rounded-full animate-ping opacity-20" />
            </div>
            <div className="flex-1">
              <p className="text-white font-serif text-lg leading-none mb-1">{t.promptTitle}</p>
              <p className="text-gray-400 text-xs uppercase tracking-wider">{t.promptSubtitle}</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setStage('hidden')}
                className="px-3 py-1 text-xs text-gray-500 hover:text-white transition-colors uppercase tracking-widest"
              >
                {t.no}
              </button>
              <button 
                onClick={startChat}
                className="px-4 py-1 bg-mk-gold text-black text-xs font-bold uppercase tracking-widest hover:bg-white transition-colors shadow-lg shadow-mk-gold/20"
              >
                {t.yes}
              </button>
            </div>
          </motion.div>
        )}

        {stage === 'chat' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20, transformOrigin: 'bottom right' }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", stiffness: 350, damping: 30 }}
            // Responsive sizing: Full width/height on mobile, fixed on desktop
            className="fixed bottom-0 right-0 w-full h-[100dvh] sm:bottom-6 sm:right-6 sm:w-[380px] sm:h-[600px] bg-mk-black border-t sm:border border-mk-gold/40 flex flex-col shadow-2xl shadow-black/50 gpu-accelerated z-[60]"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10 bg-neutral-900/90 backdrop-blur-sm relative z-10">
              <div className="flex items-center gap-2">
                <div className={`transition-all duration-500 ${isSpeaking ? 'scale-110' : 'scale-100'}`}>
                   <Navigation className={`w-5 h-5 ${isSpeaking ? 'text-mk-gold drop-shadow-[0_0_8px_rgba(212,175,55,0.8)]' : 'text-mk-gold'}`} />
                </div>
                <span className="font-serif text-white">{t.header}</span>
              </div>
              <div className="flex items-center gap-3">
                {isSpeaking && (
                   <div className="mr-2">
                      <VoiceVisualizer isActive={true} />
                   </div>
                )}
                <button onClick={() => {
                  setSoundEnabled(!soundEnabled);
                  if (soundEnabled && synthRef.current) synthRef.current.cancel();
                }} className="text-gray-400 hover:text-white transition-colors">
                  {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
                </button>
                <button onClick={() => setStage('hidden')} className="text-gray-400 hover:text-mk-red transition-colors">
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-mk-gold/20 scrollbar-track-transparent bg-gradient-to-b from-transparent to-black/30">
              <AnimatePresence mode='popLayout'>
                {messages.map((msg, i) => (
                  <motion.div
                    layout
                    key={i}
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] p-3 text-sm leading-relaxed shadow-lg ${
                      msg.role === 'user' 
                        ? 'bg-white/10 text-white border border-white/5 rounded-tl-lg rounded-bl-lg rounded-br-lg' 
                        : 'bg-[#1a1a1a] text-gray-200 border border-mk-gold/20 rounded-tr-lg rounded-bl-lg rounded-br-lg'
                    }`}>
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {isLoading && (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }} 
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="bg-[#1a1a1a] border border-mk-gold/10 rounded-tr-lg rounded-bl-lg rounded-br-lg shadow-lg">
                    <TypingIndicator />
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className={`p-4 border-t border-white/10 bg-neutral-900/90 backdrop-blur-sm transition-colors duration-500 pb-safe ${isListening ? 'border-mk-red/30' : ''}`}>
              <div className="relative flex items-center gap-2">
                <motion.button
                  onClick={toggleListening}
                  whileTap={{ scale: 0.9 }}
                  animate={isListening ? { 
                    backgroundColor: "rgba(138, 15, 15, 0.2)", 
                    borderColor: "#8A0F0F",
                    boxShadow: "0 0 15px rgba(138, 15, 15, 0.3)"
                  } : { 
                    backgroundColor: "transparent", 
                    borderColor: "rgba(212, 175, 55, 0.3)",
                    boxShadow: "none"
                  }}
                  className="p-3 border rounded-sm transition-all duration-300 relative overflow-hidden"
                >
                  <Mic size={18} className={isListening ? "text-mk-red" : "text-mk-gold"} />
                  {isListening && (
                     <div className="absolute inset-0 bg-mk-red/10 animate-pulse" />
                  )}
                </motion.button>
                
                <div className="flex-1 relative">
                   <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder={isListening ? t.listening : t.placeholder}
                    className="w-full bg-black/50 border border-white/10 text-white px-4 py-2.5 text-sm focus:border-mk-gold focus:ring-1 focus:ring-mk-gold/20 outline-none transition-all duration-300 placeholder:text-gray-600 rounded-sm"
                  />
                  {isListening && (
                     <div className="absolute right-2 top-1/2 -translate-y-1/2">
                        <VoiceVisualizer isActive={true} color="bg-mk-red" />
                     </div>
                  )}
                </div>

                <motion.button
                  onClick={() => handleSend()}
                  disabled={!input.trim()}
                  whileHover={{ scale: 1.1, color: '#D4AF37' }}
                  whileTap={{ scale: 0.9 }}
                  className="p-2 text-gray-400 disabled:opacity-30 transition-colors"
                >
                  <Send size={18} />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Minimized Trigger (if user closed prompt but didn't engage) */}
      {stage === 'hidden' && (
         <motion.button 
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            onClick={() => setStage('prompt')}
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            className="fixed bottom-6 right-6 z-40 bg-mk-black border border-mk-gold/30 p-3 text-mk-gold hover:text-black hover:bg-mk-gold transition-colors duration-300 shadow-[0_0_20px_rgba(212,175,55,0.2)] rounded-sm group"
         >
            <Bot size={24} className="group-hover:rotate-12 transition-transform duration-300" />
         </motion.button>
      )}
    </>
  );
});

export default BotGuide;
