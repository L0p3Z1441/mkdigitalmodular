

import React, { memo } from 'react';
import { motion } from 'framer-motion';
import { Star, Quote, ShieldCheck } from 'lucide-react';
import { Review } from '../types';

interface Props {
  reviews: Review[];
}

const ReviewsSection: React.FC<Props> = memo(({ reviews }) => {
  // Triple the reviews to ensure smooth looping without gaps on wide screens
  const marqueeReviews = [...reviews, ...reviews, ...reviews];

  return (
    <section className="py-24 bg-mk-black border-t border-white/5 relative overflow-hidden">
       {/* Background accent */}
       <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-mk-gold/5 rounded-full blur-[120px] pointer-events-none" />
       <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-mk-red/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6 mb-12 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-mk-gold/20 bg-mk-gold/5 mb-6">
           <ShieldCheck size={12} className="text-mk-gold" />
           <span className="text-[10px] uppercase tracking-widest text-mk-gold font-bold">Feedback Verificado</span>
        </div>
        <h3 className="text-3xl md:text-5xl font-serif text-white mb-4">
          O Efeito da Metodologia
        </h3>
        <p className="text-gray-400 font-light text-lg">
           Resultados reais de quem aplicou a estrutura.
        </p>
      </div>

      {/* Marquee Container */}
      <div className="relative w-full overflow-hidden py-8">
         {/* Gradient Masks for fade effect on edges */}
         <div className="absolute top-0 left-0 w-8 md:w-32 h-full bg-gradient-to-r from-mk-black to-transparent z-20 pointer-events-none" />
         <div className="absolute top-0 right-0 w-8 md:w-32 h-full bg-gradient-to-l from-mk-black to-transparent z-20 pointer-events-none" />

         <motion.div 
           className="flex gap-6 w-max"
           animate={{ x: ["0%", "-50%"] }}
           transition={{ 
             duration: 60, 
             ease: "linear", 
             repeat: Infinity 
           }}
           style={{ willChange: "transform" }}
         >
            {marqueeReviews.map((review, index) => (
              <div
                key={`${review.id}-${index}`}
                className="w-[300px] md:w-[400px] bg-[#0A0A0A] p-8 border border-white/5 hover:border-mk-gold/30 transition-colors duration-300 relative group rounded-sm flex-shrink-0"
              >
                <div className="absolute top-6 right-6 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Quote size={32} className="text-mk-gold" />
                </div>

                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-shrink-0">
                    <img 
                      src={review.avatar} 
                      alt={review.name} 
                      className="w-12 h-12 rounded-full object-cover border border-mk-gold/20 group-hover:border-mk-gold transition-colors"
                      loading="lazy"
                      decoding="async"
                      width="48"
                      height="48"
                    />
                    <div className="absolute -bottom-1 -right-1 bg-black rounded-full p-0.5">
                       <ShieldCheck size={12} className="text-mk-gold" />
                    </div>
                  </div>
                  <div>
                    <p className="text-base font-bold text-white font-serif">{review.name}</p>
                    <div className="flex space-x-0.5 mt-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          size={10} 
                          className={`${i < review.rating ? 'text-mk-gold fill-mk-gold' : 'text-gray-800'}`} 
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <p className="text-gray-400 text-sm leading-relaxed italic font-light">
                  "{review.text}"
                </p>
              </div>
            ))}
         </motion.div>
      </div>
    </section>
  );
});

export default ReviewsSection;