
import React from 'react';
import { motion } from 'framer-motion';
import { EmployeeReview } from '../types';
import { Quote, Briefcase, TrendingUp, Shield } from 'lucide-react';

interface Props {
  data: {
    title: string;
    subtitle: string;
    items: EmployeeReview[];
  };
}

const EmployeeFeedback: React.FC<Props> = ({ data }) => {
  return (
    <section className="py-24 bg-mk-black border-t border-white/5 relative overflow-hidden">
      {/* Background Graphic */}
      <div className="absolute top-0 right-0 p-24 opacity-[0.02] pointer-events-none">
        <Shield size={600} />
      </div>

      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <motion.div
             initial={{ opacity: 0, scale: 0.9 }}
             whileInView={{ opacity: 1, scale: 1 }}
             viewport={{ once: true }}
             className="inline-block px-4 py-1 border border-mk-gold/20 rounded-full mb-6"
          >
             <span className="text-[10px] text-mk-gold uppercase tracking-[0.5em] font-bold">MK Internal Vision</span>
          </motion.div>
          <motion.h2 
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             className="text-4xl md:text-5xl font-serif text-white mb-6"
          >
            {data.title}
          </motion.h2>
          <motion.p
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ delay: 0.1 }}
             className="text-gray-400 font-light text-lg max-w-2xl mx-auto"
          >
             {data.subtitle}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {data.items.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-neutral-900/10 p-10 border border-white/5 hover:border-mk-gold/30 transition-all duration-700 relative group flex flex-col"
            >
              <Quote className="absolute top-8 right-8 text-mk-gold/5 group-hover:text-mk-gold/20 transition-colors" size={56} />
              
              <p className="text-gray-300 text-lg leading-relaxed mb-10 italic font-light relative z-10 flex-grow">
                "{review.text}"
              </p>

              <div className="mt-auto pt-8 border-t border-white/5">
                 <h4 className="text-white font-serif text-2xl mb-2">{review.name}</h4>
                 <div className="space-y-2">
                    <div className="flex items-center gap-3 text-[10px] tracking-[0.2em] uppercase text-gray-500">
                       <Briefcase size={14} className="text-gray-700" />
                       <span>{review.formerRole}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] tracking-[0.2em] uppercase text-mk-gold">
                       <TrendingUp size={14} />
                       <span className="font-bold">{review.currentRole}</span>
                    </div>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EmployeeFeedback;
