
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, MapPin } from 'lucide-react';

const NAMES = ["Carlos", "Marta", "André", "Elena", "Jean", "Hiroshi", "Beatriz", "Liam"];
const CITIES = ["São Paulo", "Madrid", "Miami", "Lisboa", "Tokyo", "London", "Mexico City", "Berlin"];
const PRODUCTS = ["Marketing Nível 3", "Investimentos Nível 2", "Programação Nível 3", "Desenvolvimento Pessoal"];

const AcquisitionFeed: React.FC = () => {
  const [current, setCurrent] = useState<any>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const name = NAMES[Math.floor(Math.random() * NAMES.length)];
      const city = CITIES[Math.floor(Math.random() * CITIES.length)];
      const product = PRODUCTS[Math.floor(Math.random() * PRODUCTS.length)];
      
      setCurrent({ name, city, product });
      setTimeout(() => setCurrent(null), 5000);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-[60] pointer-events-none">
      <AnimatePresence>
        {current && (
          <motion.div
            initial={{ opacity: 0, x: -50, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -20, scale: 0.9 }}
            className="bg-black/80 backdrop-blur-xl border border-mk-gold/20 p-4 flex items-center gap-4 shadow-2xl rounded-sm"
          >
            <div className="bg-mk-gold/10 p-2 rounded-full">
              <ShoppingCart className="text-mk-gold w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1 flex items-center gap-1">
                <MapPin size={10} /> {current.city}
              </p>
              <p className="text-xs text-white">
                <span className="font-bold text-mk-gold">{current.name}</span> adquiriu <span className="font-bold">{current.product}</span>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AcquisitionFeed;
