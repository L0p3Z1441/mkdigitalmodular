
import React from 'react';
import { motion } from 'framer-motion';
import { NewsItem } from '../types';
import { ArrowRight, Clock, Hash } from 'lucide-react';

interface Props {
  data: {
    title: string;
    subtitle: string;
    readMore: string;
    items: NewsItem[];
  };
  onRead: (item: NewsItem) => void;
}

const LatestNews: React.FC<Props> = ({ data, onRead }) => {
  return (
    <section className="py-24 bg-[#0a0a0a] border-t border-white/5 relative">
      <div className="container mx-auto px-6">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="mb-16 md:flex md:justify-between md:items-end"
        >
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-5xl font-serif text-white mb-4">
              {data.title}
            </h2>
            <p className="text-gray-400 text-lg md:text-xl font-light">
              {data.subtitle}
            </p>
          </div>
          <div className="hidden md:block w-32 h-px bg-mk-gold/30 mb-2" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {data.items.map((item, index) => (
            <motion.article
              key={item.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              className="group relative flex flex-col h-full bg-neutral-900/20 border border-white/5 hover:border-mk-gold/30 transition-all duration-500 overflow-hidden cursor-pointer"
              onClick={() => onRead(item)}
            >
              {/* Image Container with Zoom */}
              <div className="relative h-64 overflow-hidden">
                <div 
                   className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                   style={{ backgroundImage: `url(${item.image})` }}
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                
                {/* Category Badge */}
                <div className="absolute top-4 left-4 bg-mk-black/80 backdrop-blur-md border border-mk-gold/20 px-3 py-1 flex items-center gap-2 z-10">
                   <Hash size={12} className="text-mk-gold" />
                   <span className="text-[10px] uppercase tracking-widest text-white font-bold">{item.category}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-8 flex flex-col flex-grow relative z-10">
                 <div className="flex items-center gap-2 text-gray-500 text-xs uppercase tracking-wider mb-4">
                    <Clock size={12} />
                    <span>{item.date}</span>
                 </div>

                 <h3 className="text-2xl font-serif text-white mb-4 leading-tight group-hover:text-mk-gold transition-colors duration-300">
                    {item.title}
                 </h3>

                 <p className="text-gray-400 font-light leading-relaxed mb-8 flex-grow">
                    {item.summary}
                 </p>

                 <div className="mt-auto border-t border-white/5 pt-6">
                    <button 
                      className="flex items-center gap-2 text-sm text-white group-hover:text-mk-gold transition-colors uppercase tracking-widest font-bold group/btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRead(item);
                      }}
                    >
                       {data.readMore}
                       <ArrowRight size={16} className="transform transition-transform group-hover/btn:translate-x-1" />
                    </button>
                 </div>
              </div>

              {/* Shine Overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-[shimmer_1s_infinite] pointer-events-none" />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LatestNews;
