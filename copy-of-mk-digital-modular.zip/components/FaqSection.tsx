
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus, HelpCircle, ChevronDown } from 'lucide-react';
import { FaqItem } from '../types';

interface Props {
  title: string;
  items: FaqItem[];
}

const FaqSection: React.FC<Props> = ({ title, items }) => {
  const [openIndex, setOpenIndex] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('Geral');

  // Extract unique categories and ensure 'Geral'/'General' is first
  const categories = useMemo(() => {
    const cats = Array.from(new Set(items.map(i => i.category)));
    // Sort to keep General first if possible, otherwise just unique list
    return cats.sort((a, b) => {
        if (a === 'Geral' || a === 'General') return -1;
        if (b === 'Geral' || b === 'General') return 1;
        return 0;
    });
  }, [items]);

  // Set initial category if 'Geral' is missing or just take the first one
  React.useEffect(() => {
      if (categories.length > 0 && !categories.includes(activeCategory)) {
          setActiveCategory(categories[0]);
      }
  }, [categories, activeCategory]);

  const filteredItems = items.filter(item => item.category === activeCategory);

  return (
    <section className="py-24 bg-mk-black border-t border-white/5">
      <div className="container mx-auto px-6 max-w-5xl">
        <div className="text-center mb-12">
           <div className="inline-flex items-center justify-center p-3 bg-white/5 rounded-full mb-6">
              <HelpCircle className="text-mk-gold" size={24} />
           </div>
           <h2 className="text-3xl md:text-5xl font-serif text-white">{title}</h2>
        </div>

        {/* Categories / Tabs */}
        <div className="mb-12 overflow-x-auto hide-scrollbar">
            <div className="flex space-x-2 md:justify-center min-w-max px-2">
                {categories.map((cat) => (
                    <button
                        key={cat}
                        onClick={() => {
                            setActiveCategory(cat);
                            setOpenIndex(null);
                        }}
                        className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 border ${
                            activeCategory === cat 
                                ? 'bg-mk-gold text-black border-mk-gold shadow-[0_0_15px_rgba(212,175,55,0.3)]' 
                                : 'bg-transparent text-gray-500 border-white/10 hover:border-mk-gold/50 hover:text-white'
                        }`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        </div>

        {/* Questions List */}
        <div className="space-y-4 min-h-[400px]">
           <AnimatePresence mode='wait'>
             <motion.div
                key={activeCategory}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
             >
               {filteredItems.map((item, i) => {
                   const uniqueId = `${activeCategory}-${i}`;
                   const isOpen = openIndex === uniqueId;

                   return (
                      <div key={uniqueId} className="border border-white/5 bg-neutral-900/20 overflow-hidden mb-4 rounded-sm hover:border-mk-gold/20 transition-colors">
                         <button 
                           onClick={() => setOpenIndex(isOpen ? null : uniqueId)}
                           className="w-full flex items-center justify-between p-6 text-left hover:bg-white/5 transition-colors focus:outline-none"
                         >
                            <span className={`text-sm md:text-base font-bold tracking-wide transition-colors ${isOpen ? 'text-mk-gold' : 'text-gray-200'}`}>
                                {item.question}
                            </span>
                            <div className={`transition-transform duration-300 ${isOpen ? 'rotate-180 text-mk-gold' : 'text-gray-500'}`}>
                               <ChevronDown size={20} />
                            </div>
                         </button>
                         <AnimatePresence>
                            {isOpen && (
                               <motion.div
                                 initial={{ height: 0, opacity: 0 }}
                                 animate={{ height: "auto", opacity: 1 }}
                                 exit={{ height: 0, opacity: 0 }}
                                 className="overflow-hidden"
                               >
                                  <div className="p-6 pt-0 text-gray-400 font-light leading-relaxed text-sm md:text-base border-t border-white/5 mt-2">
                                     {item.answer}
                                  </div>
                               </motion.div>
                            )}
                         </AnimatePresence>
                      </div>
                   );
               })}
             </motion.div>
           </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default FaqSection;
