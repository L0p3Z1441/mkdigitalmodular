
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Star, Crown, Check, ArrowRight } from 'lucide-react';
import { TierBenefit } from '../types';

interface Props {
  title: string;
  subtitle: string;
  items: TierBenefit[];
}

const MembershipArea: React.FC<Props> = ({ title, subtitle, items }) => {
  const icons = [Shield, Star, Crown];
  const gradients = [
    "from-gray-400/20 to-gray-600/5 border-gray-500/30", // Prata
    "from-mk-gold/20 to-mk-gold/5 border-mk-gold/40 shadow-[0_0_30px_rgba(212,175,55,0.1)]", // Gold
    "from-mk-red/20 to-mk-red/5 border-mk-red/40 shadow-[0_0_40px_rgba(138,15,15,0.15)]" // Black
  ];
  const accentColors = ["text-gray-300", "text-mk-gold", "text-mk-red"];

  return (
    <section className="py-24 bg-mk-black relative overflow-hidden">
      {/* Background Decorative Mesh */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_50%_0%,rgba(212,175,55,0.05),transparent_70%)]" />

      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-6xl font-serif text-white mb-6 tracking-tight">
            {title}
          </h2>
          <p className="text-gray-400 font-light text-lg max-w-2xl mx-auto">
            {subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((item, i) => {
            const Icon = icons[i];
            const isBlack = i === 2;
            
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.8 }}
                className={`relative group p-10 bg-gradient-to-br ${gradients[i]} border backdrop-blur-sm rounded-sm transition-all duration-500 hover:-translate-y-2`}
              >
                {isBlack && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-mk-red text-white text-[10px] font-bold px-4 py-1.5 uppercase tracking-widest shadow-xl z-20">
                    O Melhor
                  </div>
                )}

                <div className="flex flex-col h-full">
                  <div className={`mb-8 ${accentColors[i]}`}>
                    <Icon size={48} strokeWidth={1.5} />
                  </div>

                  <h3 className={`text-2xl md:text-3xl font-serif font-bold mb-8 text-white group-hover:${accentColors[i]} transition-colors`}>
                    {item.tier}
                  </h3>

                  <ul className="space-y-5 mb-12 flex-grow">
                    {item.benefits.map((benefit, j) => (
                      <li key={j} className="flex items-start gap-3 text-gray-400 text-sm group-hover:text-gray-200 transition-colors">
                        <Check size={16} className={`${accentColors[i]} mt-0.5 flex-shrink-0`} />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>

                  <button className={`w-full py-4 border ${isBlack ? 'bg-mk-red border-mk-red text-white' : 'border-white/10 hover:border-white/40 text-white'} uppercase tracking-[0.2em] text-[10px] font-bold flex items-center justify-center gap-2 transition-all hover:gap-4`}>
                    Ascender <ArrowRight size={14} />
                  </button>
                </div>

                {/* Internal Glow on Hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-white pointer-events-none" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default MembershipArea;
