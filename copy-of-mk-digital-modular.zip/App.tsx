
import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { ArrowUp, ShoppingBag, Info, AlertTriangle } from 'lucide-react';
import { Language, Translations, NicheId, User, NewsItem } from './types';
import { CONTENT, NICHE_KEYS, NICHE_IMAGES } from './constants';
import LanguageSelector from './components/LanguageSelector';
import AuthModal from './components/AuthModal';
import NicheCard from './components/NicheCard';
import ProductCard from './components/ProductCard';
import LearningEvolution from './components/LearningEvolution';
import ReviewsSection from './components/ReviewsSection';
import PlatformFeedback from './components/PlatformFeedback';
import FrequentReviews from './components/FrequentReviews';
import TrustStats from './components/TrustStats';
import FaqSection from './components/FaqSection';
import AcquisitionFeed from './components/AcquisitionFeed';
import HubHeader from './components/HubHeader';

// Static Imports
import Marketplace from './components/Marketplace';
import HubView from './components/HubView';
import DigitalGallery from './components/DigitalGallery';
import DesignPhilosophy from './components/DesignPhilosophy';
import Roadmap from './components/Roadmap';
import EmployeeFeedback from './components/EmployeeFeedback';
import LatestNews from './components/LatestNews';
import ArticleReader from './components/ArticleReader';
import BotGuide from './components/BotGuide';
import ChatGuia from './components/ChatGuia';

function App() {
  const [lang, setLang] = useState<Language>(Language.BR);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<'home' | 'marketplace' | 'hub'>('home');
  const [selectedNiche, setSelectedNiche] = useState<NicheId | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<NewsItem | null>(null);

  // Ref to control the bot programmatically
  const botRef = useRef<any>(null);

  const t: Translations = CONTENT[lang];
  
  const maxLevels = selectedNiche ? (t.nicheDetails[selectedNiche]?.maxLevels || 3) : 3;

  useEffect(() => {
    const session = localStorage.getItem('mk_user_session');
    if (session) {
      try {
        setUser(JSON.parse(session));
      } catch (e) {
        localStorage.removeItem('mk_user_session');
      }
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsScrolled(currentScrollY > 50);
      setShowBackToTop(currentScrollY > 500);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogin = async (email: string) => {
    const newUser = { name: "Membro MK", email, country: "Brasil" };
    setUser(newUser);
    localStorage.setItem('mk_user_session', JSON.stringify(newUser));
  };

  const handleRegister = async (name: string, email: string) => {
    const newUser = { name, email, country: "Brasil" };
    setUser(newUser);
    localStorage.setItem('mk_user_session', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('mk_user_session');
    setCurrentView('home');
  };

  const handleNicheClick = (nicheId: NicheId) => {
    setSelectedNiche(nicheId);
    setTimeout(() => {
       const element = document.getElementById('products-section');
       element?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleProductNavigation = (nicheId: NicheId) => {
    setCurrentView('home');
    setSelectedNiche(nicheId);
    setTimeout(() => {
      document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 500);
  };

  return (
    <div className="bg-[#050505] min-h-screen text-gray-200 font-sans selection:bg-mk-gold/30 selection:text-white overflow-x-hidden">
      <AcquisitionFeed />

      <HubHeader 
        user={user}
        lang={lang}
        isScrolled={isScrolled}
        currentView={currentView}
        translations={t}
        onLogin={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
        isOpen={mobileMenuOpen}
        onNavigate={(view) => { setCurrentView(view); setMobileMenuOpen(false); window.scrollTo(0,0); }}
        onLangSelect={setLang}
      />

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        text={t.auth}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      {/* Main Content Router */}
      {currentView === 'home' && (
        <main>
          {/* Hero Section */}
          <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
            {/* Optimized Gradient Background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1a1a1a] via-[#050505] to-[#000000] z-0" />
            
            {/* Animated Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:100px_100px] [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_70%)] pointer-events-none" />

            <div className="container mx-auto px-6 relative z-10 pt-10">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="text-center max-w-4xl mx-auto"
              >
                <motion.div 
                   initial={{ scale: 0.9, opacity: 0 }}
                   animate={{ scale: 1, opacity: 1 }}
                   transition={{ delay: 0.2 }}
                   className="inline-block mb-6 px-4 py-1 border border-mk-gold/30 rounded-full bg-mk-gold/5 backdrop-blur-md"
                >
                   <span className="text-[10px] md:text-xs font-bold uppercase tracking-[0.3em] text-mk-gold">
                      {t.hero.microcopy}
                   </span>
                </motion.div>

                {/* Adjusted Font Size for Mobile */}
                <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-9xl font-serif text-white mb-8 tracking-tight leading-[0.9]">
                  MK <span className="text-gold-gradient italic pr-2">DIGITAL</span>
                </h1>
                
                <p className="text-lg md:text-2xl text-gray-400 font-light mb-12 leading-relaxed max-w-2xl mx-auto">
                  {t.hero.subtitle}
                </p>

                <div className="flex flex-col md:flex-row items-center justify-center gap-6">
                  <motion.button
                    onClick={() => document.getElementById('niches')?.scrollIntoView({ behavior: 'smooth' })}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="group relative px-8 py-4 bg-mk-gold text-black font-bold text-sm uppercase tracking-widest overflow-hidden rounded-sm shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_40px_rgba(212,175,55,0.5)] transition-all"
                  >
                    <div className="absolute inset-0 w-full h-full bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500 skew-x-12" />
                    <span className="relative z-10 flex items-center gap-2">
                      {t.hero.cta} <ArrowUp className="rotate-45" size={16} />
                    </span>
                  </motion.button>
                  
                  <motion.button
                    onClick={() => setCurrentView('hub')}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 border border-white/20 text-white font-bold text-sm uppercase tracking-widest hover:bg-white hover:text-black transition-all rounded-sm"
                  >
                    Acessar Hub
                  </motion.button>
                </div>
              </motion.div>
            </div>

            {/* Scroll Indicator */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 1 }}
              className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
            >
              <div className="w-[1px] h-16 bg-gradient-to-b from-transparent via-mk-gold to-transparent opacity-50" />
            </motion.div>
          </section>

          {/* Trust Stats */}
          <TrustStats stats={t.stats} />

          {/* Niches Grid */}
          <section id="niches" className="py-16 md:py-24 bg-mk-black">
            <div className="container mx-auto px-6">
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="flex items-end justify-between mb-12 border-b border-white/10 pb-6"
              >
                <h2 className="text-3xl md:text-4xl font-serif text-white">
                  {t.niches.title}
                </h2>
                <span className="hidden md:block text-xs font-mono text-mk-gold">
                  /// SELECT_DOMAIN
                </span>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {NICHE_KEYS.map((key, index) => (
                  <div key={key} className={index === 0 ? "md:col-span-2 md:row-span-2 h-full" : ""}>
                    <NicheCard
                      title={t.niches.items[key]}
                      image={NICHE_IMAGES[key]}
                      index={index}
                      onClick={() => handleNicheClick(key)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </section>
          
          {/* Content Sections */}
          <ReviewsSection reviews={
            selectedNiche && t.nicheDetails[selectedNiche]?.reviews.length > 0 
              ? t.nicheDetails[selectedNiche].reviews 
              : t.frequentReviews.items
          } />

          {/* Product Section */}
          <section id="products-section" className="py-16 md:py-24 bg-[#080808] relative">
            <div className="container mx-auto px-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
                 <div>
                    <h2 className="text-4xl md:text-5xl font-serif text-white mb-4">
                      {selectedNiche ? t.niches.items[selectedNiche] : t.hero.cta}
                    </h2>
                    <p className="text-gray-400 font-light max-w-xl text-lg">
                      {selectedNiche 
                        ? t.nicheDetails[selectedNiche].description 
                        : "Selecione um domínio acima para visualizar os materiais disponíveis."}
                    </p>
                 </div>
                 {selectedNiche && (
                    <button 
                       onClick={() => setSelectedNiche(null)}
                       className="text-mk-gold text-xs uppercase tracking-widest hover:text-white transition-colors border-b border-mk-gold/30 pb-1"
                    >
                       {t.products.back}
                    </button>
                 )}
              </div>
              
              <AnimatePresence mode="wait">
                {selectedNiche ? (
                  <motion.div
                    key={selectedNiche}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.5 }}
                    className="grid grid-cols-1 md:grid-cols-3 gap-8"
                  >
                    {[1, 2, 3].map((level) => {
                       if (level > maxLevels) return null;
                       const details = t.nicheDetails[selectedNiche];
                       let link = details.checkoutLinks.level1;
                       let price = t.products.prices.level1;

                       if (level === 2) { link = details.checkoutLinks.level2; price = t.products.prices.level2; }
                       if (level === 3) { link = details.checkoutLinks.level3; price = t.products.prices.level3; }

                       return (
                          <ProductCard
                            key={level}
                            level={level as 1 | 2 | 3}
                            price={price}
                            nicheTitle={t.niches.items[selectedNiche]}
                            translations={t.products}
                            checkoutUrl={link}
                          />
                       );
                    })}
                  </motion.div>
                ) : (
                   <motion.div 
                     initial={{ opacity: 0 }} 
                     animate={{ opacity: 1 }}
                     className="h-64 flex items-center justify-center border border-dashed border-white/10 rounded-sm bg-white/5"
                   >
                      <div className="text-center">
                         <Info className="mx-auto text-gray-600 mb-3" size={32} />
                         <p className="text-gray-500 uppercase tracking-widest text-sm">Aguardando Seleção</p>
                      </div>
                   </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>

          <LearningEvolution translations={t.evolution} levels={t.products.levels} maxLevels={maxLevels} />
          
          <LatestNews 
             data={t.news} 
             onRead={(item) => setSelectedArticle(item)}
          />

          <ArticleReader 
             article={selectedArticle} 
             onClose={() => setSelectedArticle(null)}
             closeText={t.news.close}
          />

          <DigitalGallery {...t.gallery} />
          <EmployeeFeedback data={t.careers} />
          <FrequentReviews data={t.frequentReviews} />
          <DesignPhilosophy {...t.design} />
          <PlatformFeedback data={t.platformReviews} />
          <Roadmap {...t.roadmap} />
          <FaqSection title={t.faq.title} items={t.faq.items} />

          <footer className="bg-black py-12 border-t border-white/10">
            <div className="container mx-auto px-6 text-center">
              <h2 className="font-serif text-2xl text-white mb-6">MK DIGITAL</h2>
              <p className="text-gray-500 text-sm mb-6 max-w-md mx-auto">{t.footer.rights}</p>
              <a href={`mailto:${t.footer.contact}`} className="text-mk-gold hover:text-white transition-colors text-sm uppercase tracking-widest">
                {t.footer.contact}
              </a>
            </div>
          </footer>
        </main>
      )}

      {currentView === 'marketplace' && (
         <Marketplace 
           translations={t} 
           niches={t.niches.items} 
           nicheDetails={t.nicheDetails} 
           nicheImages={NICHE_IMAGES}
           onProductClick={handleProductNavigation}
         />
      )}

      {currentView === 'hub' && (
         <HubView 
           nicheNames={t.niches.items} 
           lang={lang} 
           onAskBot={(q) => botRef.current?.ask(q)}
         />
      )}

      {/* Back to Top */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            onClick={scrollToTop}
            className="fixed bottom-6 left-6 z-40 bg-mk-gold/90 text-black p-3 rounded-sm shadow-lg hover:bg-white transition-colors"
          >
            <ArrowUp size={20} />
          </motion.button>
        )}
      </AnimatePresence>

      {/* AI Assistants */}
      <BotGuide ref={botRef} onNavigate={handleNicheClick} lang={lang} />
      <ChatGuia 
        lang={lang} 
        nicheDetails={t.nicheDetails} 
        nicheNames={t.niches.items} 
        nicheImages={NICHE_IMAGES}
        onNavigateToProduct={handleProductNavigation} 
      />
    </div>
  );
}

export default App;
